import React from 'react';
import { TRACKS, COURSES } from '../../data/coursesData';
import { useAuth } from '../../context/AuthContext';
import {
  Star, Users, Clock, Play, ArrowRight, Shield, Award,
  Dumbbell, Flame, Zap, Trophy, CheckCircle, TrendingUp, FileText
} from 'lucide-react';

const TRACK_ICONS = { build: Dumbbell, cut: Flame, gain: Zap, powerlifting: Trophy };
const TRACK_COLORS = {
  build: { glow: 'glow-green', accent: 'emerald', border: 'border-emerald-500/20', badge: 'bg-emerald-500/10 text-emerald-400' },
  cut:   { glow: 'glow-cyan',  accent: 'cyan',    border: 'border-cyan-500/20',    badge: 'bg-cyan-500/10 text-cyan-400' },
  gain:  { glow: 'glow-amber', accent: 'amber',   border: 'border-amber-500/20',   badge: 'bg-amber-500/10 text-amber-400' },
  powerlifting: { glow: 'glow-purple', accent: 'purple', border: 'border-purple-500/20', badge: 'bg-purple-500/10 text-purple-400' },
};

export const LandingPage = ({ onSelectTrack, onBrowseCourses }) => {
  const { user, openAuth } = useAuth();

  return (
    <div className="min-h-screen">

      {/* ── HERO ── */}
      <section className="relative overflow-hidden pt-16 pb-24 px-4">
        {/* background glow blobs */}
        <div className="absolute inset-0 pointer-events-none select-none">
          <div className="absolute top-10 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl" />
          <div className="absolute top-40 right-1/4 w-72 h-72 bg-cyan-500/8 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold tracking-wider uppercase mb-6">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Science-Based Online Training
          </div>

          <h1 className="text-5xl sm:text-6xl md:text-7xl font-black tracking-tight text-white leading-none mb-6 font-display">
            BUILD YOUR{' '}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-emerald-400 to-cyan-400">
              ELITE
            </span>
            <br />PHYSIQUE
          </h1>

          <p className="text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            4 expert programs — <strong className="text-white">Build · Cut · Gain · Powerlifting</strong>.
            Each includes the official 12-week workout plan PDF, interactive tracker, nutrition calculator, routine breakdown &amp; weekly checklist.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 mb-12">
            <button
              onClick={() => onSelectTrack('build')}
              className="px-8 py-3.5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-bold rounded-xl text-base shadow-lg shadow-emerald-500/25 transition-all duration-200 transform hover:-translate-y-0.5 flex items-center gap-2"
            >
              Choose Your Track <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={onBrowseCourses}
              className="px-8 py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl text-base border border-slate-700 transition-all flex items-center gap-2"
            >
              <FileText className="w-4 h-4 text-emerald-400" /> Browse All Programs
            </button>
          </div>

          {/* Stats row */}
          <div className="flex flex-wrap justify-center gap-6 md:gap-12 text-center">
            {[
              { value: '50,000+', label: 'Athletes Enrolled' },
              { value: '4 Tracks', label: 'Specialised Programs' },
              { value: '12 Weeks', label: 'Structured Plan' },
              { value: '100%', label: 'Satisfaction Rate' },
            ].map(s => (
              <div key={s.label}>
                <div className="text-2xl font-black text-white">{s.value}</div>
                <div className="text-xs text-slate-400 mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHAT YOU GET ── */}
      <section className="py-16 px-4 bg-slate-900/40">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-black text-white font-display mb-2">📦 What You Get Inside</h2>
            <p className="text-slate-400">Every track includes all 6 core deliverables</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              { icon: '📑', title: '12-Week Workout PDF', desc: 'The official printable blueprint. Exact weekly splits, sets, reps, and coaching notes.' },
              { icon: '🏋️', title: 'Routine & Exercise Guide', desc: 'Step-by-step movement breakdowns, progression rules, and RIR targets.' },
              { icon: '📊', title: 'Workout Tracker', desc: 'Log every set, reps, weight & RIR. Visual progress charts. Auto-calculates 1RM.' },
              { icon: '🍽️', title: 'Nutrition Calculator', desc: 'Calories & protein targets. Adjustment rules for cut/bulk/maintain. Macro splits.' },
              { icon: '📅', title: '12-Week Program', desc: 'Week-by-week structured plan. Phase 1→2→3 periodization with deload weeks.' },
              { icon: '✅', title: 'Weekly Checklist', desc: 'Daily habit tracker. Workouts, nutrition targets, sleep & recovery checks.' },
            ].map(item => (
              <div key={item.title} className="p-5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all group">
                <div className="text-3xl mb-3">{item.icon}</div>
                <h3 className="text-base font-bold text-white mb-1.5 group-hover:text-emerald-400 transition-colors">{item.title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TRACK CARDS PREVIEW ── */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-black text-white font-display mb-2">🏋️ Choose Your Training Track</h2>
            <p className="text-slate-400">Pick the goal that matches your physique objective</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {TRACKS.map(track => {
              const Icon = TRACK_ICONS[track.id];
              const color = TRACK_COLORS[track.id];
              const course = COURSES.find(c => c.trackId === track.id);
              return (
                <button
                  key={track.id}
                  onClick={() => onSelectTrack(track.id)}
                  className={`text-left p-5 rounded-xl bg-slate-900 border ${color.border} hover:border-opacity-60 transition-all group flex flex-col h-full`}
                >
                  <div className={`w-11 h-11 rounded-xl ${color.badge} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className={`text-xs font-bold uppercase tracking-wider mb-1 ${color.badge.split(' ')[1]}`}>{track.name}</div>
                  <p className="text-sm text-slate-300 flex-1 leading-relaxed">{track.tagline}</p>
                  {course && (
                    <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between">
                      <span className="text-white font-bold">₹{course.discountPrice}</span>
                      <span className="text-[11px] text-slate-400">{course.durationHours}h · {course.lessonsCount} lessons</span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── SOCIAL PROOF ── */}
      <section className="py-16 px-4 bg-slate-900/40">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-black text-white text-center font-display mb-10">Results That Speak</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: 'James R.', track: 'BUILD', result: '+14kg lean muscle in 6 months', stars: 5, avatar: '💪', text: 'The hypertrophy science in this course is unreal. Went from 68kg to 82kg with barely any fat gain.' },
              { name: 'Priya S.', track: 'CUT', result: 'Body fat 26% → 14%', stars: 5, avatar: '🔥', text: 'The refeed strategy completely changed how I diet. Never felt deprived and lost fat faster than ever.' },
              { name: 'Tom K.', track: 'POWERLIFTING', result: 'Total up 85kg in 16 weeks', stars: 5, avatar: '🦍', text: "Viktor breaks down the biomechanics better than any coach I've worked with in person. Deadlift went from 180 to 220." },
            ].map(r => (
              <div key={r.name} className="p-5 rounded-xl bg-slate-900 border border-slate-800">
                <div className="flex items-center gap-3 mb-3">
                  <div className="text-2xl">{r.avatar}</div>
                  <div>
                    <div className="text-sm font-bold text-white">{r.name}</div>
                    <div className="text-xs text-slate-400">{r.track} Track</div>
                  </div>
                  <div className="ml-auto flex gap-0.5">
                    {Array(r.stars).fill(0).map((_, i) => <Star key={i} className="w-3 h-3 text-amber-400 fill-amber-400" />)}
                  </div>
                </div>
                <div className="text-emerald-400 text-xs font-bold mb-2">✓ {r.result}</div>
                <p className="text-sm text-slate-300 leading-relaxed">"{r.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PRICING CTA ── */}
      <section className="py-20 px-4">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-black text-white font-display mb-4">One Price. Full Access.</h2>
          <p className="text-slate-400 mb-8">All 6 deliverables included. Lifetime access. 30-day money-back guarantee.</p>
          <div className="p-8 rounded-2xl bg-slate-900 border border-emerald-500/20 glow-green">
            <div className="flex items-baseline justify-center gap-3 mb-2">
              <span className="text-5xl font-black text-white">₹2499</span>
              <span className="text-xl text-slate-500 line-through">₹4999</span>
            </div>
            <p className="text-slate-400 text-sm mb-6">per track · one-time payment · includes all bonuses</p>
            <button
              onClick={() => onSelectTrack('build')}
              className="w-full max-w-xs py-3.5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-bold rounded-xl text-base shadow-lg shadow-emerald-500/25 transition-all flex items-center justify-center gap-2 mx-auto"
            >
              Get Full Access Now <ArrowRight className="w-4 h-4" />
            </button>
            <div className="flex justify-center gap-5 mt-5 text-xs text-slate-500">
              <span className="flex items-center gap-1"><Shield className="w-3.5 h-3.5 text-emerald-400" />30-Day Refund</span>
              <span className="flex items-center gap-1"><Award className="w-3.5 h-3.5 text-amber-400" />Certificate</span>
              <span className="flex items-center gap-1"><CheckCircle className="w-3.5 h-3.5 text-cyan-400" />Lifetime Updates</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

import React from 'react';

export const KaizenLogo = ({ size = 'normal', showText = true }) => {
  const iconSize = size === 'large' ? 'w-10 h-10' : 'w-8 h-8';
  const textSize = size === 'large' ? 'text-2xl' : 'text-xl';
  const dotSize = size === 'large' ? 'text-3xl' : 'text-2xl';

  return (
    <div className="flex items-center gap-3">
      <div className={`${iconSize} bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20`}>
        <svg width="60%" height="60%" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="4" y="3" width="3" height="12" rx="1" fill="#0f0f0f"/>
          <line x1="7" y1="3" x2="14" y2="9" stroke="#0f0f0f" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
          <line x1="7" y1="15" x2="14" y2="9" stroke="#0f0f0f" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </div>
      {showText && (
        <div className={`font-black tracking-tight text-white font-display ${textSize} flex items-baseline`}>
          KAIZEN<span className={`text-emerald-500 leading-none ${dotSize}`}>.</span>
        </div>
      )}
    </div>
  );
};

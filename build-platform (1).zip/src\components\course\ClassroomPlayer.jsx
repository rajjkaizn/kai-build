import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  ArrowLeft, ChevronRight, ChevronDown, CheckCircle, Circle,
  FileText, Download, BookOpen, ExternalLink, Award,
  Dumbbell, Layers, CheckSquare, Sparkles, Printer,
  ClipboardList, Trophy, Lock, AlertCircle
} from 'lucide-react';
import { QuizEngine } from './QuizEngine';
import { DOWNLOADABLE_PDFS } from '../../data/downloadablePdfs';
import { LessonContentRenderer } from './LessonContentRenderer';
import { PowerliftingProgramSelector } from './PowerliftingProgramSelector';

const TRACK_COLORS = {
  build: { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', btn: 'bg-emerald-500 hover:bg-emerald-400 text-slate-950', badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' },
  cut: { text: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/30', btn: 'bg-cyan-500 hover:bg-cyan-400 text-slate-950', badge: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20' },
  gain: { text: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/30', btn: 'bg-amber-500 hover:bg-amber-400 text-slate-950', badge: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  powerlifting: { text: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/30', btn: 'bg-purple-500 hover:bg-purple-400 text-slate-950', badge: 'bg-purple-500/10 text-purple-400 border-purple-500/20' },
  bundle: { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', btn: 'bg-emerald-500 hover:bg-emerald-400 text-slate-950', badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' },
};

export const ClassroomPlayer = ({ course, initialLesson, onBack, onBuy }) => {
  const { user, isEnrolled, toggleLessonCompletion, isLessonCompleted, recordQuizResult } = useAuth();
  const enrolled = isEnrolled(course?.id) || isEnrolled('course-bundle-all');

  // flatten all lessons with module context
  const allLessons = course?.modules?.flatMap(m =>
    m.lessons.map(l => ({
      ...l,
      moduleId: m.id,
      moduleTitle: m.title,
      learningObjective: m.learningObjective,
      checkpoint: m.checkpoint,
      completionRequirement: m.completionRequirement,
    }))
  ) || [];

  const firstLesson = initialLesson || allLessons[0];
  const [activeLesson, setActiveLesson] = useState(firstLesson);
  const [activeTab, setActiveTab] = useState(firstLesson?.isQuiz ? 'quiz' : 'lesson');

  const [closedModules, setClosedModules] = useState({});
  const isModuleOpen = (mIdx) => !closedModules[mIdx];
  const toggleModule = (mIdx) => {
    setClosedModules(prev => ({ ...prev, [mIdx]: !prev[mIdx] }));
  };

  useEffect(() => {
    if (initialLesson) {
      const match = allLessons.find(l => l.id === initialLesson.id) || initialLesson;
      setActiveLesson(match);
      if (match.isQuiz) {
        setActiveTab('quiz');
      } else {
        setActiveTab('lesson');
      }
    } else if (allLessons.length > 0) {
      setActiveLesson(allLessons[0]);
      setActiveTab(allLessons[0].isQuiz ? 'quiz' : 'lesson');
    }
  }, [initialLesson, course?.id]);

  const colors = TRACK_COLORS[course?.trackId] || TRACK_COLORS.build;
  const coursePdf = DOWNLOADABLE_PDFS.find(p => p.trackId === course?.trackId) || DOWNLOADABLE_PDFS[0];
  const pdfUrl = coursePdf?.fileUrl || '/pdfs/KFA_12_Week_Workout_Plans.pdf';

  const handleLessonSelect = (lesson) => {
    if (!lesson.isFreePreview && !enrolled) {
      if (onBuy) onBuy(course);
      return;
    }
    const enriched = allLessons.find(l => l.id === lesson.id) || lesson;
    setActiveLesson(enriched);
    if (enriched.isQuiz) {
      setActiveTab('quiz');
    } else {
      setActiveTab('lesson');
    }
  };

  const handleMarkComplete = () => {
    if (activeLesson) toggleLessonCompletion(activeLesson.id);
  };

  const completed = activeLesson ? isLessonCompleted(activeLesson.id) : false;

  const handleDownloadPdf = () => {
    const a = document.createElement('a');
    a.href = pdfUrl;
    a.download = (coursePdf?.title || 'Kaizen_Workout_Plan').replace(/[^a-zA-Z0-9]/g, '_') + '.pdf';
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const currentIdx = allLessons.findIndex(l => l.id === activeLesson?.id);
  const nextLesson = allLessons[currentIdx + 1] || null;

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col">
      {/* Top Navigation Bar */}
      <div className="sticky top-0 z-30 bg-slate-950/95 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onBack}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 flex-shrink-0"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Course
          </button>
          <div className="text-xs text-slate-300 font-bold truncate hidden sm:block">
            {course?.title}
          </div>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            onClick={handleDownloadPdf}
            className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-all shadow-md shadow-emerald-500/20"
          >
            <Download className="w-3.5 h-3.5" /> Download Blueprint PDF
          </button>
          <a
            href={pdfUrl}
            target="_blank"
            rel="noreferrer"
            className="hidden md:flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" /> Popout
          </a>
          <button
            onClick={handleMarkComplete}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg transition-all ${
              completed
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-slate-900 border border-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            {completed ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Circle className="w-3.5 h-3.5" />}
            {completed ? 'Completed' : 'Mark Done'}
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* ── MAIN CONTENT AREA ── */}
        <div className="flex-1 flex flex-col overflow-y-auto">
          {/* Header Banner */}
          <div className="p-6 bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border-b border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${colors.bg} ${colors.text} border ${colors.border}`}>
                    📑 Official Curriculum Lesson
                  </span>
                  <span className="text-xs text-slate-500">·</span>
                  <span className="text-xs text-slate-400">{activeLesson?.moduleTitle}</span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-black text-white font-display">
                  {activeLesson?.title}
                </h1>
                <p className="text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
                  {activeLesson?.summary || course?.subtitle}
                </p>
              </div>

              {activeLesson?.quizData && (
                <button
                  onClick={() => setActiveTab('quiz')}
                  className="px-4 py-2.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-xl text-xs font-bold hover:bg-amber-500/20 transition-all flex items-center gap-2 flex-shrink-0"
                >
                  <Award className="w-4 h-4 text-amber-400" /> Take Lesson Quiz (5 Qs)
                </button>
              )}
            </div>

            {/* Module Checkpoint Pill if available */}
            {activeLesson?.checkpoint && (
              <div className="mt-4 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 flex items-start gap-2.5 max-w-3xl">
                <ClipboardList className={`w-4 h-4 mt-0.5 flex-shrink-0 ${colors.text}`} />
                <div>
                  <span className="font-bold text-white uppercase text-[10px] tracking-wider block">
                    Module Checkpoint Target:
                  </span>
                  <span>{activeLesson.checkpoint}</span>
                </div>
              </div>
            )}

            {/* Content Tabs */}
            <div className="flex flex-wrap gap-2 mt-6">
              {[
                { id: 'lesson', icon: BookOpen, label: 'Educational Lesson Guide' },
                { id: 'pdf', icon: FileText, label: 'Official 12-Week PDF' },
                { id: 'routine', icon: Dumbbell, label: 'Routine & Exercise Menu' },
                { id: 'quiz', icon: Award, label: activeLesson?.isQuiz ? 'Final Certification Exam' : 'Lesson Quiz' },
                ...(course?.trackId === 'powerlifting' ? [{ id: 'powerlifting', icon: Trophy, label: 'Powerlifting Programs' }] : [])
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                    activeTab === tab.id
                      ? 'bg-slate-800 text-white border-slate-700 shadow-md'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  <tab.icon className={`w-3.5 h-3.5 ${activeTab === tab.id ? colors.text : ''}`} />
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Panes */}
          <div className="p-6 flex-1">
            {/* 1. LESSON READING TAB (Full Educational Content) */}
            {activeTab === 'lesson' && (
              <div>
                <LessonContentRenderer
                  content={activeLesson?.content}
                  lesson={activeLesson}
                  color={course?.trackId}
                />

                {/* Bottom Navigation */}
                <div className="pt-8 border-t border-slate-800 flex items-center justify-between gap-4 max-w-4xl mx-auto">
                  <button
                    onClick={handleMarkComplete}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all ${
                      completed
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-slate-900 border border-slate-700 text-white hover:border-emerald-500'
                    }`}
                  >
                    <CheckCircle className="w-4 h-4" />
                    {completed ? 'Lesson Completed ✓' : 'Mark Lesson as Complete'}
                  </button>

                  {nextLesson && (
                    <button
                      onClick={() => handleLessonSelect(nextLesson)}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-all shadow-md shadow-emerald-500/20"
                    >
                      <span>Next: {nextLesson.title.substring(0, 24)}...</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* 2. PDF VIEWER TAB */}
            {activeTab === 'pdf' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-black text-sm">
                      PDF
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white">{coursePdf?.title}</div>
                      <div className="text-xs text-slate-400">{coursePdf?.pages} Pages · High-Resolution Printable Blueprint</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleDownloadPdf}
                      className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg text-xs flex items-center gap-1.5 transition-all"
                    >
                      <Download className="w-3.5 h-3.5" /> Download
                    </button>
                    <a
                      href={pdfUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-lg text-xs flex items-center gap-1.5 transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5" /> Popout
                    </a>
                  </div>
                </div>

                {/* Embedded PDF Viewer */}
                <div className="w-full h-[650px] rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl relative">
                  <iframe
                    src={`${pdfUrl}#view=FitH`}
                    title="Kaizen 12-Week Workout Plan"
                    className="w-full h-full border-0"
                  />
                </div>
              </div>
            )}

            {/* 3. ROUTINE & COACHING CUES TAB */}
            {activeTab === 'routine' && (
              <div className="max-w-4xl space-y-6">
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
                  <h3 className="text-base font-black text-white font-display mb-1 flex items-center gap-2">
                    <Dumbbell className="w-5 h-5 text-emerald-400" />
                    Recommended Weekly Split & Exercise Menu
                  </h3>
                  <p className="text-xs text-slate-400 mb-4">
                    Extracted directly from the Kaizen 12-Week Program. Follow the exact order and respect the target Reps In Reserve (RIR).
                  </p>

                  <div className="space-y-4">
                    {coursePdf?.previewSections ? (
                      coursePdf.previewSections.map((sec, idx) => (
                        <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800/80">
                          <div className="text-xs font-black text-white uppercase tracking-wider mb-1 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                            {sec.title}
                          </div>
                          <div className="text-sm text-slate-300 leading-relaxed font-mono text-xs sm:text-sm">
                            {sec.text}
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-slate-400">Please refer to the PDF view for the complete exercise roster.</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* 4. QUIZ TAB */}
            {activeTab === 'quiz' && (
              <div className="max-w-2xl mx-auto py-4">
                {activeLesson?.quizData ? (
                  <QuizEngine
                    quizData={activeLesson.quizData}
                    courseId={course.id}
                    onComplete={(score, passed) => {
                      recordQuizResult(course.id, score, passed);
                      if (passed) {
                        toggleLessonCompletion(activeLesson.id);
                      }
                    }}
                  />
                ) : (
                  <div className="p-8 text-center text-slate-400">
                    <Award className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>No quiz registered for this chapter.</p>
                  </div>
                )}
              </div>
            )}

            {/* 5. POWERLIFTING PROGRAMS TAB */}
            {activeTab === 'powerlifting' && (
              <div className="max-w-3xl mx-auto py-4">
                <PowerliftingProgramSelector mode="dashboard" />
              </div>
            )}
          </div>
        </div>

        {/* ── SIDEBAR: Curriculum & Routine Chapters ── */}
        <div className="w-full lg:w-88 border-t lg:border-t-0 lg:border-l border-slate-800 bg-slate-900 flex flex-col">
          <div className="p-4 border-b border-slate-800">
            <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
              <span>Course Curriculum</span>
              <span className="text-[11px] text-emerald-400 font-mono">
                {allLessons.filter(l => isLessonCompleted(l.id)).length}/{allLessons.length} Done
              </span>
            </div>
            
            {/* Progress bar */}
            <div className="mt-2.5 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-500 rounded-full transition-all"
                style={{ width: `${allLessons.length > 0 ? (allLessons.filter(l => isLessonCompleted(l.id)).length / allLessons.length) * 100 : 0}%` }}
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            {course?.modules?.map((mod, mIdx) => (
              <div key={mod.id} className="border-b border-slate-800/60">
                <div className="w-full px-4 py-2.5 bg-slate-950/80 hover:bg-slate-900 border-b border-slate-800/40 text-left transition-colors flex items-center justify-between cursor-pointer">
                  <div
                    onClick={() => {
                      if (closedModules[mIdx]) {
                        setClosedModules(prev => ({ ...prev, [mIdx]: false }));
                      }
                      if (mod.lessons?.[0]) {
                        handleLessonSelect(mod.lessons[0]);
                      }
                    }}
                    className="flex-1 flex items-center gap-2 min-w-0 pr-2 cursor-pointer"
                  >
                    <span className="text-[11px] font-bold text-slate-200 uppercase tracking-wider truncate hover:text-emerald-400 transition-colors">
                      {mod.title}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className="text-[10px] text-slate-500 font-mono">
                      {mod.lessons.length}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleModule(mIdx);
                      }}
                      className="p-1 text-slate-400 hover:text-white cursor-pointer"
                      aria-label="Toggle module"
                    >
                      {isModuleOpen(mIdx) ? (
                        <ChevronDown className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                      )}
                    </button>
                  </div>
                </div>

                {isModuleOpen(mIdx) && (
                  <div>
                    {mod.lessons.map(lesson => {
                      const isActive = activeLesson?.id === lesson.id;
                      const isDone = isLessonCompleted(lesson.id);
                      const isLocked = !lesson.isFreePreview && !enrolled;
                      return (
                        <button
                          key={lesson.id}
                          onClick={() => handleLessonSelect(lesson)}
                          className={`w-full flex items-start gap-3 px-4 py-3 text-left transition-all cursor-pointer ${
                            isActive ? 'bg-emerald-500/10 border-l-2 border-emerald-500' : 'hover:bg-slate-800/50'
                          }`}
                        >
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                            isDone ? 'bg-emerald-500' : isLocked ? 'bg-slate-800 border border-slate-700' : 'border border-slate-700 bg-slate-800'
                          }`}>
                            {isDone ? (
                              <CheckCircle className="w-3 h-3 text-white" />
                            ) : isLocked ? (
                              <Lock className="w-2.5 h-2.5 text-slate-500" />
                            ) : (
                              <FileText className="w-2.5 h-2.5 text-slate-400" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className={`text-xs font-semibold leading-snug truncate ${
                              isActive ? colors.text : isLocked ? 'text-slate-400' : 'text-slate-300'
                            }`}>
                              {lesson.title}
                            </div>
                            <div className="text-[10px] text-slate-500 mt-0.5 flex items-center gap-2">
                              <span>{lesson.isQuiz ? 'Certification Exam' : 'Lesson & Quiz'}</span>
                              <span className="text-slate-600">·</span>
                              <span>{lesson.duration || '15 min'}</span>
                              {lesson.isFreePreview && <span className="text-emerald-400 font-bold ml-1">Free Preview</span>}
                              {isLocked && <span className="text-amber-400/90 font-semibold ml-1 flex items-center gap-0.5"><Lock className="w-2.5 h-2.5" /> Unlock</span>}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Quick PDF Action Card in Sidebar */}
          <div className="p-4 border-t border-slate-800 bg-slate-950 space-y-2">
            <button
              onClick={handleDownloadPdf}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 border border-slate-700"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              Download Full Blueprint PDF
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { CheckCircle, X, Award, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';

export const QuizEngine = ({ quizData, courseId, onComplete }) => {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  if (!quizData) return null;
  const { title, questions, passingScore } = quizData;

  const handleSelect = (qId, idx) => {
    if (submitted) return;
    setAnswers(prev => ({ ...prev, [qId]: idx }));
  };

  const handleSubmit = () => {
    let correct = 0;
    questions.forEach(q => { if (answers[q.id] === q.correctAnswer) correct++; });
    const pct = Math.round((correct / questions.length) * 100);
    setScore(pct);
    setSubmitted(true);
    if (pct >= passingScore) {
      try {
        confetti({ particleCount: 150, spread: 80, origin: { y: 0.5 }, colors: ['#22c55e', '#eab308', '#ffffff'] });
      } catch (e) {}
      if (onComplete) onComplete(pct, true);
    } else {
      if (onComplete) onComplete(pct, false);
    }
  };

  const handleRetry = () => {
    setAnswers({});
    setSubmitted(false);
    setScore(0);
  };

  const allAnswered = questions.every(q => answers[q.id] !== undefined);
  const passed = score >= passingScore;

  return (
    <div className="w-full max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
      <div className="p-5 border-b border-slate-800">
        <div className="text-xs text-amber-400 font-bold uppercase tracking-wider mb-1">📝 Course Quiz</div>
        <h3 className="text-base font-bold text-white">{title}</h3>
        <p className="text-xs text-slate-400 mt-1">Pass mark: {passingScore}% · {questions.length} questions</p>
      </div>

      {submitted ? (
        <div className="p-6 text-center space-y-4">
          <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${
            passed ? 'bg-emerald-500/20 border-2 border-emerald-500' : 'bg-rose-500/20 border-2 border-rose-500'
          }`}>
            {passed ? <Award className="w-8 h-8 text-emerald-400" /> : <X className="w-8 h-8 text-rose-400" />}
          </div>
          <div>
            <div className={`text-4xl font-black ${passed ? 'text-emerald-400' : 'text-rose-400'}`}>{score}%</div>
            <div className="text-white font-bold mt-1">{passed ? '🎉 Passed! Certificate Unlocked!' : 'Not Quite — Try Again'}</div>
            <div className="text-sm text-slate-400 mt-1">{passed ? 'Your completion certificate is now available on your dashboard.' : `You need ${passingScore}% to pass. Review the lesson notes and retry.`}</div>
          </div>

          {/* Review answers */}
          <div className="text-left space-y-3 mt-4">
            {questions.map((q, idx) => {
              const correct = answers[q.id] === q.correctAnswer;
              return (
                <div key={q.id} className={`p-3 rounded-xl border text-sm ${correct ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-rose-500/30 bg-rose-500/5'}`}>
                  <div className="flex items-start gap-2">
                    {correct ? <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" /> : <X className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />}
                    <div>
                      <div className="text-white font-medium">{q.question}</div>
                      <div className="text-xs text-slate-400 mt-1">✓ {q.options[q.correctAnswer]}</div>
                      <div className="text-xs text-slate-500 mt-1 italic">{q.explanation}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {!passed && (
            <button onClick={handleRetry} className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-sm font-semibold mx-auto transition-all">
              <RefreshCw className="w-4 h-4" /> Retry Quiz
            </button>
          )}
        </div>
      ) : (
        <div className="p-5 space-y-5">
          {questions.map((q, qIdx) => (
            <div key={q.id}>
              <div className="text-sm font-semibold text-white mb-3">
                <span className="text-slate-500 mr-2">Q{qIdx + 1}.</span>{q.question}
              </div>
              <div className="space-y-2">
                {q.options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => handleSelect(q.id, i)}
                    className={`w-full text-left px-4 py-2.5 rounded-xl border text-sm transition-all ${
                      answers[q.id] === i
                        ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300'
                        : 'border-slate-800 bg-slate-950 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="font-bold mr-2 text-slate-500">{String.fromCharCode(65 + i)}.</span>{opt}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <button
            onClick={handleSubmit}
            disabled={!allAnswered}
            className="w-full py-3 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-bold rounded-xl text-sm transition-all"
          >
            Submit Answers ({Object.keys(answers).length}/{questions.length} answered)
          </button>
        </div>
      )}
    </div>
  );
};

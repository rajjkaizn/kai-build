import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { WorkoutProvider } from './context/WorkoutContext';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { AuthModal } from './components/common/AuthModal';
import { CheckoutModal } from './components/common/CheckoutModal';
import { LandingPage } from './components/landing/LandingPage';
import { TrackSelector } from './components/landing/TrackSelector';
import { CourseCatalog } from './components/course/CourseCatalog';
import { CourseDetail } from './components/course/CourseDetail';
import { ClassroomPlayer } from './components/course/ClassroomPlayer';
import { PdfLibrary } from './components/course/PdfLibrary';
import { WorkoutTracker } from './components/tracker/WorkoutTracker';
import { NutritionCalculator } from './components/tracker/NutritionCalculator';
import { WeeklyProgram } from './components/tracker/WeeklyProgram';
import { WeeklyChecklist } from './components/tracker/WeeklyChecklist';
import { UserDashboard } from './components/dashboard/UserDashboard';

function AppInner() {
  const [currentView, setCurrentView] = useState('landing');
  const [selectedTrackId, setSelectedTrackId] = useState('build');
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [checkoutCourse, setCheckoutCourse] = useState(null);
  const [classroomCourse, setClassroomCourse] = useState(null);
  const [classroomLesson, setClassroomLesson] = useState(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [currentView, classroomCourse, classroomLesson]);

  const handleSelectTrack = (trackId) => {
    setSelectedTrackId(trackId);
  };

  const handleViewCourse = (course) => {
    setSelectedCourse(course);
    setCurrentView('courseDetail');
  };

  const handleOpenCheckout = (course) => {
    setCheckoutCourse(course);
  };

  const handleCheckoutSuccess = (course) => {
    setCheckoutCourse(null);
    setClassroomCourse(course);
    setClassroomLesson(null);
    setCurrentView('classroom');
  };

  const handleEnterClassroom = (course, lesson = null) => {
    setClassroomCourse(course);
    setClassroomLesson(lesson);
    setCurrentView('classroom');
  };

  const renderView = () => {
    switch (currentView) {
      case 'landing':
        return (
          <LandingPage
            onSelectTrack={(id) => { handleSelectTrack(id); setCurrentView('tracks'); }}
            onBrowseCourses={() => setCurrentView('curriculum')}
          />
        );
      case 'tracks':
        return (
          <TrackSelector
            selectedTrackId={selectedTrackId}
            onSelectTrack={handleSelectTrack}
            onViewCourse={handleViewCourse}
            setCurrentView={setCurrentView}
          />
        );
      case 'curriculum':
        return (
          <CourseCatalog
            selectedTrackId={selectedTrackId}
            onSelectTrack={handleSelectTrack}
            onViewCourse={handleViewCourse}
          />
        );
      case 'courseDetail':
        return (
          <CourseDetail
            course={selectedCourse}
            onBuy={handleOpenCheckout}
            onEnterClassroom={handleEnterClassroom}
            onBack={() => setCurrentView('curriculum')}
          />
        );
      case 'classroom':
        return (
          <ClassroomPlayer
            course={classroomCourse}
            initialLesson={classroomLesson}
            onBack={() => { setSelectedCourse(classroomCourse); setCurrentView('courseDetail'); }}
            onBuy={handleOpenCheckout}
          />
        );
      case 'tracker':
        return (
          <WorkoutTracker
            selectedTrackId={selectedTrackId}
          />
        );
      case 'nutrition':
        return <NutritionCalculator selectedTrackId={selectedTrackId} />;
      case 'program':
        return <WeeklyProgram selectedTrackId={selectedTrackId} />;
      case 'checklist':
        return <WeeklyChecklist selectedTrackId={selectedTrackId} />;
      case 'resources':
        return <PdfLibrary selectedTrackId={selectedTrackId} onSelectTrack={handleSelectTrack} />;
      case 'dashboard':
        return (
          <UserDashboard
            onEnterClassroom={handleEnterClassroom}
            onViewCourse={handleViewCourse}
            setCurrentView={setCurrentView}
          />
        );
      default:
        return <LandingPage onSelectTrack={(id) => { handleSelectTrack(id); setCurrentView('tracks'); }} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <Navbar
        currentView={currentView}
        setCurrentView={setCurrentView}
        onSelectTrack={handleSelectTrack}
        selectedTrack={selectedTrackId}
        extraNavItems={[
          { id: 'nutrition', label: '🍽️ Nutrition Calc' },
          { id: 'program', label: '📅 12-Week Plan' },
          { id: 'checklist', label: '✅ Weekly Checklist' },
        ]}
      />

      <main className="flex-1">
        {renderView()}
      </main>

      <Footer onSelectTrack={handleSelectTrack} setCurrentView={setCurrentView} />

      {/* Global Modals */}
      <AuthModal />
      {checkoutCourse && (
        <CheckoutModal
          course={checkoutCourse}
          isOpen={!!checkoutCourse}
          onClose={() => setCheckoutCourse(null)}
          onSuccess={handleCheckoutSuccess}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <WorkoutProvider>
        <AppInner />
      </WorkoutProvider>
    </AuthProvider>
  );
}

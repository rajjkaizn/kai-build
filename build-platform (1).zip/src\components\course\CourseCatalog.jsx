import React, { useState } from 'react';
import { TRACKS, COURSES } from '../../data/coursesData';
import { useAuth } from '../../context/AuthContext';
import { Star, Clock, Users, Play, Lock, Dumbbell, Flame, Zap, Trophy, ArrowRight } from 'lucide-react';

const TRACK_ICONS = { build: Dumbbell, cut: Flame, gain: Zap, powerlifting: Trophy };
const TRACK_COLORS = {
  build:        { label: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30' },
  cut:          { label: 'text-cyan-400',    bg: 'bg-cyan-500/10',    border: 'border-cyan-500/30' },
  gain:         { label: 'text-amber-400',   bg: 'bg-amber-500/10',   border: 'border-amber-500/30' },
  powerlifting: { label: 'text-purple-400',  bg: 'bg-purple-500/10',  border: 'border-purple-500/30' },
};

export const CourseCatalog = ({ selectedTrackId, onSelectTrack, onViewCourse }) => {
  const { user, isEnrolled } = useAuth();
  const [filter, setFilter] = useState('all');

  const filteredCourses = filter === 'all' ? COURSES : COURSES.filter(c => c.trackId === filter);

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-black text-white font-display mb-2">📚 All Training Programs</h1>
        <p className="text-slate-400">Browse every available course. Each includes the official 12-week workout plan PDF, tracker, nutrition calc, progression schedule & checklist.</p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2 mb-8">
        <button onClick={() => setFilter('all')}
          className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${filter === 'all' ? 'bg-slate-700 text-white' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'}`}>
          All Tracks
        </button>
        {TRACKS.map(t => {
          const Icon = TRACK_ICONS[t.id];
          const c = TRACK_COLORS[t.id];
          return (
            <button key={t.id} onClick={() => setFilter(t.id)}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                filter === t.id ? `${c.bg} ${c.label} border ${c.border}` : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}>
              <Icon className="w-4 h-4" />{t.id.toUpperCase()}
            </button>
          );
        })}
      </div>

      {/* Course Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredCourses.map(course => {
          const enrolled = isEnrolled(course.id);
          const color = TRACK_COLORS[course.trackId];
          const Icon = TRACK_ICONS[course.trackId];
          return (
            <div key={course.id} className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden hover:border-slate-700 transition-all group">
              {/* Thumbnail */}
              <div className="relative h-48 overflow-hidden">
                <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent" />
                <div className="absolute top-3 left-3 flex gap-2">
                  {course.badge && (
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${color.bg} ${color.label} border ${color.border}`}>
                      {course.badge}
                    </span>
                  )}
                  {enrolled && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500 text-slate-950">
                      ✓ ENROLLED
                    </span>
                  )}
                </div>
                <div className="absolute bottom-3 right-3 flex items-center gap-1 text-xs text-white bg-slate-950/70 px-2 py-1 rounded-lg">
                  <Clock className="w-3 h-3" />12-Week PDF · {course.lessonsCount} sections
                </div>
              </div>

              <div className="p-5">
                <div className={`flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider ${color.label} mb-2`}>
                  <Icon className="w-3.5 h-3.5" />{course.trackId} Track
                </div>
                <h3 className="text-base font-bold text-white mb-1 line-clamp-2 leading-snug">{course.title}</h3>
                <p className="text-xs text-slate-400 mb-3 line-clamp-2">{course.subtitle}</p>

                {/* Includes badges */}
                <div className="flex flex-wrap gap-1 mb-4">
                  {['📑 12-Week PDF', '🏋️ Routine Splits', '📊 Tracker', '🍽️ Nutrition', '📅 12-Week', '✅ Checklist'].map(tag => (
                    <span key={tag} className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">{tag}</span>
                  ))}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1 text-xs">
                      <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      <span className="font-bold text-white">{course.rating}</span>
                      <span className="text-slate-500">({course.reviewCount.toLocaleString()})</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-slate-400">
                      <Users className="w-3 h-3" />{course.enrolledCount.toLocaleString()}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-black text-white">₹{course.discountPrice}</span>
                    <span className="text-xs text-slate-500 line-through">₹{course.price}</span>
                  </div>
                </div>

                <button
                  onClick={() => onViewCourse(course)}
                  className="mt-4 w-full py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold rounded-xl text-sm transition-all flex items-center justify-center gap-2"
                >
                  {enrolled ? <><Play className="w-4 h-4 text-emerald-400" />Continue Learning</> : <>View Course <ArrowRight className="w-4 h-4" /></>}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Dumbbell, Flame, User, LogOut, FileText, Activity,
  ChevronDown, Menu, X, Calculator, Calendar, CheckSquare
} from 'lucide-react';
import { KaizenLogo } from './KaizenLogo';

export const Navbar = ({ currentView, setCurrentView, onSelectTrack, selectedTrack, extraNavItems = [] }) => {
  const { user, logout, openAuth } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navItems = [
    { id: 'landing', label: 'Home' },
    { id: 'tracks', label: 'Choose Track' },
    { id: 'curriculum', label: 'Courses' },
    { id: 'tracker', label: '💪 Workout Log' },
    { id: 'nutrition', label: '🍽️ Nutrition' },
    { id: 'program', label: '📅 12-Week Plan' },
    { id: 'checklist', label: '✅ Checklist' },
    { id: 'resources', label: '📄 PDF Library' },
  ];

  return (
    <nav className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-xl border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">

          {/* Brand */}
          <button onClick={() => setCurrentView('landing')} className="flex items-center gap-2.5 group hover:opacity-80 transition-opacity">
            <KaizenLogo />
          </button>

          {/* Desktop Nav */}
          <div className="hidden xl:flex items-center gap-0.5">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                  currentView === item.id
                    ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Right: Auth */}
          <div className="hidden md:flex items-center gap-2">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all"
                >
                  <img src={user.avatar} alt={user.name} className="w-7 h-7 rounded-full ring-2 ring-emerald-500/40 object-cover" />
                  <div className="text-left">
                    <div className="text-xs font-semibold text-white">{user.name.split(' ')[0]}</div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Flame className="w-3 h-3 text-amber-400" />{user.currentStreak}d streak
                    </div>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>
                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-52 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl py-2 z-50"
                    onMouseLeave={() => setUserDropdownOpen(false)}>
                    <div className="px-4 py-2 border-b border-slate-800 text-xs text-slate-400 truncate">{user.email}</div>
                    {[
                      { id: 'dashboard', icon: User, label: 'My Dashboard', color: 'text-emerald-400' },
                      { id: 'tracker', icon: Activity, label: 'Workout Log', color: 'text-cyan-400' },
                      { id: 'nutrition', icon: Calculator, label: 'Nutrition Calc', color: 'text-amber-400' },
                      { id: 'program', icon: Calendar, label: '12-Week Program', color: 'text-purple-400' },
                      { id: 'checklist', icon: CheckSquare, label: 'Weekly Checklist', color: 'text-rose-400' },
                      { id: 'resources', icon: FileText, label: 'PDF Library', color: 'text-slate-400' },
                    ].map(({ id, icon: Icon, label, color }) => (
                      <button key={id} onClick={() => { setCurrentView(id); setUserDropdownOpen(false); }}
                        className="w-full text-left px-4 py-2 text-xs text-slate-300 hover:bg-slate-800 flex items-center gap-2 transition-colors">
                        <Icon className={`w-3.5 h-3.5 ${color}`} />{label}
                      </button>
                    ))}
                    <div className="border-t border-slate-800 mt-1 pt-1">
                      <button onClick={() => { logout(); setUserDropdownOpen(false); }}
                        className="w-full text-left px-4 py-2 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2 transition-colors">
                        <LogOut className="w-3.5 h-3.5" />Log Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button onClick={() => openAuth('login')} className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white transition-colors">
                  Log In
                </button>
                <button onClick={() => openAuth('signup')}
                  className="px-4 py-2 text-xs font-bold text-slate-950 bg-emerald-500 hover:bg-emerald-400 rounded-lg shadow-lg shadow-emerald-500/20 transition-all">
                  Join Free
                </button>
              </div>
            )}
          </div>

          {/* Mobile Toggle */}
          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-800 bg-slate-950 px-4 pt-3 pb-6 space-y-1">
          {navItems.map((item) => (
            <button key={item.id} onClick={() => { setCurrentView(item.id); setMobileMenuOpen(false); }}
              className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium ${
                currentView === item.id ? 'bg-slate-900 text-emerald-400' : 'text-slate-300'
              }`}>
              {item.label}
            </button>
          ))}
          <div className="pt-3 border-t border-slate-800">
            {user ? (
              <>
                <button onClick={() => { setCurrentView('dashboard'); setMobileMenuOpen(false); }}
                  className="w-full text-left px-4 py-2.5 rounded-lg text-sm font-semibold text-emerald-400 bg-emerald-500/10">
                  My Dashboard ({user.name})
                </button>
                <button onClick={() => { logout(); setMobileMenuOpen(false); }}
                  className="w-full text-left px-4 py-2 mt-1 text-sm text-rose-400">
                  Log Out
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-2 mt-2">
                <button onClick={() => { openAuth('login'); setMobileMenuOpen(false); }}
                  className="py-2.5 text-center rounded-xl bg-slate-900 border border-slate-800 text-white text-sm font-medium">
                  Log In
                </button>
                <button onClick={() => { openAuth('signup'); setMobileMenuOpen(false); }}
                  className="py-2.5 text-center rounded-xl bg-emerald-500 text-slate-950 text-sm font-bold">
                  Join Free
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

import React, { useState } from 'react';
import { TRACKS } from '../../data/coursesData';
import { Dumbbell, Flame, Zap, Trophy, RefreshCw } from 'lucide-react';

const TRACK_ICONS = { build: Dumbbell, cut: Flame, gain: Zap, powerlifting: Trophy };
const TRACK_COLORS = {
  build: { label: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', btn: 'bg-emerald-500 hover:bg-emerald-400' },
  cut: { label: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20', btn: 'bg-cyan-500 hover:bg-cyan-400' },
  gain: { label: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20', btn: 'bg-amber-500 hover:bg-amber-400' },
  powerlifting: { label: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20', btn: 'bg-purple-500 hover:bg-purple-400' },
};

const GOALS = {
  build: { name: 'Build (Hypertrophy)', surplusPct: 10, proteinPerKg: 2.0, fatPerKg: 1.0, note: 'Lean surplus: +10% above maintenance. Keep protein high to maximise MPS.' },
  cut: { name: 'Cut (Fat Loss)', surplusPct: -20, proteinPerKg: 2.2, fatPerKg: 0.8, note: 'Moderate deficit: –20% from maintenance. High protein protects muscle during the cut.' },
  gain: { name: 'Gain (Clean Bulk)', surplusPct: 15, proteinPerKg: 1.8, fatPerKg: 1.2, note: 'Aggressive surplus: +15% above maintenance. Focus on calorie-dense, easily digestible foods.' },
  powerlifting: { name: 'Powerlifting (Strength)', surplusPct: 5, proteinPerKg: 1.8, fatPerKg: 1.0, note: 'Slight surplus or maintenance. Prioritise performance and recovery over aesthetics.' },
};

const ACTIVITY_MULTIPLIERS = [
  { label: 'Sedentary (desk job, no exercise)', value: 1.2 },
  { label: 'Light (1–3 workouts/week)', value: 1.375 },
  { label: 'Moderate (4–5 workouts/week)', value: 1.55 },
  { label: 'Active (6–7 workouts/week)', value: 1.725 },
  { label: 'Very Active (2× daily / athlete)', value: 1.9 },
];

export const NutritionCalculator = ({ selectedTrackId }) => {
  const [trackId, setTrackId] = useState(selectedTrackId || 'build');
  const [form, setForm] = useState({ weight: '', height: '', age: '', sex: 'male', activity: 1.55 });
  const [result, setResult] = useState(null);

  const color = TRACK_COLORS[trackId] || TRACK_COLORS.build;
  const goal = GOALS[trackId];

  const calc = () => {
    const w = parseFloat(form.weight);
    const h = parseFloat(form.height);
    const a = parseInt(form.age);
    if (!w || !h || !a) return;

    const bmr = form.sex === 'male'
      ? 10 * w + 6.25 * h - 5 * a + 5
      : 10 * w + 6.25 * h - 5 * a - 161;

    const maintenance = Math.round(bmr * parseFloat(form.activity));
    const target = Math.round(maintenance * (1 + goal.surplusPct / 100));
    const protein = Math.round(w * goal.proteinPerKg);
    const fat = Math.round(w * goal.fatPerKg);
    const proteinCals = protein * 4;
    const fatCals = fat * 9;
    const carbCals = Math.max(0, target - proteinCals - fatCals);
    const carbs = Math.round(carbCals / 4);

    setResult({ maintenance, target, protein, fat, carbs, bmr: Math.round(bmr) });
  };

  const reset = () => { setResult(null); setForm({ weight: '', height: '', age: '', sex: 'male', activity: 1.55 }); };

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <div className="mb-6">
        <h1 className="text-3xl font-black text-white font-display">🍽️ Nutrition Calculator</h1>
        <p className="text-slate-400 text-sm mt-1">Get your personalised calories, protein, carbs & fat targets for your selected goal.</p>
      </div>

      {/* Track Selector */}
      <div className="flex flex-wrap gap-2 mb-6">
        {TRACKS.map(t => {
          const Icon = TRACK_ICONS[t.id];
          const c = TRACK_COLORS[t.id];
          return (
            <button key={t.id} onClick={() => { setTrackId(t.id); setResult(null); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold uppercase border transition-all ${
                trackId === t.id ? `${c.bg} ${c.label} ${c.border}` : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}>
              <Icon className="w-3.5 h-3.5" />{t.id}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
          <div className={`p-3 rounded-xl ${color.bg} border ${color.border}`}>
            <div className={`text-xs font-bold uppercase tracking-wider ${color.label} mb-0.5`}>{goal.name}</div>
            <div className="text-xs text-slate-400">{goal.note}</div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { key: 'weight', label: 'Bodyweight (kg)', placeholder: '75' },
              { key: 'height', label: 'Height (cm)', placeholder: '175' },
              { key: 'age', label: 'Age (years)', placeholder: '25' },
            ].map(f => (
              <div key={f.key} className={f.key === 'age' ? '' : ''}>
                <label className="text-xs text-slate-400 mb-1 block">{f.label}</label>
                <input type="number" placeholder={f.placeholder} value={form[f.key]}
                  onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500" />
              </div>
            ))}

            <div>
              <label className="text-xs text-slate-400 mb-1 block">Sex</label>
              <select value={form.sex} onChange={e => setForm(p => ({ ...p, sex: e.target.value }))}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-300 focus:outline-none focus:border-emerald-500">
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-400 mb-1 block">Activity Level</label>
            <select value={form.activity} onChange={e => setForm(p => ({ ...p, activity: e.target.value }))}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-300 focus:outline-none focus:border-emerald-500">
              {ACTIVITY_MULTIPLIERS.map(m => (
                <option key={m.value} value={m.value}>{m.label}</option>
              ))}
            </select>
          </div>

          <div className="flex gap-3">
            <button onClick={calc} className={`flex-1 py-3 ${color.btn} text-slate-950 font-bold rounded-xl text-sm transition-all`}>
              Calculate My Targets
            </button>
            {result && (
              <button onClick={reset} className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl text-sm transition-all">
                <RefreshCw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Results */}
        {result ? (
          <div className="space-y-4">
            {/* Calorie targets */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <h3 className="text-sm font-bold text-white">📊 Your Daily Calorie Targets</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                  <div className="text-xs text-slate-400 mb-1">BMR (Base)</div>
                  <div className="text-xl font-black text-slate-300">{result.bmr.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-500">kcal / day</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                  <div className="text-xs text-slate-400 mb-1">TDEE (Maintenance)</div>
                  <div className="text-xl font-black text-slate-300">{result.maintenance.toLocaleString()}</div>
                  <div className="text-[10px] text-slate-500">kcal / day</div>
                </div>
              </div>
              <div className={`p-4 rounded-xl ${color.bg} border ${color.border} text-center`}>
                <div className="text-xs text-slate-400 mb-1">🎯 Your {goal.name} Target</div>
                <div className={`text-4xl font-black ${color.label}`}>{result.target.toLocaleString()}</div>
                <div className="text-xs text-slate-400 mt-1">kcal / day ({goal.surplusPct > 0 ? '+' : ''}{goal.surplusPct}% from maintenance)</div>
              </div>
            </div>

            {/* Macros */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <h3 className="text-sm font-bold text-white mb-4">🥩 Daily Macro Targets</h3>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { macro: 'Protein', g: result.protein, kcal: result.protein * 4, color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', pct: Math.round((result.protein * 4 / result.target) * 100) },
                  { macro: 'Carbs', g: result.carbs, kcal: result.carbs * 4, color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20', pct: Math.round((result.carbs * 4 / result.target) * 100) },
                  { macro: 'Fat', g: result.fat, kcal: result.fat * 9, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20', pct: Math.round((result.fat * 9 / result.target) * 100) },
                ].map(m => (
                  <div key={m.macro} className={`p-3 rounded-xl ${m.bg} border ${m.border} text-center`}>
                    <div className={`text-2xl font-black ${m.color}`}>{m.g}g</div>
                    <div className="text-xs text-white font-bold">{m.macro}</div>
                    <div className="text-[10px] text-slate-400">{m.kcal} kcal · {m.pct}%</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Adjustment Rules */}
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">⚙️ Adjustment Rules</h3>
              {[
                { rule: 'Not losing weight for 2 weeks (CUT):', action: 'Reduce by 150–200 kcal, preferably from carbs.' },
                { rule: 'Gaining too fast / too much fat (BUILD):', action: 'Cut surplus by 100 kcal and monitor for 2 weeks.' },
                { rule: 'Strength dropping significantly (CUT):', action: 'Add a 24h carb refeed day, keep protein at target.' },
                { rule: 'Not gaining weight (GAIN):', action: 'Add 250 kcal from liquid carbs (oats in shake) for 2 weeks.' },
              ].map(r => (
                <div key={r.rule} className="text-xs">
                  <span className="text-slate-300 font-semibold">{r.rule}</span>
                  <span className="text-slate-400"> {r.action}</span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-64 rounded-2xl bg-slate-900/50 border border-dashed border-slate-800 text-slate-500 text-sm">
            Fill in your stats and click Calculate →
          </div>
        )}
      </div>
    </div>
  );
};

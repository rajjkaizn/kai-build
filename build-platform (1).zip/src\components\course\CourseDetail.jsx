import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  Star, Users, Clock, Award, Shield, Check, Lock,
  ChevronDown, ChevronRight, FileText, ArrowLeft, Play, Download, Dumbbell, Sparkles
} from 'lucide-react';
import { PowerliftingProgramSelector } from './PowerliftingProgramSelector';

const TRACK_COLORS = {
  build: { label: 'text-emerald-400', badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', btn: 'bg-emerald-500 hover:bg-emerald-400' },
  cut: { label: 'text-cyan-400', badge: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20', btn: 'bg-cyan-500 hover:bg-cyan-400' },
  gain: { label: 'text-amber-400', badge: 'bg-amber-500/10 text-amber-400 border-amber-500/20', btn: 'bg-amber-500 hover:bg-amber-400' },
  powerlifting: { label: 'text-purple-400', badge: 'bg-purple-500/10 text-purple-400 border-purple-500/20', btn: 'bg-purple-500 hover:bg-purple-400' },
  bundle: { label: 'text-emerald-400', badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', btn: 'bg-emerald-500 hover:bg-emerald-400' },
};

export const CourseDetail = ({ course, onBuy, onEnterClassroom, onBack }) => {
  const { isEnrolled } = useAuth();
  const enrolled = isEnrolled(course?.id) || isEnrolled('course-bundle-all');
  const [closedModules, setClosedModules] = useState({});
  const isModuleOpen = (mIdx) => !closedModules[mIdx];
  const toggleModule = (mIdx) => {
    setClosedModules(prev => ({ ...prev, [mIdx]: !prev[mIdx] }));
  };

  if (!course) return null;

  const color = TRACK_COLORS[course.trackId] || TRACK_COLORS.build;
  const totalLessons = course.modules?.reduce((acc, m) => acc + m.lessons.length, 0) || 0;

  const allOpen = course.modules ? course.modules.every((_, idx) => !closedModules[idx]) : true;
  const toggleAllModules = () => {
    if (allOpen) {
      const closed = {};
      course.modules?.forEach((_, idx) => { closed[idx] = true; });
      setClosedModules(closed);
    } else {
      setClosedModules({});
    }
  };

  const handleEnrollAction = () => {
    if (enrolled) {
      onEnterClassroom(course);
    } else {
      onBuy(course);
    }
  };

  const handleLessonClick = (lesson) => {
    if (lesson.isFreePreview || enrolled) {
      onEnterClassroom(course, lesson);
    } else {
      onBuy(course);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Back button */}
      <button onClick={onBack} className="flex items-center gap-2 text-xs text-slate-400 hover:text-white transition-colors mb-6 group">
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        Back to Courses
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* ── LEFT: Main Info ── */}
        <div className="lg:col-span-2 space-y-8">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className={`text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${color.badge}`}>
                {course.badge || `${course.trackId} track`}
              </span>
              <span className="text-xs text-slate-400">{course.level || 'All Levels'}</span>
              <span className="text-xs text-slate-500">·</span>
              <span className="text-xs text-slate-400">{course.durationHours} Hours Total Content</span>
            </div>

            {enrolled && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold mb-3">
                <Check className="w-3.5 h-3.5" /> Enrolled &amp; Unlocked
              </div>
            )}
            <h1 className="text-2xl sm:text-3xl font-black text-white font-display leading-tight mt-2">{course.title}</h1>
            <p className="text-slate-300 mt-2 leading-relaxed">{course.subtitle}</p>

            <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-slate-400">
              <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" /><span className="text-white font-bold">{course.rating}</span> ({course.reviewCount.toLocaleString()} reviews)</span>
              <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{course.enrolledCount.toLocaleString()} enrolled</span>
              <span className="flex items-center gap-1"><FileText className="w-3.5 h-3.5 text-emerald-400" />12-Week Official Blueprint · {totalLessons} Lessons</span>
              <span>Updated {course.lastUpdated}</span>
            </div>
          </div>

          {/* Instructor */}
          <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
            <img src={course.instructor.avatar} alt={course.instructor.name} className="w-14 h-14 rounded-xl object-cover ring-2 ring-slate-700" />
            <div className="flex-1">
              <div className="text-sm font-bold text-white">{course.instructor.name}</div>
              <div className="text-xs text-slate-400 mb-1">{course.instructor.role}</div>
              <p className="text-xs text-slate-500 leading-relaxed">{course.instructor.bio}</p>
            </div>
          </div>

          {/* What's Included */}
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800">
            <h2 className="text-sm font-bold text-white mb-4">📦 Everything Included in This Program</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                { icon: '📑', label: 'Complete 12-Week Workout Program PDF' },
                { icon: '🏋️', label: 'Exact weekly splits, sets, reps & coaching cues' },
                { icon: '📊', label: 'Workout tracker: sets · reps · weight · RIR' },
                { icon: '🍽️', label: 'Nutrition calculator & macro deficit/surplus guide' },
                { icon: '📅', label: 'Structured periodization & double progression rules' },
                { icon: '✅', label: 'Weekly habit & recovery progress checklist' },
                { icon: '📄', label: 'Printable tracking sheets & PDF Resource Vault' },
                { icon: '🏆', label: 'Official certificate of completion' },
              ].map(f => (
                <div key={f.label} className="flex items-start gap-2 text-sm text-slate-300">
                  <span className="text-base leading-5">{f.icon}</span>
                  <span>{f.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Special Powerlifting Programs Preview */}
          {course.trackId === 'powerlifting' && (
            <div className="p-5 rounded-2xl bg-purple-950/20 border border-purple-500/30">
              <div className="mb-4">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 border border-purple-500/30 uppercase tracking-wider">
                  Selectable Programs
                </span>
                <h3 className="text-base font-bold text-white mt-1">
                  Choose Your SBD Focus (1 Included + ₹50 Each Additional)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Each option corresponds to an authentic, periodized PDF program blueprint.
                </p>
              </div>
              <PowerliftingProgramSelector mode="checkout" />
            </div>
          )}

          {/* Curriculum Accordion */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <span>📚 Program Modules &amp; Complete Curriculum</span>
                <span className="text-xs font-normal text-slate-400">({course.modules?.length} Modules · {totalLessons} Lessons)</span>
              </h2>
              <button
                onClick={toggleAllModules}
                className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
              >
                {allOpen ? 'Collapse All' : 'Expand All'}
              </button>
            </div>

            <div className="space-y-3">
              {course.modules?.map((mod, mIdx) => (
                <div key={mod.id} className="rounded-xl border border-slate-800 overflow-hidden bg-slate-900 shadow-sm">
                  <div
                    onClick={() => toggleModule(mIdx)}
                    className="w-full flex items-center justify-between p-4 text-left hover:bg-slate-800/50 transition-colors cursor-pointer"
                  >
                    <div className="flex-1 pr-4">
                      <div className="text-sm font-bold text-white flex items-center gap-2">
                        <span>{mod.title}</span>
                      </div>
                      <div className="text-xs text-slate-400 mt-0.5">
                        {mod.lessons.length} lessons · Complete Educational Readings &amp; Quizzes
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (enrolled || mod.lessons?.[0]?.isFreePreview) {
                            onEnterClassroom(course, mod.lessons[0]);
                          } else {
                            onBuy(course);
                          }
                        }}
                        className={`text-xs font-bold px-3 py-1.5 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                          enrolled || mod.lessons?.[0]?.isFreePreview
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-sm shadow-emerald-500/20'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                        }`}
                      >
                        {enrolled ? (
                          <>Open Module <ChevronRight className="w-3.5 h-3.5" /></>
                        ) : mod.lessons?.[0]?.isFreePreview ? (
                          <>Free Preview <ChevronRight className="w-3.5 h-3.5" /></>
                        ) : (
                          <><Lock className="w-3.5 h-3.5 text-slate-400" /> Unlock Module</>
                        )}
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleModule(mIdx);
                        }}
                        className="p-1 text-slate-400 hover:text-white cursor-pointer"
                        aria-label="Toggle module"
                      >
                        {isModuleOpen(mIdx) ? <ChevronDown className="w-4 h-4 text-emerald-400" /> : <ChevronRight className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {isModuleOpen(mIdx) && (
                    <div className="border-t border-slate-800 bg-slate-950/40">
                      {mod.lessons.map((lesson, lIdx) => (
                        <button
                          key={lesson.id}
                          onClick={() => handleLessonClick(lesson)}
                          className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-slate-800/40 transition-colors border-b border-slate-800/50 last:border-0 group cursor-pointer"
                        >
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            lesson.isFreePreview || enrolled
                              ? 'bg-emerald-500/10 border border-emerald-500/20 group-hover:bg-emerald-500/20'
                              : 'bg-slate-800/80 border border-slate-700/60'
                          } transition-colors`}>
                            {lesson.isFreePreview || enrolled
                              ? <FileText className={`w-3.5 h-3.5 ${color.label}`} />
                              : <Lock className="w-3.5 h-3.5 text-slate-500" />
                            }
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className={`text-sm font-medium truncate transition-colors ${
                              lesson.isFreePreview || enrolled ? 'text-white group-hover:text-emerald-400' : 'text-slate-300'
                            }`}>
                              {lesson.title}
                            </div>
                            <div className="flex items-center gap-2 text-xs text-slate-400">
                              <span>{lesson.isQuiz ? 'Certification Exam' : 'Educational Lesson Guide & Quiz'}</span>
                              <span className="text-slate-600">·</span>
                              <span className="text-slate-500">{lesson.duration || '15 min'}</span>
                              {lesson.isFreePreview && <span className="text-emerald-400 font-bold ml-1">Free Preview</span>}
                            </div>
                          </div>
                          <div className="text-xs font-semibold text-slate-500 group-hover:text-emerald-400 flex items-center gap-1 transition-colors">
                            <span>{lesson.isFreePreview || enrolled ? 'Read' : 'Unlock'}</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── RIGHT: Sticky Checkout ── */}
        <div className="lg:col-span-1">
          <div className="sticky top-20 space-y-4">
            <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden">
              <div className="relative">
                <img src={course.thumbnail} alt={course.title} className="w-full h-44 object-cover" />
                <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-sm px-2.5 py-1 rounded-md text-[11px] font-bold text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                  <FileText className="w-3 h-3" /> Official PDF Included
                </div>
              </div>

              <div className="p-5 space-y-4">
                {!enrolled ? (
                  <>
                    <div className="flex items-baseline gap-3">
                      <span className="text-3xl font-black text-white">₹{course.discountPrice}</span>
                      <span className="text-slate-500 line-through">₹{course.price}</span>
                      <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">50% OFF</span>
                    </div>

                    <div className="text-xs text-rose-400 font-semibold text-center bg-rose-500/10 border border-rose-500/20 rounded-lg py-1.5">
                      ⏳ Limited-time launch price — ends soon
                    </div>

                    <button
                      onClick={handleEnrollAction}
                      className={`w-full py-3.5 ${color.btn} text-slate-950 font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2 border-beam-btn`}
                    >
                      Get Instant Access <ChevronRight className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => onEnterClassroom(course)}
                    className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2"
                  >
                    <Play className="w-4 h-4" /> Enter Classroom &amp; Lessons
                  </button>
                )}

                {/* Quick Links */}
                <div className="space-y-2 pt-2 border-t border-slate-800/60">
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">Track Resources:</div>
                  <div className="text-xs text-slate-300 flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5 text-emerald-400" />
                    <span>28 Substantive In-Depth Lessons</span>
                  </div>
                  <div className="text-xs text-slate-300 flex items-center gap-2">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    <span>28 Knowledge Assessment Quizzes</span>
                  </div>
                  <div className="text-xs text-slate-300 flex items-center gap-2">
                    <Dumbbell className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Official 12-Week Printable PDF Blueprint</span>
                  </div>
                </div>

                <div className="border-t border-slate-800 pt-3 text-center space-y-1">
                  <div className="flex justify-center gap-4 text-[11px] text-slate-500">
                    <span className="flex items-center gap-1"><Shield className="w-3.5 h-3.5 text-emerald-400" />30-day refund</span>
                    <span className="flex items-center gap-1"><Award className="w-3.5 h-3.5 text-amber-400" />Official Certificate</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

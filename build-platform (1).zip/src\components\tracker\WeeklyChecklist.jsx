import React, { useState, useEffect } from 'react';
import { TRACKS } from '../../data/coursesData';
import { Dumbbell, Flame, Zap, Trophy, CheckSquare, Square, RefreshCw } from 'lucide-react';

const TRACK_ICONS = { build: Dumbbell, cut: Flame, gain: Zap, powerlifting: Trophy };
const TRACK_COLORS = {
  build: { label: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', check: 'text-emerald-400' },
  cut: { label: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20', check: 'text-cyan-400' },
  gain: { label: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20', check: 'text-amber-400' },
  powerlifting: { label: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20', check: 'text-purple-400' },
};

const WEEKLY_CHECKLIST_ITEMS = {
  build: [
    { id: 'b_w1', category: '🏋️ Workouts', label: 'Complete Upper Push session' },
    { id: 'b_w2', category: '🏋️ Workouts', label: 'Complete Upper Pull session' },
    { id: 'b_w3', category: '🏋️ Workouts', label: 'Complete Lower Quad session' },
    { id: 'b_w4', category: '🏋️ Workouts', label: 'Complete Lower Posterior session' },
    { id: 'b_n1', category: '🍽️ Nutrition', label: 'Hit protein target (2.0g/kg) every day' },
    { id: 'b_n2', category: '🍽️ Nutrition', label: 'Maintained caloric surplus all week' },
    { id: 'b_n3', category: '🍽️ Nutrition', label: 'Ate pre-workout carbs 60 min before each session' },
    { id: 'b_r1', category: '😴 Recovery', label: 'Averaged 7.5+ hours of sleep per night' },
    { id: 'b_r2', category: '😴 Recovery', label: 'Completed mobility / stretching on rest days' },
    { id: 'b_p1', category: '📈 Progress', label: 'Logged all sets, reps, and weights in tracker' },
    { id: 'b_p2', category: '📈 Progress', label: 'Achieved progressive overload on at least 2 lifts' },
    { id: 'b_p3', category: '📈 Progress', label: 'Logged morning bodyweight (3 readings, averaged)' },
    { id: 'b_c1', category: '📚 Course', label: 'Watched at least 1 new lesson video' },
    { id: 'b_c2', category: '📚 Course', label: 'Reviewed form tips for upcoming week exercises' },
  ],
  cut: [
    { id: 'c_w1', category: '🏋️ Workouts', label: 'Completed 4 lifting sessions (heavy, short rest)' },
    { id: 'c_w2', category: '🏋️ Workouts', label: 'Completed 3× 25-min incline LISS cardio sessions' },
    { id: 'c_w3', category: '🏋️ Workouts', label: 'Averaged 10,000+ steps per day (NEAT target)' },
    { id: 'c_n1', category: '🍽️ Nutrition', label: 'Stayed within calorie target every day' },
    { id: 'c_n2', category: '🍽️ Nutrition', label: 'Hit protein target (2.2g/kg) every day' },
    { id: 'c_n3', category: '🍽️ Nutrition', label: 'No unplanned cheat meals or binging episodes' },
    { id: 'c_n4', category: '🍽️ Nutrition', label: 'Executed refeed day correctly (carbs high, fat low)' },
    { id: 'c_r1', category: '😴 Recovery', label: 'Slept 7.5+ hours average (prioritised on heavy days)' },
    { id: 'c_p1', category: '📈 Progress', label: 'Logged daily scale weight (morning, fasted)' },
    { id: 'c_p2', category: '📈 Progress', label: 'Week-on-week average weight shows 0.5–1% decrease' },
    { id: 'c_p3', category: '📈 Progress', label: 'Weekly progress photos taken (morning, same lighting)' },
    { id: 'c_c1', category: '📚 Course', label: 'Reviewed nutrition module lesson' },
  ],
  gain: [
    { id: 'g_w1', category: '🏋️ Workouts', label: 'Completed 4 heavy compound sessions' },
    { id: 'g_w2', category: '🏋️ Workouts', label: 'Hit progressive overload on main lifts (added load or reps)' },
    { id: 'g_n1', category: '🍽️ Nutrition', label: 'Hit full calorie surplus target EVERY day (no exceptions)' },
    { id: 'g_n2', category: '🍽️ Nutrition', label: 'Consumed at least 1 mass shake on each training day' },
    { id: 'g_n3', category: '🍽️ Nutrition', label: 'Hit 4+ meals / feeding windows per day' },
    { id: 'g_n4', category: '🍽️ Nutrition', label: 'Used easy-digest carbs (rice, oats, potato) not high-fat' },
    { id: 'g_r1', category: '😴 Recovery', label: 'Achieved 8+ hours of sleep (growth hormone peak)' },
    { id: 'g_r2', category: '😴 Recovery', label: 'Limited cardio to 2× 20-min walks (no excess calorie burn)' },
    { id: 'g_p1', category: '📈 Progress', label: 'Week-over-week body weight is trending up (0.3–0.6 kg)' },
    { id: 'g_p2', category: '📈 Progress', label: 'Logged all workout volumes in tracker' },
    { id: 'g_c1', category: '📚 Course', label: 'Completed at least 1 course video lesson' },
  ],
  powerlifting: [
    { id: 'p_w1', category: '🏋️ Workouts', label: 'Completed Competition Squat session (correct stance)' },
    { id: 'p_w2', category: '🏋️ Workouts', label: 'Completed Competition Bench session (legal pause)' },
    { id: 'p_w3', category: '🏋️ Workouts', label: 'Completed Competition Deadlift session (competition setup)' },
    { id: 'p_w4', category: '🏋️ Workouts', label: 'Completed Accessories session (close-grip, SSB, RDL)' },
    { id: 'p_w5', category: '🏋️ Workouts', label: 'Filmed at least 1 set of each main lift for form review' },
    { id: 'p_n1', category: '🍽️ Nutrition', label: 'Hit protein target (1.8g/kg bodyweight)' },
    { id: 'p_n2', category: '🍽️ Nutrition', label: 'Carb-loaded before every main session' },
    { id: 'p_r1', category: '😴 Recovery', label: 'Averaged 8+ hours of sleep (CNS recovery critical)' },
    { id: 'p_r2', category: '😴 Recovery', label: 'Active recovery day: walks, light band work, stretching' },
    { id: 'p_p1', category: '📈 Progress', label: 'All RPE targets met or exceeded for the week' },
    { id: 'p_p2', category: '📈 Progress', label: 'Calculated projected 1RM from working sets' },
    { id: 'p_c1', category: '📚 Course', label: 'Reviewed biomechanics lesson (bar path, cues)' },
  ],
};

const STORAGE_KEY = 'kaizen_checklist';

export const WeeklyChecklist = ({ selectedTrackId }) => {
  const [trackId, setTrackId] = useState(selectedTrackId || 'build');
  const [checked, setChecked] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; } catch { return {}; }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(checked));
  }, [checked]);

  const color = TRACK_COLORS[trackId] || TRACK_COLORS.build;
  const items = WEEKLY_CHECKLIST_ITEMS[trackId] || [];

  const toggle = (id) => setChecked(prev => ({ ...prev, [id]: !prev[id] }));
  const resetTrack = () => {
    const reset = { ...checked };
    items.forEach(item => { delete reset[item.id]; });
    setChecked(reset);
  };

  const totalChecked = items.filter(i => checked[i.id]).length;
  const pct = items.length > 0 ? Math.round((totalChecked / items.length) * 100) : 0;

  // Group by category
  const grouped = items.reduce((acc, item) => {
    if (!acc[item.category]) acc[item.category] = [];
    acc[item.category].push(item);
    return acc;
  }, {});

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <div className="mb-6">
        <h1 className="text-3xl font-black text-white font-display">✅ Weekly Checklist</h1>
        <p className="text-slate-400 text-sm mt-1">Track your weekly habits across workouts, nutrition, recovery, progress, and course content.</p>
      </div>

      {/* Track Selector */}
      <div className="flex flex-wrap gap-2 mb-6">
        {TRACKS.map(t => {
          const Icon = TRACK_ICONS[t.id];
          const c = TRACK_COLORS[t.id];
          return (
            <button key={t.id} onClick={() => setTrackId(t.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold uppercase border transition-all ${
                trackId === t.id ? `${c.bg} ${c.label} ${c.border}` : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}>
              <Icon className="w-3.5 h-3.5" />{t.id}
            </button>
          );
        })}
      </div>

      {/* Progress Ring */}
      <div className={`p-5 rounded-2xl ${color.bg} border ${color.border} mb-6 flex items-center gap-5`}>
        <div className="relative w-20 h-20 flex-shrink-0">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
            <circle cx="18" cy="18" r="15.915" fill="none" stroke="#1e293b" strokeWidth="3" />
            <circle cx="18" cy="18" r="15.915" fill="none" strokeWidth="3"
              className={color.label.replace('text-', 'stroke-')}
              strokeDasharray={`${pct} ${100 - pct}`}
              strokeLinecap="round" />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className={`text-lg font-black ${color.label}`}>{pct}%</span>
          </div>
        </div>
        <div className="flex-1">
          <div className="text-white font-bold text-base">{totalChecked} / {items.length} items completed</div>
          <div className="text-sm text-slate-400 mt-0.5">
            {pct === 100 ? '🎉 Perfect week! Incredible consistency.' :
             pct >= 80 ? '🔥 Great week! Nearly perfect.' :
             pct >= 50 ? '💪 Solid progress. Finish strong!' :
             'Get started — tick off your habits one by one.'}
          </div>
        </div>
        <button onClick={resetTrack} className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs text-slate-400 hover:text-white transition-all">
          <RefreshCw className="w-3.5 h-3.5" /> Reset Week
        </button>
      </div>

      {/* Checklist by category */}
      <div className="space-y-4">
        {Object.entries(grouped).map(([category, catItems]) => {
          const catChecked = catItems.filter(i => checked[i.id]).length;
          return (
            <div key={category} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
              <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
                <span className="text-xs font-bold text-white">{category}</span>
                <span className="text-[11px] text-slate-400">{catChecked}/{catItems.length}</span>
              </div>
              <div className="divide-y divide-slate-800/50">
                {catItems.map(item => {
                  const isChecked = !!checked[item.id];
                  return (
                    <button
                      key={item.id}
                      onClick={() => toggle(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-all ${
                        isChecked ? 'bg-emerald-500/5' : 'hover:bg-slate-800/30'
                      }`}
                    >
                      {isChecked
                        ? <CheckSquare className={`w-5 h-5 flex-shrink-0 ${color.check}`} />
                        : <Square className="w-5 h-5 flex-shrink-0 text-slate-600" />
                      }
                      <span className={`text-sm transition-colors ${isChecked ? 'text-slate-400 line-through' : 'text-slate-200'}`}>
                        {item.label}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

import React, { createContext, useContext, useState, useEffect } from 'react';
import { WORKOUT_TEMPLATES, INITIAL_PROGRESS_LOGS } from '../data/sampleWorkouts';

const WorkoutContext = createContext(null);

export const WorkoutProvider = ({ children }) => {
  const [selectedTrack, setSelectedTrack] = useState('build');
  const [activeWorkout, setActiveWorkout] = useState(null);
  
  const [progressLogs, setProgressLogs] = useState(() => {
    try {
      const saved = localStorage.getItem('kaizen_progress_logs');
      return saved ? JSON.parse(saved) : INITIAL_PROGRESS_LOGS;
    } catch (e) {
      return INITIAL_PROGRESS_LOGS;
    }
  });

  const [completedWorkouts, setCompletedWorkouts] = useState(() => {
    try {
      const saved = localStorage.getItem('kaizen_completed_workouts');
      return saved ? JSON.parse(saved) : [
        {
          id: 'cw-1',
          date: '2026-08-15',
          workoutName: 'Day 1: Upper Hypertrophy',
          trackId: 'build',
          durationMinutes: 58,
          exercisesLogged: 5,
          totalVolumeKg: 4280
        }
      ];
    } catch (e) {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('kaizen_progress_logs', JSON.stringify(progressLogs));
  }, [progressLogs]);

  useEffect(() => {
    localStorage.setItem('kaizen_completed_workouts', JSON.stringify(completedWorkouts));
  }, [completedWorkouts]);

  const addBodyweightEntry = (entry) => {
    const newEntry = {
      date: entry.date || new Date().toISOString().split('T')[0],
      weight: parseFloat(entry.weight),
      bodyFat: entry.bodyFat ? parseFloat(entry.bodyFat) : null,
      track: selectedTrack,
      notes: entry.notes || ''
    };
    setProgressLogs(prev => [newEntry, ...prev]);
  };

  const saveCompletedWorkout = (workoutData) => {
    const newRecord = {
      id: 'cw-' + Date.now(),
      date: new Date().toISOString().split('T')[0],
      ...workoutData
    };
    setCompletedWorkouts(prev => [newRecord, ...prev]);
  };

  // Epley and Brzycki 1RM Estimation
  const calculate1RM = (weight, reps) => {
    if (!weight || !reps || reps <= 0) return { epley: 0, brzycki: 0, rounded: 0 };
    const w = parseFloat(weight);
    const r = parseInt(reps, 10);
    if (r === 1) return { epley: w, brzycki: w, rounded: Math.round(w) };

    const epley = w * (1 + r / 30);
    const brzycki = w * (36 / (37 - r));
    const avg = (epley + brzycki) / 2;

    return {
      epley: Math.round(epley * 10) / 10,
      brzycki: Math.round(brzycki * 10) / 10,
      rounded: Math.round(avg)
    };
  };

  return (
    <WorkoutContext.Provider
      value={{
        selectedTrack,
        setSelectedTrack,
        workoutTemplates: WORKOUT_TEMPLATES,
        progressLogs,
        addBodyweightEntry,
        completedWorkouts,
        saveCompletedWorkout,
        calculate1RM,
        activeWorkout,
        setActiveWorkout
      }}
    >
      {children}
    </WorkoutContext.Provider>
  );
};

export const useWorkout = () => useContext(WorkoutContext);

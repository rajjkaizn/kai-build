import React, { useState } from 'react';
import { useWorkout } from '../../context/WorkoutContext';
import { useAuth } from '../../context/AuthContext';
import { TRACKS } from '../../data/coursesData';
import {
  Plus, Minus, CheckCircle, Save, TrendingUp, Scale,
  Dumbbell, Flame, Zap, Trophy, ChevronDown, BarChart3, Calculator
} from 'lucide-react';

const TRACK_ICONS = { build: Dumbbell, cut: Flame, gain: Zap, powerlifting: Trophy };
const TRACK_COLORS = {
  build: { accent: 'emerald', label: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', btn: 'bg-emerald-500 hover:bg-emerald-400' },
  cut: { accent: 'cyan', label: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20', btn: 'bg-cyan-500 hover:bg-cyan-400' },
  gain: { accent: 'amber', label: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20', btn: 'bg-amber-500 hover:bg-amber-400' },
  powerlifting: { accent: 'purple', label: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20', btn: 'bg-purple-500 hover:bg-purple-400' },
};

const RIR_DESCRIPTIONS = ['1 RIR (Extremely Hard)', '2 RIR (Very Hard)', '3 RIR (Hard)', '4 RIR (Moderate)', '5+ RIR (Easy)'];

export const WorkoutTracker = ({ selectedTrackId }) => {
  const { user } = useAuth();
  const {
    workoutTemplates, progressLogs, addBodyweightEntry,
    completedWorkouts, saveCompletedWorkout, calculate1RM, selectedTrack, setSelectedTrack
  } = useWorkout();

  const [tab, setTab] = useState('log'); // 'log' | 'progress' | 'calc'
  const [trackId, setTrackId] = useState(selectedTrackId || 'build');
  const [selectedWorkoutIdx, setSelectedWorkoutIdx] = useState(0);

  // Set logs state per exercise
  const templates = workoutTemplates[trackId] || [];
  const workout = templates[selectedWorkoutIdx];
  const [setLogs, setSetLogs] = useState({});
  const [workoutSaved, setWorkoutSaved] = useState(false);

  // Bodyweight form
  const [bwForm, setBwForm] = useState({ weight: '', bodyFat: '', notes: '' });
  const [bwSaved, setBwSaved] = useState(false);

  // 1RM calc
  const [rmWeight, setRmWeight] = useState('');
  const [rmReps, setRmReps] = useState('');
  const rmResult = calculate1RM(rmWeight, rmReps);

  const color = TRACK_COLORS[trackId] || TRACK_COLORS.build;

  const updateSet = (exId, setIdx, field, value) => {
    setSetLogs(prev => ({
      ...prev,
      [exId]: {
        ...prev[exId],
        [setIdx]: { ...(prev[exId]?.[setIdx] || {}), [field]: value }
      }
    }));
    setWorkoutSaved(false);
  };

  const addSet = (exId, targetSets) => {
    const current = setLogs[exId] ? Object.keys(setLogs[exId]).length : 0;
    if (current < 8) updateSet(exId, current, 'weight', '');
  };

  const handleSaveWorkout = () => {
    let totalVolume = 0;
    Object.entries(setLogs).forEach(([exId, sets]) => {
      Object.values(sets).forEach(s => {
        const w = parseFloat(s.weight) || 0;
        const r = parseInt(s.reps) || 0;
        totalVolume += w * r;
      });
    });
    saveCompletedWorkout({
      workoutName: workout?.name,
      trackId,
      durationMinutes: 55,
      exercisesLogged: Object.keys(setLogs).length,
      totalVolumeKg: Math.round(totalVolume),
    });
    setWorkoutSaved(true);
  };

  const handleSaveBw = () => {
    if (!bwForm.weight) return;
    addBodyweightEntry(bwForm);
    setBwSaved(true);
    setBwForm({ weight: '', bodyFat: '', notes: '' });
    setTimeout(() => setBwSaved(false), 2000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="mb-6">
        <h1 className="text-3xl font-black text-white font-display">📊 Workout & Progress Tracker</h1>
        <p className="text-slate-400 text-sm mt-1">Log sets · reps · weight · RIR → track your progression</p>
      </div>

      {/* Track Selector */}
      <div className="flex flex-wrap gap-2 mb-6">
        {TRACKS.map(t => {
          const Icon = TRACK_ICONS[t.id];
          const c = TRACK_COLORS[t.id];
          return (
            <button key={t.id} onClick={() => { setTrackId(t.id); setSelectedWorkoutIdx(0); setSetLogs({}); setWorkoutSaved(false); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold uppercase border transition-all ${
                trackId === t.id ? `${c.bg} ${c.label} ${c.border}` : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}>
              <Icon className="w-3.5 h-3.5" />{t.id}
            </button>
          );
        })}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-slate-800 mb-6">
        {[
          { id: 'log', label: '💪 Workout Log' },
          { id: 'progress', label: '📈 Progress & BW' },
          { id: 'calc', label: '🔢 1RM Calculator' },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`px-4 py-2.5 text-sm font-medium transition-all border-b-2 ${
              tab === t.id ? `border-emerald-500 ${color.label}` : 'border-transparent text-slate-400 hover:text-white'
            }`}>
            {t.label}
          </button>
        ))}
      </div>

      {/* ── LOG TAB ── */}
      {tab === 'log' && (
        <div>
          {/* Workout Selector */}
          {templates.length > 1 && (
            <div className="flex flex-wrap gap-2 mb-5">
              {templates.map((tmpl, idx) => (
                <button key={tmpl.id} onClick={() => { setSelectedWorkoutIdx(idx); setSetLogs({}); setWorkoutSaved(false); }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                    selectedWorkoutIdx === idx ? `${color.bg} ${color.label} ${color.border}` : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}>
                  {tmpl.name}
                </button>
              ))}
            </div>
          )}

          {workout ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-white">{workout.name}</h2>
                  <p className="text-xs text-slate-400">Est. {workout.estimatedTime} · {workout.exercises.length} exercises</p>
                </div>
                <button onClick={handleSaveWorkout}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                    workoutSaved ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : `${color.btn} text-slate-950`
                  }`}>
                  {workoutSaved ? <><CheckCircle className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" /> Save Workout</>}
                </button>
              </div>

              {workout.exercises.map(ex => {
                const logs = setLogs[ex.id] || {};
                const setCount = Math.max(ex.targetSets, Object.keys(logs).length);

                return (
                  <div key={ex.id} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                    <div className="px-4 py-3 border-b border-slate-800 flex items-start justify-between gap-2">
                      <div>
                        <div className="text-sm font-semibold text-white">{ex.name}</div>
                        <div className="text-xs text-slate-400 mt-0.5">
                          Target: <span className="font-medium">{ex.targetSets} sets × {ex.targetReps} reps</span>
                          {' · '}<span className={color.label}>RPE {ex.targetRpe}</span>
                          {' · '}{ex.restTime} rest
                        </div>
                        <div className="text-xs text-slate-500 mt-1 italic">💡 {ex.formTip}</div>
                      </div>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-slate-800 text-slate-500">
                            <th className="text-left px-4 py-2 w-10">Set</th>
                            <th className="text-left px-4 py-2">Weight (kg)</th>
                            <th className="text-left px-4 py-2">Reps</th>
                            <th className="text-left px-4 py-2">RIR</th>
                            <th className="text-left px-4 py-2 hidden sm:table-cell">1RM Est.</th>
                          </tr>
                        </thead>
                        <tbody>
                          {Array.from({ length: setCount }).map((_, sIdx) => {
                            const s = logs[sIdx] || {};
                            const rm = calculate1RM(s.weight, s.reps);
                            return (
                              <tr key={sIdx} className="border-b border-slate-800/50 last:border-0 hover:bg-slate-800/20">
                                <td className="px-4 py-2 font-bold text-slate-400">{sIdx + 1}</td>
                                <td className="px-4 py-2">
                                  <input
                                    type="number"
                                    placeholder={ex.defaultWeight.toString()}
                                    value={s.weight || ''}
                                    onChange={e => updateSet(ex.id, sIdx, 'weight', e.target.value)}
                                    className="w-20 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-white text-xs focus:outline-none focus:border-emerald-500"
                                  />
                                </td>
                                <td className="px-4 py-2">
                                  <input
                                    type="number"
                                    placeholder={ex.targetReps.split(' - ')[0] || '8'}
                                    value={s.reps || ''}
                                    onChange={e => updateSet(ex.id, sIdx, 'reps', e.target.value)}
                                    className="w-16 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-white text-xs focus:outline-none focus:border-emerald-500"
                                  />
                                </td>
                                <td className="px-4 py-2">
                                  <select
                                    value={s.rir || ''}
                                    onChange={e => updateSet(ex.id, sIdx, 'rir', e.target.value)}
                                    className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-slate-300 text-xs focus:outline-none focus:border-emerald-500"
                                  >
                                    <option value="">—</option>
                                    {[0,1,2,3,4,5].map(r => <option key={r} value={r}>{r} RIR</option>)}
                                  </select>
                                </td>
                                <td className="px-4 py-2 hidden sm:table-cell">
                                  {rm.rounded > 0 ? (
                                    <span className={`font-bold ${color.label}`}>{rm.rounded} kg</span>
                                  ) : <span className="text-slate-600">—</span>}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                    <div className="px-4 py-2 border-t border-slate-800">
                      <button onClick={() => addSet(ex.id, ex.targetSets)} className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors">
                        <Plus className="w-3.5 h-3.5" /> Add Set
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12 text-slate-500">No workouts available for this track yet.</div>
          )}
        </div>
      )}

      {/* ── PROGRESS TAB ── */}
      {tab === 'progress' && (
        <div className="space-y-6">
          {/* Log bodyweight */}
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800">
            <h3 className="text-sm font-bold text-white mb-4">⚖️ Log Today's Stats</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Bodyweight (kg)</label>
                <input type="number" step="0.1" placeholder="e.g. 78.5"
                  value={bwForm.weight} onChange={e => setBwForm(p => ({ ...p, weight: e.target.value }))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Body Fat % (optional)</label>
                <input type="number" step="0.1" placeholder="e.g. 14.5"
                  value={bwForm.bodyFat} onChange={e => setBwForm(p => ({ ...p, bodyFat: e.target.value }))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Notes</label>
                <input type="text" placeholder="Feeling strong today"
                  value={bwForm.notes} onChange={e => setBwForm(p => ({ ...p, notes: e.target.value }))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500" />
              </div>
            </div>
            <button onClick={handleSaveBw}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${bwSaved ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : `${color.btn} text-slate-950`}`}>
              {bwSaved ? '✓ Saved!' : 'Log Entry'}
            </button>
          </div>

          {/* Progress log table */}
          <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">📈 Bodyweight & Body Fat History</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="border-b border-slate-800 text-slate-500">
                  <tr>
                    <th className="text-left px-4 py-2">Date</th>
                    <th className="text-left px-4 py-2">Weight (kg)</th>
                    <th className="text-left px-4 py-2">BF%</th>
                    <th className="text-left px-4 py-2">Track</th>
                    <th className="text-left px-4 py-2 hidden sm:table-cell">Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {progressLogs.slice(0, 20).map((log, i) => (
                    <tr key={i} className="border-b border-slate-800/50 last:border-0 hover:bg-slate-800/20">
                      <td className="px-4 py-2.5 text-slate-300">{log.date}</td>
                      <td className="px-4 py-2.5 font-bold text-white">{log.weight}</td>
                      <td className="px-4 py-2.5 text-slate-400">{log.bodyFat ? `${log.bodyFat}%` : '—'}</td>
                      <td className="px-4 py-2.5">
                        {log.track && <span className={`text-[10px] font-bold uppercase ${TRACK_COLORS[log.track]?.label || 'text-slate-400'}`}>{log.track}</span>}
                      </td>
                      <td className="px-4 py-2.5 text-slate-500 hidden sm:table-cell truncate max-w-xs">{log.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {progressLogs.length === 0 && (
                <div className="py-8 text-center text-slate-500 text-sm">No entries yet. Log your first stats above.</div>
              )}
            </div>
          </div>

          {/* Recent workouts */}
          {completedWorkouts.length > 0 && (
            <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-800">
                <h3 className="text-sm font-bold text-white">🏋️ Completed Workouts</h3>
              </div>
              <div className="divide-y divide-slate-800/50">
                {completedWorkouts.slice(0, 8).map(w => (
                  <div key={w.id} className="flex items-center gap-4 px-4 py-3">
                    <div className="flex-1">
                      <div className="text-sm font-medium text-white">{w.workoutName}</div>
                      <div className="text-xs text-slate-400">{w.date} · {w.durationMinutes} min · {w.exercisesLogged} exercises</div>
                    </div>
                    <div className="text-right">
                      <div className={`text-sm font-bold ${TRACK_COLORS[w.trackId]?.label || 'text-emerald-400'}`}>{w.totalVolumeKg?.toLocaleString()} kg</div>
                      <div className="text-[10px] text-slate-500">total volume</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── 1RM CALC TAB ── */}
      {tab === 'calc' && (
        <div className="max-w-lg space-y-5">
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-800">
            <h3 className="text-base font-bold text-white mb-1">🔢 One-Rep Max Calculator</h3>
            <p className="text-xs text-slate-400 mb-4">Estimates your 1RM using both Epley and Brzycki formulas. Enter a working set weight and reps performed.</p>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Weight Lifted (kg)</label>
                <input type="number" placeholder="e.g. 100" value={rmWeight} onChange={e => setRmWeight(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500" />
              </div>
              <div>
                <label className="text-xs text-slate-400 mb-1 block">Reps Performed</label>
                <input type="number" placeholder="e.g. 5" value={rmReps} onChange={e => setRmReps(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500" />
              </div>
            </div>

            {rmResult.rounded > 0 && (
              <div className="space-y-3">
                <div className={`text-center p-4 rounded-xl ${color.bg} border ${color.border}`}>
                  <div className="text-xs text-slate-400 mb-1">Estimated 1RM</div>
                  <div className={`text-4xl font-black ${color.label}`}>{rmResult.rounded} kg</div>
                  <div className="text-xs text-slate-400 mt-1">Epley: {rmResult.epley} kg · Brzycki: {rmResult.brzycki} kg</div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  {[
                    { pct: 90, label: '90% (Peaking)' },
                    { pct: 80, label: '80% (Strength)' },
                    { pct: 70, label: '70% (Volume)' },
                    { pct: 65, label: '65% (Hypertrophy)' },
                    { pct: 60, label: '60% (Technique)' },
                    { pct: 50, label: '50% (Warmup)' },
                  ].map(({ pct, label }) => (
                    <div key={pct} className="p-2 bg-slate-950 border border-slate-800 rounded-lg">
                      <div className="font-bold text-white">{Math.round(rmResult.rounded * pct / 100)} kg</div>
                      <div className="text-slate-500">{label}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 leading-relaxed">
            <strong className="text-white">Formula Notes:</strong> The <em>Epley formula</em> (w × (1 + r/30)) and <em>Brzycki formula</em> (w × 36/(37−r)) are both validated estimators. For best accuracy, use reps between 2–10 and avoid sets taken to complete failure.
          </div>
        </div>
      )}
    </div>
  );
};

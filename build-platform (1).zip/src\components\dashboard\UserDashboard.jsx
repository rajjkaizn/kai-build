import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useWorkout } from '../../context/WorkoutContext';
import { COURSES, TRACKS } from '../../data/coursesData';
import {
  Flame, Award, Activity, BookOpen, Calendar, CheckSquare,
  FileText, Play, Calculator, ArrowRight, Dumbbell, Zap, Trophy,
  Download, Sparkles
} from 'lucide-react';
import { PowerliftingProgramSelector, getPurchasedPrograms } from '../course/PowerliftingProgramSelector';

const TRACK_COLORS = {
  build: { label: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', btn: 'bg-emerald-500 hover:bg-emerald-400' },
  cut: { label: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20', btn: 'bg-cyan-500 hover:bg-cyan-400' },
  gain: { label: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20', btn: 'bg-amber-500 hover:bg-amber-400' },
  powerlifting: { label: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20', btn: 'bg-purple-500 hover:bg-purple-400' },
};

export const UserDashboard = ({ onEnterClassroom, onViewCourse, setCurrentView }) => {
  const { user, isLessonCompleted, openAuth } = useAuth();
  const { progressLogs, completedWorkouts } = useWorkout();

  if (!user) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <div className="text-4xl mb-4">🔒</div>
        <h2 className="text-xl font-bold text-white mb-2">Please log in to view your dashboard</h2>
        <p className="text-slate-400 mb-6">Your progress, enrolled courses, and stats are all saved securely.</p>
        <button
          onClick={() => openAuth('login')}
          className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-lg shadow-emerald-500/20 cursor-pointer"
        >
          Log In / Join Free
        </button>
      </div>
    );
  }

  const enrolledCourses = COURSES.filter(c => user.enrolledCourseIds?.includes(c.id));
  const hasPowerlifting = user.enrolledCourseIds?.includes('course-powerlifting') || user.enrolledCourseIds?.includes('course-bundle-all');
  const purchasedPLPrograms = getPurchasedPrograms();

  // Compute progress per enrolled course
  const courseProgress = enrolledCourses.map(course => {
    const allLessons = course.modules?.flatMap(m => m.lessons) || [];
    const completed = allLessons.filter(l => isLessonCompleted(l.id)).length;
    const pct = allLessons.length > 0 ? Math.round((completed / allLessons.length) * 100) : 0;
    const quizPassed = user.quizScores?.[course.id]?.passed;
    return { course, total: allLessons.length, completed, pct, quizPassed };
  });

  const latestWeight = progressLogs[0]?.weight;

  const toolCards = [
    { icon: Activity, label: 'Workout Log', sub: 'Log sets · reps · weight · RIR', view: 'tracker', color: 'text-emerald-400' },
    { icon: Calculator, label: 'Nutrition Calc', sub: 'Calories & macros for your goal', view: 'nutrition', color: 'text-amber-400' },
    { icon: Calendar, label: '12-Week Program', sub: 'View your periodized plan', view: 'program', color: 'text-purple-400' },
    { icon: CheckSquare, label: 'Weekly Checklist', sub: 'Track daily habits', view: 'checklist', color: 'text-cyan-400' },
    { icon: FileText, label: 'PDF Library', sub: 'Download workbooks & blueprints', view: 'resources', color: 'text-rose-400' },
    { icon: BookOpen, label: 'All Courses', sub: 'Browse the full catalog', view: 'curriculum', color: 'text-blue-400' },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      {/* Welcome Header */}
      <div className="flex items-center gap-4 mb-8">
        <img src={user.avatar} alt={user.name} className="w-16 h-16 rounded-2xl object-cover ring-4 ring-emerald-500/20" />
        <div>
          <div className="text-2xl font-black text-white font-display">Welcome back, {user.name.split(' ')[0]} 👋</div>
          <div className="text-sm text-slate-400 mt-0.5 flex flex-wrap items-center gap-3">
            <span className="flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-amber-400">{user.currentStreak}</span> day streak
            </span>
            <span>{enrolledCourses.length} course{enrolledCourses.length !== 1 ? 's' : ''} enrolled</span>
            <span>Joined {user.joinedDate}</span>
          </div>
        </div>
      </div>

      {/* Quick Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
        {[
          { label: 'Courses Enrolled', value: enrolledCourses.length, icon: BookOpen, color: 'text-emerald-400' },
          { label: 'Lessons Completed', value: user.completedLessonIds?.length || 0, icon: Award, color: 'text-amber-400' },
          { label: 'Workouts Logged', value: completedWorkouts.length, icon: Activity, color: 'text-cyan-400' },
          { label: 'Current Weight', value: latestWeight ? `${latestWeight} kg` : '—', icon: Dumbbell, color: 'text-purple-400' },
        ].map(stat => (
          <div key={stat.label} className="p-4 rounded-xl bg-slate-900 border border-slate-800">
            <stat.icon className={`w-5 h-5 ${stat.color} mb-2`} />
            <div className="text-xl font-black text-white">{stat.value}</div>
            <div className="text-xs text-slate-400">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ── My Courses ── */}
        <div className="lg:col-span-2 space-y-6">
          <div>
            <h2 className="text-base font-bold text-white mb-3 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-emerald-400" /> My Enrolled Courses
            </h2>

            {enrolledCourses.length === 0 ? (
              <div className="p-8 rounded-xl bg-slate-900 border border-dashed border-slate-800 text-center">
                <p className="text-slate-400 text-sm mb-4">You haven't enrolled in any course yet.</p>
                <button
                  onClick={() => setCurrentView('curriculum')}
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-sm transition-all"
                >
                  Browse Courses
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {courseProgress.map(({ course, total, completed, pct, quizPassed }) => {
                  const color = TRACK_COLORS[course.trackId] || TRACK_COLORS.build;
                  return (
                    <div key={course.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all">
                      <div className="flex items-start gap-4">
                        <img src={course.thumbnail} alt={course.title} className="w-20 h-14 rounded-lg object-cover flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className={`text-[11px] font-bold uppercase tracking-wider ${color.label} mb-0.5`}>{course.trackId} track</div>
                          <h3 className="text-sm font-bold text-white leading-snug line-clamp-1">{course.title}</h3>
                          <div className="flex items-center gap-3 mt-1.5">
                            <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                              <div className={`h-full rounded-full transition-all ${pct > 0 ? `bg-emerald-500` : 'bg-slate-700'}`} style={{ width: `${pct}%` }} />
                            </div>
                            <span className="text-[11px] text-slate-400 flex-shrink-0">{completed}/{total} lessons · {pct}%</span>
                          </div>
                          {quizPassed && (
                            <div className="mt-1.5 flex items-center gap-1 text-[11px] text-amber-400 font-semibold">
                              <Award className="w-3 h-3" /> Certificate Earned
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => onEnterClassroom(course)}
                          className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-2 ${color.btn} text-slate-950 font-bold rounded-lg text-xs transition-all`}
                        >
                          <Play className="w-3.5 h-3.5" /> Continue
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* ── Powerlifting Programs Section (if enrolled or purchased) ── */}
          {(hasPowerlifting || purchasedPLPrograms.length > 0) && (
            <div className="p-5 rounded-2xl bg-purple-950/20 border border-purple-500/30">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-purple-400" />
                  <h3 className="text-base font-bold text-white font-display">
                    Powerlifting Blueprint Programs
                  </h3>
                </div>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  {purchasedPLPrograms.length} of 3 Programs Unlocked
                </span>
              </div>
              <PowerliftingProgramSelector mode="dashboard" />
            </div>
          )}

          {/* Recent workouts */}
          {completedWorkouts.length > 0 && (
            <div>
              <h2 className="text-base font-bold text-white mt-2 mb-3">🏋️ Recent Workouts</h2>
              <div className="rounded-xl bg-slate-900 border border-slate-800 divide-y divide-slate-800/50">
                {completedWorkouts.slice(0, 5).map(w => (
                  <div key={w.id} className="flex items-center gap-3 px-4 py-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                      <Dumbbell className="w-4 h-4 text-emerald-400" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm font-medium text-white">{w.workoutName}</div>
                      <div className="text-xs text-slate-400">{w.date} · {w.durationMinutes} min · {w.exercisesLogged} exercises</div>
                    </div>
                    <div className="text-sm font-bold text-emerald-400">{w.totalVolumeKg?.toLocaleString()} kg</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* ── Tools Sidebar ── */}
        <div>
          <h2 className="text-base font-bold text-white mb-4">⚡ Quick Access</h2>
          <div className="space-y-2">
            {toolCards.map(tool => (
              <button
                key={tool.view}
                onClick={() => setCurrentView(tool.view)}
                className="w-full flex items-center gap-3 p-3.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all text-left group"
              >
                <tool.icon className={`w-5 h-5 ${tool.color} flex-shrink-0`} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white">{tool.label}</div>
                  <div className="text-xs text-slate-500">{tool.sub}</div>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-400 transition-colors" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

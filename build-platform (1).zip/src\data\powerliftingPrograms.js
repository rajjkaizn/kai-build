// Powerlifting program definitions — maps to the user's uploaded PDFs
export const POWERLIFTING_PROGRAMS = [
  {
    id: 'pl-squat',
    name: 'Squat Program',
    subtitle: 'Block 1 — Conventional Stance',
    description:
      'Periodized squat programming with percentage-based progression across hypertrophy, strength conversion, and peaking blocks. Designed for lifters running conventional squat stance.',
    pdfFile: '/pdfs/Powerlifting_Block1_Conv_3xBench.pdf',
    pdfFileName: 'Powerlifting_Block1_Conv_3xBench.pdf',
    icon: '🦵',
    highlights: [
      'Multi-block periodization (Hypertrophy → Strength → Peak)',
      'Competition-legal depth cues and technique drills',
      'Accessory work for sticking points (quads, glutes, erectors)',
      'RPE/percentage autoregulation guidance',
    ],
  },
  {
    id: 'pl-bench',
    name: 'Bench Press Program',
    subtitle: '4× Weekly Bench Frequency',
    description:
      'High-frequency bench press specialisation block with 4 bench sessions per week. Includes paused, close-grip, and competition bench variations across a periodized progression.',
    pdfFile: '/pdfs/Powerlifting_Block1_Conv_4xBench.pdf',
    pdfFileName: 'Powerlifting_Block1_Conv_4xBench.pdf',
    icon: '🏋️',
    highlights: [
      '4× weekly bench frequency with variation cycling',
      'Paused reps, Spoto press, and close-grip bench programming',
      'Shoulder health prehab and scapular retraction drills',
      'Grip width optimisation based on forearm verticality',
    ],
  },
  {
    id: 'pl-deadlift',
    name: 'Deadlift Program',
    subtitle: 'Sumo Stance Specialisation',
    description:
      '15-week sumo deadlift peaking program with dedicated pulling blocks. Builds hip mobility, wedge strength, and lockout power for competition sumo pulls.',
    pdfFile: '/pdfs/Powerlifting_15_Week_Sumo_4xBench.pdf',
    pdfFileName: 'Powerlifting_15_Week_Sumo_4xBench.pdf',
    icon: '💀',
    highlights: [
      '15-week periodized sumo deadlift progression',
      'Hip mobility and adductor flexibility work',
      'Slack-pull technique and lat engagement drills',
      'Block pulls and deficit deadlift accessory cycles',
    ],
  },
];

export const PL_ADDON_PRICE = 50; // ₹50 per additional program

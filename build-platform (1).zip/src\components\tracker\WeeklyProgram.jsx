import React, { useState } from 'react';
import { TRACKS } from '../../data/coursesData';
import { Dumbbell, Flame, Zap, Trophy, ChevronDown, ChevronRight } from 'lucide-react';

const TRACK_ICONS = { build: Dumbbell, cut: Flame, gain: Zap, powerlifting: Trophy };
const TRACK_COLORS = {
  build: { label: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
  cut: { label: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20' },
  gain: { label: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
  powerlifting: { label: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
};

const PROGRAMS = {
  build: {
    name: 'Hypertrophy Blueprint — 12-Week Program',
    phases: [
      {
        phase: 'Phase 1: Accumulation (Weeks 1–4)',
        goal: 'Build base volume tolerance, learn mechanics, establish mind-muscle connection.',
        weeks: [
          { week: 1, focus: 'Intro & Calibration', days: ['Day 1: Upper Push · Incline DB Press 4×10, Cable Flye 3×15, OHP 3×10, Tricep Pushdown 3×15', 'Day 2: Lower · Hack Squat 4×10, RDL 3×10, Leg Curl 3×12, Calf Raise 4×15', 'Day 3: Rest / Walk 8k steps', 'Day 4: Upper Pull · Lat Pulldown 4×10, CS Row 4×10, Bicep Curl 3×12', 'Day 5: Lower Volume · Leg Press 4×12, Bulgarian SS 3×10, Leg Extension 3×15', 'Day 6: Rest', 'Day 7: Rest + Mobility'], rpe: '6-7', notes: 'Learn the movements. No heroics this week.' },
          { week: 2, focus: 'Ramp Up Volume', days: ['Same split — add +1 set per major compound.', 'Push to RPE 7-8 on working sets.', 'Track all weights to establish your baseline numbers.'], rpe: '7-8', notes: 'Progressive overload begins here.' },
          { week: 3, focus: 'Progressive Overload I', days: ['Increase weight on all exercises by 2.5–5 kg where possible.', 'Add drop set on final isolation (laterals & bicep curls).', 'Keep video of one set of each compound for form review.'], rpe: '8', notes: 'Log every set — numbers do not lie.' },
          { week: 4, focus: 'Deload & Recovery', days: ['Reduce all working sets by 50%.', 'Keep the weight the same — only cut reps.', 'Focus on full ROM and slow eccentrics (3 seconds down).'], rpe: '5-6', notes: 'Deload resets the CNS and prevents injury. Do not skip.' },
        ]
      },
      {
        phase: 'Phase 2: Intensification (Weeks 5–8)',
        goal: 'Increase load and introduce mechanical drop sets, rest-pause, and myo-reps.',
        weeks: [
          { week: 5, focus: 'Heavy Compound Load', days: ['Switch to Upper/Lower 4-Day split.', 'Prioritise: Incline BB Press, Weighted Pull-ups, Hack Squat, RDL.', 'Work sets at RPE 8.5 on all compounds.'], rpe: '8.5', notes: 'Performance is king. Pre-workout carbs 60 min before.' },
          { week: 6, focus: 'Volume Peak', days: ['Highest volume week of the program.', 'Add 1 extra isolation exercise per day.', 'Monitor sleep — need 7–9h to recover from this volume.'], rpe: '9', notes: 'Highest training demand of the program. Eat more.' },
          { week: 7, focus: 'Intensity Focus', days: ['Cut 20% of sets — keep all weights the same.', 'Introduce lengthened partials on 2 exercises per day.', 'Add mechanical drop set: eg Incline DB → Flat DB → Cable Flye.'], rpe: '9-9.5', notes: 'Quality over quantity. Perfection on every rep.' },
          { week: 8, focus: 'Mini Deload', days: ['3 full-body sessions only.', 'RPE 6. Light weights. Treat as active recovery.', 'Prioritise 9h sleep, 200g carbs, 2.0g/kg protein.'], rpe: '6', notes: 'Second deload. This is where gains actually happen.' },
        ]
      },
      {
        phase: 'Phase 3: Metabolic Peak (Weeks 9–12)',
        goal: 'Maximise hypertrophic stimulus with extended sets, pumping blood, and high frequency.',
        weeks: [
          { week: 9, focus: 'Frequency Increase', days: ['Train each muscle 3× per week.', 'Upper A (Heavy) / Upper B (Volume) / Lower A / Lower B.', 'Add 20-min incline walk post-lifting on 3 days.'], rpe: '8.5', notes: 'Frequency peak. High protein — 2.2g/kg minimum.' },
          { week: 10, focus: 'Myo-Reps & Extended Sets', days: ['Use myo-rep sets on isolation: 15 reps + rest 15s × 3 mini-sets.', 'Incorporate supersets for arms and shoulders.', 'Aim for maximum pump while maintaining form.'], rpe: '9', notes: 'Chase the pump. This is metabolic stress week.' },
          { week: 11, focus: 'Final Push', days: ['Last heavy compound week.', 'Personal records on Incline Press and Hack Squat.', 'Photograph progress: morning, fasted, full body.'], rpe: '9.5', notes: 'Leave everything in the gym this week.' },
          { week: 12, focus: 'Maintenance & Assessment', days: ['3 light sessions. Test 1RM on key lifts (Incline, Weighted Pull-up).', 'Complete final quiz and receive your certificate.', 'Plan your next block: Cut, maintain, or repeat Hypertrophy.'], rpe: '6', notes: 'Celebrate your 12-week journey. Log your transformation stats.' },
        ]
      }
    ]
  },
  cut: {
    name: 'Sub-10% Shred Protocol — 8-Week Program',
    phases: [
      {
        phase: 'Phase 1: Deficit Setup & Volume Maintenance (Weeks 1–3)',
        goal: 'Establish precise caloric deficit, high NEAT, and muscle-preserving training.',
        weeks: [
          { week: 1, focus: 'Deficit Calibration', days: ['Set TDEE − 400 kcal target.', 'Walk 10,000 steps daily (minimum).', 'Strength training 4× / week — heavy weights, low volume reduction.'], rpe: '7-8', notes: 'Do not crash diet. Slow and steady wins the cut.' },
          { week: 2, focus: 'Adding Cardio Layer', days: ['Add 3× 25-min incline treadmill LISS sessions.', 'Keep lifting intensity high — RPE 8.', 'Track scale weight daily — average weekly.'], rpe: '8', notes: 'LISS should feel like a brisk walk, not running.' },
          { week: 3, focus: 'HIIT Introduction', days: ['Replace 1 LISS session with 20-min HIIT (8s on / 12s off).', 'Calorie cycle: eat TDEE on heavy lifting days, deficit on rest days.'], rpe: '8.5', notes: 'High day / low day cycling maintains anabolism.' },
        ]
      },
      {
        phase: 'Phase 2: Acceleration & Refeed (Weeks 4–6)',
        goal: 'Sustain deficit, execute refeed days, manage metabolic adaptation.',
        weeks: [
          { week: 4, focus: 'Refeed Day Protocol', days: ['Execute first full refeed: TDEE + 20% carbs, fat at minimum.', 'Scale weight will increase 0.5–1 kg — this is glycogen, not fat.', 'Workout performance on day after refeed should be excellent.'], rpe: '8', notes: 'The refeed is not a cheat day — it is precision nutrition.' },
          { week: 5, focus: 'Volume Peak + Low Carb', days: ['Lowest carb week of the program.', 'Carbs only around training.', 'High vegetable volume for satiety.'], rpe: '8.5', notes: 'Expect some performance dip. This is normal on low carbs.' },
          { week: 6, focus: 'Diet Break', days: ['Full 1-week diet break at maintenance calories.', 'Continue lifting and steps — no changes to activity.', 'Leptin and hormones restore to baseline.'], rpe: '7', notes: 'Diet breaks are mandatory. Skipping them prolongs cuts.' },
        ]
      },
      {
        phase: 'Phase 3: Final Polish (Weeks 7–8)',
        goal: 'Final push to target body fat, water management, and peak conditioning.',
        weeks: [
          { week: 7, focus: 'Peak Deficit Week', days: ['Drop 200 kcal further below previous deficit.', 'Maximise NEAT — walk everywhere.', 'Add morning fasted LISS (30 min) on 3 days.'], rpe: '8', notes: 'Deepest deficit of the entire program. Temporary.' },
          { week: 8, focus: 'Final Assessment', days: ['Return to maintenance calories for 3 days (final refeed).', 'Test body composition — skinfold or DEXA if available.', 'Complete shred quiz and receive certificate.'], rpe: '7', notes: 'Congratulations — you have completed the Sub-10% Protocol.' },
        ]
      }
    ]
  },
  gain: {
    name: 'Mass Monster Clean Bulk — 10-Week Program',
    phases: [
      {
        phase: 'Phase 1: Caloric Adaptation (Weeks 1–4)',
        goal: 'Build appetite and digestive capacity progressively without excess fat gain.',
        weeks: [
          { week: 1, focus: 'Calorie Ramp', days: ['Start at TDEE + 200 kcal.', 'Add 1 high-calorie shake daily.', 'Full-body 3× per week with all major compounds.'], rpe: '7', notes: 'Digestive system needs 2 weeks to adapt to high volume eating.' },
          { week: 2, focus: 'Ramp to Full Surplus', days: ['Increase to TDEE + 400 kcal.', 'Begin Upper/Lower 4-Day split.', 'Progressive overload on all compounds.'], rpe: '8', notes: 'Cook in bulk. Meal prepping is non-negotiable on a mass phase.' },
          { week: 3, focus: 'Volume & Strength', days: ['Add compound exercises: Barbell Row, Overhead Press, Close-Grip Bench.', 'Track weekly bodyweight (average 3 morning readings).', 'Target 0.5–0.7 kg gain per week.'], rpe: '8.5', notes: 'Gaining faster than 1 kg/week means excess fat — adjust down.' },
          { week: 4, focus: 'Deload + Digestive Reset', days: ['Reduce training volume by 40%.', 'Continue eating at full surplus.', 'Bodyweight typically jumps — mostly glycogen and water. Normal.'], rpe: '6', notes: 'Eat big. Rest big. Grow big.' },
        ]
      },
    ]
  },
  powerlifting: {
    name: 'SBD 1RM Peaking System — 16-Week Program',
    phases: [
      {
        phase: 'Phase 1: Base Strength Building (Weeks 1–6)',
        goal: 'Build raw strength foundation with moderate intensity and high technical practice.',
        weeks: [
          { week: 1, focus: 'Technique & Volume Base', days: ['Squat: 5×5 @ 70% 1RM', 'Bench: 5×5 @ 70% 1RM', 'Deadlift: 3×5 @ 75% 1RM', 'Accessories: Close-grip bench, paused squats, Romanian DL.'], rpe: '7', notes: 'Film every set. Identify technical deficiencies early.' },
          { week: 2, focus: 'Load Increase I', days: ['Add 2.5kg to Squat & Bench, 5kg to Deadlift.', 'All main movements: 4×5.', 'Accessories: moderate intensity, quality reps.'], rpe: '7.5', notes: 'Small jumps compound dramatically over 16 weeks.' },
          { week: 3, focus: 'Load Increase II', days: ['Continue adding load per week. RPE 8 target on last set.', 'Introduce tempo squats: 3s descent, no bounce out of hole.', 'Paused bench (1s pause): 3×3 at 75%.'], rpe: '8', notes: 'Paused and tempo work builds maximal strength out of sticking points.' },
        ]
      },
      {
        phase: 'Phase 2: Intensification (Weeks 7–12)',
        goal: 'Increase load weekly. Singles and triples. Learn how near-max feels.',
        weeks: [
          { week: 7, focus: 'Heavy Triples', days: ['Squat: 4×3 @ 82.5%', 'Bench: 4×3 @ 82.5%', 'Deadlift: 3×3 @ 85%', 'Only 1 accessory exercise per session to manage fatigue.'], rpe: '8.5', notes: 'Competition stance and grip on every rep. No variations.' },
          { week: 10, focus: 'Heavy Doubles', days: ['Squat: 3×2 @ 90%', 'Bench: 3×2 @ 90%', 'Deadlift: 2×2 @ 92%', 'No accessories — full CNS reserve for main lifts only.'], rpe: '9', notes: 'Doubles at 90% feel like singles. This is the goal.' },
        ]
      },
      {
        phase: 'Phase 3: Peak & Test (Weeks 13–16)',
        goal: 'Final taper, hit openers, and test 1RM on Week 16.',
        weeks: [
          { week: 13, focus: 'Final Heavy Week', days: ['Last heavy Squat & Bench single (RPE 9.0). These are your openers.', 'Last heavy Deadlift — no belt if possible, then belt on.', 'Begin taper: cut accessories completely.'], rpe: '9', notes: 'Do not push beyond RPE 9 here. Save for the test day.' },
          { week: 15, focus: 'Pre-Test Taper', days: ['Monday: Squat opener at 90% (should feel easy).', 'Wednesday: Bench opener at 90%.', 'Friday: Total rest.', 'Saturday: Deadlift opener only.'], rpe: '6-7', notes: 'These should feel embarrassingly easy. Good. Trust the process.' },
          { week: 16, focus: 'MAX TEST DAY 🏆', days: ['Warm up to opener — take 3 attempts on each lift.', 'Attempt 1: Opener (90% confident).', 'Attempt 2: 97-98% of goal 1RM.', 'Attempt 3: PR attempt (101-104% of best estimate).'], rpe: '10', notes: 'YOU ARE READY. Trust the 16 weeks. Attack the platform.' },
        ]
      }
    ]
  }
};

export const WeeklyProgram = ({ selectedTrackId }) => {
  const [trackId, setTrackId] = useState(selectedTrackId || 'build');
  const [openPhases, setOpenPhases] = useState({ 0: true });
  const [openWeeks, setOpenWeeks] = useState({ '0-0': true });

  const program = PROGRAMS[trackId];
  const color = TRACK_COLORS[trackId] || TRACK_COLORS.build;

  const togglePhase = (idx) => setOpenPhases(p => ({ ...p, [idx]: !p[idx] }));
  const toggleWeek = (key) => setOpenWeeks(p => ({ ...p, [key]: !p[key] }));

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <div className="mb-6">
        <h1 className="text-3xl font-black text-white font-display">📅 12-Week Training Program</h1>
        <p className="text-slate-400 text-sm mt-1">Full periodized plan broken into phases, weeks, and daily targets.</p>
      </div>

      {/* Track Selector */}
      <div className="flex flex-wrap gap-2 mb-6">
        {TRACKS.map(t => {
          const Icon = TRACK_ICONS[t.id];
          const c = TRACK_COLORS[t.id];
          return (
            <button key={t.id} onClick={() => { setTrackId(t.id); setOpenPhases({ 0: true }); setOpenWeeks({ '0-0': true }); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold uppercase border transition-all ${
                trackId === t.id ? `${c.bg} ${c.label} ${c.border}` : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}>
              <Icon className="w-3.5 h-3.5" />{t.id}
            </button>
          );
        })}
      </div>

      <div className={`p-3 rounded-xl ${color.bg} border ${color.border} mb-6`}>
        <h2 className={`text-sm font-bold ${color.label}`}>{program.name}</h2>
      </div>

      <div className="space-y-3">
        {program.phases.map((phase, pIdx) => (
          <div key={pIdx} className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
            {/* Phase Header */}
            <button onClick={() => togglePhase(pIdx)}
              className="w-full flex items-center justify-between p-4 text-left hover:bg-slate-800/50 transition-colors">
              <div>
                <div className={`text-xs font-bold uppercase tracking-wider ${color.label} mb-0.5`}>{phase.phase}</div>
                <div className="text-xs text-slate-400">{phase.goal}</div>
              </div>
              {openPhases[pIdx] ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
            </button>

            {openPhases[pIdx] && (
              <div className="border-t border-slate-800 divide-y divide-slate-800/50">
                {phase.weeks.map((week, wIdx) => {
                  const key = `${pIdx}-${wIdx}`;
                  return (
                    <div key={wIdx}>
                      <button onClick={() => toggleWeek(key)}
                        className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-slate-800/30 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-lg ${color.bg} border ${color.border} flex items-center justify-center text-xs font-black ${color.label}`}>
                            {week.week}
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-white">Week {week.week}: {week.focus}</div>
                            <div className="text-[11px] text-slate-400">Target RPE: {week.rpe}</div>
                          </div>
                        </div>
                        {openWeeks[key] ? <ChevronDown className="w-3.5 h-3.5 text-slate-500" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
                      </button>

                      {openWeeks[key] && (
                        <div className="px-4 pb-4 space-y-2">
                          <ul className="space-y-1.5">
                            {week.days.map((day, dIdx) => (
                              <li key={dIdx} className="flex items-start gap-2 text-sm text-slate-300">
                                <span className={`text-[10px] font-bold w-5 h-5 rounded flex items-center justify-center flex-shrink-0 mt-0.5 ${color.bg} ${color.label}`}>
                                  {dIdx + 1}
                                </span>
                                {day}
                              </li>
                            ))}
                          </ul>
                          <div className="mt-2 p-2.5 rounded-lg bg-slate-950/50 border border-slate-800/50 text-xs text-slate-400 italic">
                            💡 Coach's Note: {week.notes}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

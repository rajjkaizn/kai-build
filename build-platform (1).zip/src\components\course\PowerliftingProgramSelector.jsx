import React, { useState } from 'react';
import {
  CheckCircle,
  Circle,
  Download,
  FileText,
  Lock,
  Plus,
  ShoppingCart,
  Sparkles,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { POWERLIFTING_PROGRAMS, PL_ADDON_PRICE } from '../../data/powerliftingPrograms';
import { useAuth } from '../../context/AuthContext';

/**
 * PowerliftingProgramSelector
 *
 * Displayed on the Powerlifting course detail / checkout page.
 * – Lets the customer pick 1 program (included in base price).
 * – Additional programs cost ₹50 each.
 * – After purchase, only unlocked programs are downloadable.
 * – Already-purchased programs are never re-charged.
 */
export const PowerliftingProgramSelector = ({
  mode = 'checkout', // 'checkout' | 'dashboard'
  onSelectionChange,
  selectedIds: controlledIds,
}) => {
  const { user } = useAuth();

  // Programs the user has already purchased (stored in localStorage)
  const purchasedIds = (() => {
    try {
      const raw = localStorage.getItem('kaizen_pl_programs');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  })();

  const [internalSelected, setInternalSelected] = useState([]);
  const selectedIds = controlledIds ?? internalSelected;
  const setSelectedIds = (ids) => {
    setInternalSelected(ids);
    onSelectionChange?.(ids);
  };

  const [expandedId, setExpandedId] = useState(null);

  // ── CHECKOUT MODE ──────────────────────────────────────────
  if (mode === 'checkout') {
    const newSelections = selectedIds.filter((id) => !purchasedIds.includes(id));
    const freeSlots = Math.max(0, 1 - purchasedIds.length); // 1 free slot if they haven't bought any yet
    const freeSelectionsUsed = Math.min(freeSlots, newSelections.length);
    const paidAddons = Math.max(0, newSelections.length - freeSelectionsUsed);
    const addonTotal = paidAddons * PL_ADDON_PRICE;

    const toggleProgram = (programId) => {
      if (purchasedIds.includes(programId)) return; // already owned
      setSelectedIds(
        selectedIds.includes(programId)
          ? selectedIds.filter((id) => id !== programId)
          : [...selectedIds, programId]
      );
    };

    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
            <FileText className="w-4 h-4 text-purple-400" />
            Select Your Programs
          </h3>
          <span className="text-[11px] text-slate-400">
            1 included · +₹{PL_ADDON_PRICE} each additional
          </span>
        </div>

        <div className="space-y-2">
          {POWERLIFTING_PROGRAMS.map((prog) => {
            const isOwned = purchasedIds.includes(prog.id);
            const isSelected = selectedIds.includes(prog.id);
            const isExpanded = expandedId === prog.id;

            return (
              <div key={prog.id} className="rounded-xl border overflow-hidden transition-all">
                {/* Card Header */}
                <button
                  onClick={() => !isOwned && toggleProgram(prog.id)}
                  disabled={isOwned}
                  className={`w-full p-4 text-left transition-all flex items-start gap-3 ${
                    isOwned
                      ? 'bg-purple-500/5 border-purple-500/20 opacity-70 cursor-default'
                      : isSelected
                      ? 'bg-purple-500/10 border-purple-500/40'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700 cursor-pointer'
                  }`}
                >
                  {/* Checkbox */}
                  <div className="mt-0.5 flex-shrink-0">
                    {isOwned ? (
                      <div className="w-5 h-5 rounded-full bg-purple-500 flex items-center justify-center">
                        <CheckCircle className="w-3.5 h-3.5 text-white" />
                      </div>
                    ) : isSelected ? (
                      <div className="w-5 h-5 rounded-full bg-purple-500 flex items-center justify-center">
                        <CheckCircle className="w-3.5 h-3.5 text-white" />
                      </div>
                    ) : (
                      <Circle className="w-5 h-5 text-slate-600" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-lg">{prog.icon}</span>
                      <span className="text-sm font-bold text-white">{prog.name}</span>
                      {isOwned && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 border border-purple-500/30">
                          OWNED
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-purple-400 font-semibold">{prog.subtitle}</p>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">{prog.description}</p>
                  </div>

                  {/* Price badge */}
                  <div className="flex-shrink-0 text-right">
                    {isOwned ? (
                      <span className="text-[11px] text-slate-500">Already purchased</span>
                    ) : (
                      <span className="text-xs font-bold text-slate-300">
                        {selectedIds.indexOf(prog.id) === 0 && purchasedIds.length === 0
                          ? 'Included'
                          : `+₹${PL_ADDON_PRICE}`}
                      </span>
                    )}
                  </div>
                </button>

                {/* Expand/Preview Toggle */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setExpandedId(isExpanded ? null : prog.id);
                  }}
                  className="w-full py-1.5 bg-slate-950 border-t border-slate-800 text-[10px] text-slate-400 hover:text-white transition-colors flex items-center justify-center gap-1"
                >
                  {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  {isExpanded ? 'Hide Details' : 'Preview Program Details'}
                </button>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-2">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      What's Inside:
                    </h4>
                    <ul className="space-y-1.5">
                      {prog.highlights.map((h, i) => (
                        <li key={i} className="flex items-start gap-2 text-xs text-slate-300">
                          <CheckCircle className="w-3.5 h-3.5 text-purple-400 flex-shrink-0 mt-0.5" />
                          {h}
                        </li>
                      ))}
                    </ul>
                    <div className="pt-2 text-[10px] text-slate-500 flex items-center gap-2">
                      <FileText className="w-3 h-3" /> Full PDF program with weekly periodization
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Pricing summary */}
        {newSelections.length > 0 && (
          <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/30 space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">
                {newSelections.length} program{newSelections.length > 1 ? 's' : ''} selected
              </span>
              {freeSelectionsUsed > 0 && (
                <span className="text-purple-400 font-semibold">
                  {freeSelectionsUsed} included in base price
                </span>
              )}
            </div>
            {paidAddons > 0 && (
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">
                  {paidAddons} additional × ₹{PL_ADDON_PRICE}
                </span>
                <span className="text-white font-bold">+₹{addonTotal}</span>
              </div>
            )}
          </div>
        )}

        {selectedIds.length === 0 && (
          <p className="text-[11px] text-amber-400 text-center py-1">
            Please select at least one program to continue
          </p>
        )}
      </div>
    );
  }

  // ── DASHBOARD MODE ──────────────────────────────────────────
  // Shows purchased programs with download buttons + option to buy more
  const unpurchased = POWERLIFTING_PROGRAMS.filter((p) => !purchasedIds.includes(p.id));

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
        <FileText className="w-4 h-4 text-purple-400" />
        Your Powerlifting Programs
      </h3>

      {/* Purchased Programs */}
      {purchasedIds.length > 0 ? (
        <div className="space-y-2">
          {POWERLIFTING_PROGRAMS.filter((p) => purchasedIds.includes(p.id)).map((prog) => (
            <div
              key={prog.id}
              className="p-4 rounded-xl bg-slate-900 border border-purple-500/30 flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-3 min-w-0">
                <span className="text-2xl">{prog.icon}</span>
                <div className="min-w-0">
                  <div className="text-sm font-bold text-white">{prog.name}</div>
                  <div className="text-[11px] text-purple-400">{prog.subtitle}</div>
                </div>
              </div>
              <a
                href={prog.pdfFile}
                download={prog.pdfFileName}
                target="_blank"
                rel="noreferrer"
                className="flex-shrink-0 flex items-center gap-1.5 px-4 py-2 bg-purple-500 hover:bg-purple-400 text-white font-bold text-xs rounded-lg transition-all shadow-md shadow-purple-500/20"
              >
                <Download className="w-3.5 h-3.5" />
                Download PDF
              </a>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-center">
          <Lock className="w-6 h-6 text-slate-500 mx-auto mb-2" />
          <p className="text-xs text-slate-400">No programs purchased yet.</p>
        </div>
      )}

      {/* Buy More */}
      {unpurchased.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Unlock Additional Programs — ₹{PL_ADDON_PRICE} each
          </h4>
          {unpurchased.map((prog) => (
            <div
              key={prog.id}
              className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-lg">{prog.icon}</span>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white">{prog.name}</div>
                  <div className="text-[10px] text-slate-400">{prog.subtitle}</div>
                </div>
              </div>
              <button
                onClick={() => {
                  // Opens Razorpay for ₹50 addon purchase
                  const payUrl = `https://razorpay.me/@rajashokrai?amount=${PL_ADDON_PRICE}`;
                  window.open(payUrl, '_blank');
                  // After payment, save to localStorage
                  setTimeout(() => {
                    const current = JSON.parse(localStorage.getItem('kaizen_pl_programs') || '[]');
                    if (!current.includes(prog.id)) {
                      localStorage.setItem(
                        'kaizen_pl_programs',
                        JSON.stringify([...current, prog.id])
                      );
                      window.location.reload();
                    }
                  }, 3000);
                }}
                className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 font-bold text-[11px] rounded-lg transition-all border border-purple-500/30"
              >
                <Plus className="w-3 h-3" />
                Buy ₹{PL_ADDON_PRICE}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

/**
 * Utility: save purchased program IDs to localStorage after checkout.
 */
export const savePurchasedPrograms = (programIds) => {
  try {
    const existing = JSON.parse(localStorage.getItem('kaizen_pl_programs') || '[]');
    const merged = Array.from(new Set([...existing, ...programIds]));
    localStorage.setItem('kaizen_pl_programs', JSON.stringify(merged));
  } catch {
    localStorage.setItem('kaizen_pl_programs', JSON.stringify(programIds));
  }
};

/**
 * Utility: get purchased program IDs from localStorage.
 */
export const getPurchasedPrograms = () => {
  try {
    return JSON.parse(localStorage.getItem('kaizen_pl_programs') || '[]');
  } catch {
    return [];
  }
};

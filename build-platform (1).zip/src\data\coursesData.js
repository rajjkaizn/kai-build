import { BUILD_COURSE_MODULES } from './muscleGainContent.js';
import { CUT_COURSE_MODULES } from './fatLossContent.js';
import { GAIN_COURSE_MODULES } from './skinnyToBuiltContent.js';

export const TRACKS = [
  {
    id: 'build',
    name: 'BUILD (Hypertrophy)',
    tagline: 'Sculpt Lean Muscle & Maximum Hypertrophy',
    color: 'emerald',
    icon: 'Dumbbell',
    description: 'Scientifically proven 12-week hypertrophy program maximizing mechanical tension, volume landmarks, and muscle protein synthesis.',
    bgGradient: 'from-emerald-950 via-slate-900 to-slate-950',
    accentBorder: 'border-emerald-500/30 hover:border-emerald-500',
    badgeClass: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
  },
  {
    id: 'cut',
    name: 'CUT (Fat Loss)',
    tagline: 'Chisel Down to Single-Digit Body Fat',
    color: 'cyan',
    icon: 'Flame',
    description: 'Precision deficit protocols, nutrient timing, and metabolic conditioning to incinerate fat while preserving 100% of your hard-earned muscle.',
    bgGradient: 'from-cyan-950 via-slate-900 to-slate-950',
    accentBorder: 'border-cyan-500/30 hover:border-cyan-500',
    badgeClass: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
  },
  {
    id: 'gain',
    name: 'GAIN (Clean Bulking & Skinny to Built)',
    tagline: 'Pack on Serious Size Without The Excess Fat',
    color: 'amber',
    icon: 'Zap',
    description: 'The foundation blueprint for beginners and hardgainers: sustained caloric surplus, body recomposition, movement mechanics, and mass engineering.',
    bgGradient: 'from-amber-950 via-slate-900 to-slate-950',
    accentBorder: 'border-amber-500/30 hover:border-amber-500',
    badgeClass: 'bg-amber-500/10 text-amber-400 border-amber-500/20'
  },
  {
    id: 'powerlifting',
    name: 'POWERLIFTING (Strength)',
    tagline: 'Break Plateaus & Smash 1RM Records',
    color: 'purple',
    icon: 'Trophy',
    description: 'Master the biomechanics of the Squat, Bench Press, and Deadlift with periodized RPE programming, peaking cycles, and specialized uploaded PDF blueprints.',
    bgGradient: 'from-purple-950 via-slate-900 to-slate-950',
    accentBorder: 'border-purple-500/30 hover:border-purple-500',
    badgeClass: 'bg-purple-500/10 text-purple-400 border-purple-500/20'
  }
];

export const COURSES = [
  {
    id: 'course-bundle-all',
    title: 'Kaizen Full Access Pass',
    subtitle: 'Complete all-in-one access to all 4 training tracks (Build, Cut, Gain, Powerlifting), official 12-week workout PDF blueprints, trackers, and calculators.',
    trackId: 'bundle',
    badge: 'ALL-ACCESS PASS',
    price: 1496,
    discountPrice: 559,
    duration: 'Lifetime Access',
    durationHours: 48,
    modulesCount: 5,
    lessonsCount: 23,
    students: 12050,
    enrolledCount: 12050,
    rating: 5.0,
    reviewCount: 1840,
    lastUpdated: 'November 2026',
    thumbnail: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80',
    pdfUrl: '/pdfs/KFA_12_Week_Workout_Plans.pdf',
    isFreePreview: false,
    instructor: {
      name: 'Kaizen Head Coaches & Biomechanics Staff',
      role: 'Sports Scientists, IFBB Pros & Elite Powerlifters',
      avatar: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=150&auto=format&fit=crop&q=80',
      rating: 5.0,
      students: 28000,
      bio: 'Multi-disciplinary coaching panel specializing in drug-free hypertrophy, aggressive fat loss preservation, and SBD 1RM peaking.'
    },
    overview: 'The Kaizen Full Access Pass unlocks every training blueprint in our ecosystem. You get the 12-Week Hypertrophy Blueprint (Upper/Lower Split), the 12-Week Fat Loss Metabolic Shield (Full Body Split), the Skinny-to-Built Mass Foundation (A/B Overload Split), and the 15-Week SBD Peaking Competition Blueprint, plus our entire PDF vault and calculators.',
    features: [
      'All 4 Complete 12-Week Training Programs & PDF Blueprints',
      'Downloadable High-Res Workout Routines & Exercise Menus',
      'Interactive Sets, Reps, Weight & RIR Workout Tracker',
      'Precision TDEE & Macro Nutrition Calculator for Bulk & Cut',
      'Weekly Habit Tracker & Daily Progress Checklists',
      'Printable Tracking Sheets & 1RM Attempt Selection Sheets',
      'Official Certificates of Completion for All Tracks',
      'Lifetime Updates to All Future Programs'
    ],
    modules: [
      {
        id: 'mod-bundle-1',
        title: 'Module 1: The Master 12-Week Workout Blueprint & PDF Vault',
        duration: 'Master Guide',
        lessons: [
          {
            id: 'les-bundle-1',
            title: 'Complete 12-Week Workout System: Architecture & Split Selection',
            content: `## Complete 12-Week Workout System: Architecture & Split Selection

### 1. Introduction
Welcome to the Kaizen Master Workout System. Your Full Access Pass gives you access to three distinct, scientifically engineered periodized training tracks:
- **BUILD (Hypertrophy):** 4-Day Upper/Lower Split engineered for localized mechanical tension and muscle protein synthesis.
- **CUT (Fat Loss):** 3-Day Full Body High-Density Split paired with systematic NEAT acceleration to preserve lean tissue during a caloric deficit.
- **GAIN (Skinny to Built):** 3-Day Alternating A/B Overload Split for beginners and hardgainers focusing on foundational movement mechanics and progressive strength.
- **POWERLIFTING (SBD Peaking):** 15-Week Periodized Block Peaking system for maximum 1RM strength on the Squat, Bench Press, and Deadlift.

### 2. Learning Objectives
- Identify which 12-week blueprint matches your primary physiological adaptation.
- Understand the progressive overload rules governing compound and isolation movements.
- Schedule your weekly training sessions, recovery days, and scheduled deloads.

### 3. Split Comparison & Periodization Architecture

| Training Track | Split Frequency | Primary Target | Main Compound Lift Focus | Deload Cadence |
| :--- | :--- | :--- | :--- | :--- |
| **BUILD (Muscle Gain)** | 4 Days / Week (Upper/Lower) | Maximum Hypertrophy | Incline Press, Hack Squat, RDL, Rows | Every 6th Week |
| **CUT (Fat Loss)** | 3 Days / Week (Full Body) | Muscle Retention in Deficit | Squat pattern, Hinge, Horizontal/Vertical Press | Every 4th-5th Week |
| **GAIN (Skinny to Built)** | 3 Days / Week (Alternating A/B) | Movement Mastery & Mass | Goblet Squat, DB Bench, RDL, Lat Pulldown | Every 6th Week |
| **POWERLIFTING** | 3-4 Days / Week (SBD) | 1RM Force & Rate of Force | Competition Squat, Bench Press, Deadlift | Peaking Block Taper |

### 4. Progressive Overload Protocols
- **Double Progression Model:** Pick a rep range (e.g., 8–12 reps). Keep load identical until you hit the upper rep target on all prescribed working sets with 1–2 Reps in Reserve (RIR). Then, increase load by 2.5 kg to 5 kg and reset at the bottom of the rep range.
- **Rep Quality & Cadence:** 2 to 3 seconds controlled eccentric (lowering) phase, a brief 0.5-second pause at maximum stretch, and an explosive concentric phase.

### 5. Common Mistakes
1. **Track Hopping:** Switching between cutting and bulking every two weeks. You must commit to a minimum 12-week block to produce structural adaptations.
2. **Training to Absolute Failure on Every Set:** Training to muscular failure generates excessive systemic fatigue with diminishing hypertrophic return. Keep compound movements at 1–2 RIR.
3. **Neglecting Rest Intervals:** Rest 2.5 to 3.5 minutes on heavy compound movements to allow full ATP-CP replenishment.

### 6. Today's Action Task
Download your official 12-Week Workout Plan PDF from the tab above, print page 6 (Workout Tracker Sheet), and log your starting baseline metrics in the Kaizen Workout Log.`,
            
            duration: 'Program Guide',
            isFreePreview: true,
            summary: 'Understanding the 3 distinct training methodologies inside your Full Access Pass. Learn when to run the 4-day Upper/Lower split, the 3-day Full Body fat loss split, or the 3-day A/B overload split.',
            keyTakeaways: [
              'Match your training track to your primary 12-week goal (Hypertrophy vs Fat Loss vs Strength).',
              'Double progression model applies to all compound movements.',
              'Deloads are built into Week 6 (beginners) or Week 12 (systemic recovery).'
            ]
          },
          {
            id: 'les-bundle-2',
            title: 'Official Kaizen PDF Vault: Download & Printing Guide',
            content: `## Official Kaizen PDF Vault: Download & Printing Guide

### 1. Introduction
The Kaizen Fitness Academy curriculum is designed to be paired directly with your physical, high-resolution 12-Week Workout Blueprints. All workout plans, exercise menus, sets, reps, and tracking templates are available in the PDF Vault.

### 2. Learning Objectives
- Download, print, and navigate your complete 12-Week PDF Blueprint.
- Use the physical workout tracking sheet alongside your digital workout log.
- Interpret exercise notation, coaching cues, and tempo prescriptions.

### 3. Blueprint Reading Guide
- **Sets x Reps Notation:** E.g., \`3 x 8-10 @ RIR 2\` means perform 3 working sets, targeting between 8 and 10 repetitions per set, terminating each set when you still have 2 repetitions left before technical failure.
- **Exercise Swaps:** If your gym lacks a Hack Squat, refer to the Exercise Menu on Page 4 of your PDF to swap in a Leg Press or Heel-Elevated Goblet Squat without altering the biomechanical stimulus.

### 4. Step-by-Step Implementation
1. Click the **"Download Blueprint PDF"** button in the top navigation bar or switch to the **"Official 12-Week PDF"** tab.
2. Print the Workout Tracker Sheet (Page 6) or save the PDF to your tablet/notes app.
3. Keep track of date, bodyweight, exercise name, weight lifted, reps completed, and perceived RIR for every training session.

### 5. Today's Action Task
Ensure you have downloaded the complete 12-Week Blueprint PDF to your device and bookmarked the Routine & Exercise Menu tab for reference during gym sessions.`,
            
            duration: 'Resource Guide',
            isFreePreview: true,
            summary: 'Direct access to download and print the high-resolution workout templates, exercise menus, coaching cues, and tracking sheets.',
            keyTakeaways: [
              'Print the Tracking Sheet (Page 6) or keep it in your notes app.',
              'Record every working set to ensure progressive overload.',
              'Follow the coaching notes on exercise execution and pain-free range of motion.'
            ]
          }
        ]
      },
      {
        id: 'mod-bundle-2',
        title: 'Module 2: Build Track (Hypertrophy & Upper/Lower Split)',
        duration: 'Hypertrophy Track',
        lessons: [
          {
            id: 'les-bundle-3',
            title: '4-Day Upper/Lower Hypertrophy Split Overview',
            content: `## 4-Day Upper/Lower Hypertrophy Split Overview

### 1. Introduction
The 4-Day Upper/Lower split is the gold standard for natural hypertrophy. By separating the body into Upper body sessions (Chest, Back, Shoulders, Arms) and Lower body sessions (Quads, Hamstrings, Glutes, Calves), each muscle group is trained twice every 7 days with 48 to 72 hours of recovery between sessions.

### 2. Weekly Split Schedule
- **Monday: Upper A** (Incline DB Press, Chest-Supported Row, Overhead DB Press, Lat Pulldown, Tricep Pushdown, Bicep Curl)
- **Tuesday: Lower A** (Hack Squat / Front Squat, Romanian Deadlift, Leg Extension, Seated Leg Curl, Standing Calf Raise)
- **Wednesday: Rest / Active Recovery** (8,000–10,000 steps brisk walking)
- **Thursday: Upper B** (Flat Barbell/Dumbbell Press, Neutral-Grip Pull-Up, Cable Lateral Raise, Cable Row, Incline Dumbbell Curl, Overhead Cable Tricep Extension)
- **Friday: Lower B** (Barbell Romanian Deadlift / Leg Press, Bulgarian Split Squat, Lying Leg Curl, Walking Lunges, Seated Calf Raise)
- **Saturday: Rest**
- **Sunday: Rest & Weekly Review**

### 3. Hypertrophy Principles
- **Direct Volume:** 10 to 16 direct working sets per muscle group per week, split evenly across Upper A/B and Lower A/B.
- **Reps in Reserve (RIR):** Week 1–4 calibrate at 2 RIR; Week 5–8 push to 1 RIR; Week 9–11 push final set to 0 RIR.

### 4. Today's Action Task
Review your Upper A and Lower A exercise list and set your starting weights conservatively to master strict technique before progressing loads.`,
            
            duration: 'Split Guide',
            isFreePreview: false,
            summary: 'Upper A, Lower A, Upper B, and Lower B routines designed to maximize mechanical tension and localized muscle protein synthesis without accumulating systemic fatigue.',
            keyTakeaways: [
              'Upper A prioritizes incline pressing and chest-supported rows.',
              'Lower A balances hack/goblet squats with Romanian deadlifts.',
              'Upper B introduces vertical pulling and shoulder pressing.'
            ]
          }
        ]
      },
      {
        id: 'mod-bundle-3',
        title: 'Module 3: Cut Track (Fat Loss & Full Body Metabolic Split)',
        duration: 'Fat Loss Track',
        lessons: [
          {
            id: 'les-bundle-4',
            title: 'Full Body A/B/C Resistance & Cardio System',
            content: `## Full Body A/B/C Resistance & Cardio System

### 1. Introduction
During a fat loss phase, your body operates in an energy deficit. The primary objective of training is not to burn calories through excessive volume, but to signal to your physiology that muscle tissue is metabolically indispensable.

### 2. Training Philosophy During a Deficit
- **Preserve Training Intensity:** Do not drop the weights and do sets of 25 "for definition". Heavy resistance training (6–12 reps at 1–2 RIR) sends the strongest hormonal and mechanical signal to preserve muscle mass.
- **Frequency Over Session Volume:** 3 Full Body workouts per week (Monday, Wednesday, Friday) spreads volume across 3 sessions, preventing excessive localized soreness while maintaining continuous muscle protein synthesis.

### 3. Nutrition & Cardio Synergy
- **Caloric Deficit Target:** 400 to 500 kcal deficit below maintenance (TDEE).
- **Protein Requirement:** 2.0 to 2.2g per kg of total bodyweight to maximize satiety and nitrogen retention.
- **Low-Impact NEAT:** Target 10,000 daily steps to drive fat loss without spiking cortisol or appetite.

### 4. Today's Action Task
Calculate your baseline TDEE using the Kaizen Nutrition Calculator in the dashboard and set your daily deficit targets.`,
            
            duration: 'Deficit Protocol',
            isFreePreview: false,
            summary: 'How to preserve 100% of lean muscle tissue in a caloric deficit using 3 non-consecutive full body sessions and sustainable Zone 2 cardio.',
            keyTakeaways: [
              'Do not drop heavy compound lifts when cutting; maintain intensity to signal muscle retention.',
              'Add 20-30 min brisk walking 2-4x per week as recovery allows.',
              'Protein set at 2.0-2.2g per kg bodyweight.'
            ]
          }
        ]
      },
      {
        id: 'mod-bundle-4',
        title: 'Module 4: Gain Track (Skinny to Built A/B Progression)',
        duration: 'Mass Track',
        lessons: [
          {
            id: 'les-bundle-5',
            title: 'Alternating A/B Overload Split for Clean Bulking',
            content: `## Alternating A/B Overload Split for Clean Bulking

### 1. Introduction
Beginners and individuals starting from a skinny or skinny-fat baseline achieve optimal results with a high-frequency, low-complexity training split. The Alternating A/B program rotates two complementary full-body routines across three training days per week.

### 2. Weekly Rotation Schedule
- **Week 1:** Workout A (Mon) · Workout B (Wed) · Workout A (Fri)
- **Week 2:** Workout B (Mon) · Workout A (Wed) · Workout B (Fri)
- **Week 3:** Repeat rotation

### 3. Movement Structure
- **Workout A:** Squat Pattern (Goblet/Hack Squat), Horizontal Push (Dumbbell Bench Press), Horizontal Pull (Chest-Supported Row), Core Stabilization (Plank).
- **Workout B:** Hinge Pattern (Romanian Deadlift), Vertical Pull (Lat Pulldown), Vertical Push (Overhead Dumbbell Press), Loaded Carry (Farmer's Walk).

### 4. Clean Bulking Rules
- **Lean Surplus:** Eat 200 to 300 kcal above maintenance. This yields approximately 0.25 to 0.5 kg of weight gain per month for beginners, ensuring maximum muscle gain with minimal fat accrual.
- **Hydration & Sleep:** 3 to 4 liters of water daily and 7.5 to 9 hours of uninterrupted sleep.

### 5. Today's Action Task
Log your starting bodyweight and waist measurement in your Kaizen dashboard to establish your clean bulking baseline.`,
            
            duration: 'Bulking Guide',
            isFreePreview: false,
            summary: 'The hardgainer blueprint for building a strong foundation with alternating A/B workouts, progressive volume build-up, and clean surplus nutrition.',
            keyTakeaways: [
              'Week 1: A/B/A; Week 2: B/A/B on non-consecutive days.',
              'Focus on learning movement technique in Weeks 1-2 before ramping loads.',
              'Aim for modest, steady weight gain of 0.25-0.5% bodyweight per week.'
            ]
          }
        ]
      },
      {
        id: 'mod-bundle-5',
        title: 'Module 5: Powerlifting (SBD 15-Week Peaking Blueprint)',
        duration: 'Peaking Track',
        lessons: [
          {
            id: 'les-bundle-6',
            title: '15-Week SBD Periodization & Attempt Selection Matrix',
            content: `## 15-Week SBD Periodization & Attempt Selection Matrix

### 1. Introduction
The Kaizen 15-Week SBD (Squat, Bench Press, Deadlift) Peaking Blueprint is designed to systematically convert structural hypertrophy into maximal 1-Repetition Maximum (1RM) neurological force production.

### 2. Periodization Blocks
- **Block 1: Hypertrophy & Work Capacity (Weeks 1–5):** Higher volume (6–10 rep range), building tendon tolerance and cross-sectional muscle area.
- **Block 2: Strength Conversion (Weeks 6–10):** Intensity increases to 75–85% 1RM (3–5 rep range), refining bar path and intra-abdominal bracing.
- **Block 3: Peaking & Taper (Weeks 11–15):** Heavy singles and doubles at 88–95% 1RM, concluding with a 10-day volume taper to dissipate fatigue and supercompensate for competition or test day.

### 3. Competition Attempt Selection Matrix
- **Opener (1st Attempt):** 90–92% 1RM. A weight you can triple on any day with confidence.
- **Second Attempt:** 96–98% 1RM. Solid PR or match of current training best.
- **Third Attempt:** 101–103% 1RM. Full expression of strength based on second attempt bar speed.

### 4. Today's Action Task
Select your focus program (Squat, Bench Press, or Deadlift) in the Powerlifting Programs tab to download your customized periodized PDF blueprint.`,
            
            duration: '1RM Peaking',
            isFreePreview: false,
            summary: 'The periodized peaking taper system to convert training volume into max competition singles on Squat, Bench, and Deadlift.',
            keyTakeaways: [
              'Block 1: Hypertrophy & Work Capacity; Block 2: Strength Conversion; Block 3: Peaking & Taper.',
              'Opener selected at 90-92% (triple any day).',
              'Volume cut by 40% two weeks out to allow complete CNS recovery.'
            ]
          }
        ]
      }
    ]
  },

  {
    id: 'course-build',
    trackId: 'build',
    title: 'Hypertrophy Masterclass: Maximum Muscle Blueprint',
    subtitle: 'The ultimate 12-week science-based system for building dense, symmetrical muscle tissue.',
    instructor: {
      name: 'Coach Marcus Vance',
      role: 'Exercise Biomechanics Specialist & Natural Physique Coach',
      avatar: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=150&auto=format&fit=crop&q=80',
      rating: 4.95,
      students: 14200,
      bio: 'Collegiate strength coach with over 15 years coaching natural bodybuilders and athletes to elite physiques using evidence-based biomechanics.'
    },
    thumbnail: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=800&auto=format&fit=crop&q=80',
    price: 399,
    discountPrice: 199,
    rating: 4.95,
    reviewCount: 1840,
    enrolledCount: 12850,
    durationHours: 24,
    modulesCount: 5,
    lessonsCount: 28,
    badge: 'BESTSELLER',
    pdfUrl: '/pdfs/KFA_12_Week_Workout_Plans.pdf',
    level: 'All Levels',
    lastUpdated: 'November 2026',
    overview: 'This comprehensive 5-module curriculum dismantles bro-science and delivers an evidence-backed framework for progressive overload, optimal volume dosing per muscle group, recovery biology, and mesocycle periodization. Includes complete lesson readings, practical assignments, 5-question quizzes per lesson, and final certification exam.',
    features: [
      '5 Complete Modules & 28 Substantive Educational Lessons',
      '12-Week Periodized Workout Plan (4-Day Upper/Lower Split)',
      'Official 12-Week Workout Program PDF & Periodized Splits',
      'Downloadable Hypertrophy Excel Tracker + PDF Guides',
      'Full Nutrition, Caloric Surplus & Anabolic Window Protocol',
      'End-of-Lesson Quizzes + Official Certificate of Completion'
    ],
    modules: BUILD_COURSE_MODULES
  },

  {
    id: 'course-cut',
    trackId: 'cut',
    title: 'The Ultimate Shred: Sub-10% Fat Loss Protocol',
    subtitle: 'Incinerate body fat, protect 100% of lean muscle tissue, and reveal razor-sharp muscle definition.',
    instructor: {
      name: 'Dr. Sarah Chen, PhD',
      role: 'Physique Coach & Sports Nutrition Scientist',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
      rating: 4.98,
      students: 19800,
      bio: 'PhD in Nutritional Biochemistry, prep coach for hundreds of competitive athletes, and published researcher on sustainable fat loss and metabolic adaptation.'
    },
    thumbnail: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80',
    price: 499,
    discountPrice: 250,
    rating: 4.97,
    reviewCount: 2410,
    enrolledCount: 18450,
    durationHours: 22,
    modulesCount: 5,
    lessonsCount: 28,
    badge: 'POPULAR',
    pdfUrl: '/pdfs/KFA_12_Week_Workout_Plans.pdf',
    level: 'All Levels',
    lastUpdated: 'November 2026',
    overview: 'No crash diets or muscle wasting. Master the science of precision caloric deficits, protein preservation, high-volume satiety eating, low-impact NEAT optimization, and the MATADOR diet break protocol to achieve permanent single-digit body fat.',
    features: [
      '5 Complete Modules & 28 Substantive Educational Lessons',
      '3-Day Full Body Resistance Split for Maximum Muscle Retention',
      'Precision TDEE, Deficit & Macro Calculation Worksheets',
      'High-Volume Food Swaps & Satiety Engineering Guide',
      'Refeed Protocols & MATADOR Diet Break Manual',
      'End-of-Lesson Quizzes + Sub-10% Fat Loss Specialist Certificate'
    ],
    modules: CUT_COURSE_MODULES
  },

  {
    id: 'course-gain',
    trackId: 'gain',
    title: 'Skinny to Built: Complete Physique Transformation',
    subtitle: 'The beginner and hardgainer blueprint for building a strong, muscular foundation without gaining excess fat.',
    instructor: {
      name: 'Coach Darius Vance',
      role: 'Strength & Conditioning Specialist & Hardgainer Coach',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      rating: 4.93,
      students: 9400,
      bio: 'Former skinny hardgainer turned competitive strength coach, specialized in body recomposition, beginner movement mechanics, and high-calorie digestion.'
    },
    thumbnail: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&auto=format&fit=crop&q=80',
    price: 299,
    discountPrice: 150,
    rating: 4.93,
    reviewCount: 1120,
    enrolledCount: 8900,
    durationHours: 21,
    modulesCount: 5,
    lessonsCount: 28,
    badge: 'HIGH DEMAND',
    pdfUrl: '/pdfs/KFA_12_Week_Workout_Plans.pdf',
    level: 'Beginner to Intermediate',
    lastUpdated: 'November 2026',
    overview: 'Specifically engineered for beginners, individuals with low muscle mass, and the skinny-fat demographic. Learn how to achieve true body recomposition, master foundational movement patterns (push/pull/squat/hinge), navigate surplus nutrition without digestive distress, and build permanent athletic consistency.',
    features: [
      '5 Complete Modules & 28 Substantive Educational Lessons',
      'Alternating Workout A & B Foundation Split Blueprint',
      'Beginner Movement Mechanics & Form Execution Mastery',
      'Body Recomposition & Lean Surplus Nutrition Guide',
      'Tracking Body Composition (Waist vs Scale Weight)',
      'End-of-Lesson Quizzes + Transformation Specialist Certificate'
    ],
    modules: GAIN_COURSE_MODULES
  },

  {
    id: 'course-powerlifting',
    trackId: 'powerlifting',
    title: 'Absolute Power: SBD 1RM Peaking System',
    subtitle: 'Master the Squat, Bench Press, and Deadlift biomechanics to shatter PRs and build raw brute power.',
    instructor: {
      name: 'Viktor "The Iron Hammer" Kane',
      role: 'USAPL Elite Powerlifter & Strength Coach',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
      rating: 4.99,
      students: 11300,
      bio: 'USAPL National competitor with an 850kg raw total. Coached dozens of regional and national podium finishers.'
    },
    thumbnail: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=800&auto=format&fit=crop&q=80',
    price: 299,
    discountPrice: 159,
    rating: 4.98,
    reviewCount: 1650,
    enrolledCount: 10400,
    durationHours: 20,
    modulesCount: 2,
    lessonsCount: 4,
    badge: 'ELITE STRENGTH',
    pdfUrl: '/pdfs/Powerlifting_15_Week_Sumo_4xBench.pdf',
    level: 'Intermediate to Advanced',
    lastUpdated: 'November 2026',
    overview: 'Powerlifting is a game of millimeters and physics. Learn how to optimize bar path, cue intra-abdominal pressure with the valsalva maneuver, and build explosive rate of force development (RFD). Choose your specialized program (Squat, Bench Press, or Deadlift) with authentic periodized PDF blueprints.',
    features: [
      'Authentic Uploaded Powerlifting PDF Blueprints (Squat, Bench, Deadlift)',
      '1 Included in Base Price + Choose Additional Programs at +₹50 Each',
      'Detailed Routine Cues & Form Execution Standards',
      'Accessory Lift Programming for Sticking Points',
      'CNS Recovery & Deload Periodization Guide',
      'Official Powerlifting Certificate of Completion'
    ],
    modules: [
      {
        id: 'mod-p1',
        title: 'Module 1: The Biomechanics of the "Big 3"',
        duration: '3h 10m',
        lessons: [
          {
            id: 'les-p1-1',
            title: 'Squat Mastery: Low Bar vs High Bar & Hip Anatomy',
            content: `## Squat Mastery: Low Bar vs High Bar & Hip Anatomy

### 1. Introduction
The squat is the king of lower-body compound movements. To maximize weight lifted safely, your bar placement and stance width must match your individual hip anatomy.

### 2. High Bar vs. Low Bar Biomechanics
- **High Bar:** Barbell rests across the upper trapezius. Promotes a more upright torso, greater knee flexion, and higher quad recruitment.
- **Low Bar:** Barbell sits on the shelf created by the posterior deltoids. Requires a more forward torso lean, placing greater mechanical load on the posterior chain (glutes, hamstrings, and lower back), typically allowing 5–10% heavier loads.

### 3. Step-by-Step Execution Checklist
1. **The Walkout:** 3-step walkout only. Step 1: back with dominant foot; Step 2: back with other foot; Step 3: micro-adjust stance.
2. **Bracing (Valsalva Maneuver):** Inhale deeply into your belly and lower back (360-degree expansion) and brace down on your core as if taking a punch.
3. **The Descent:** Push knees out in line with toes, sit back and down into your hips.
4. **Depth:** The hip crease must pass below the top of the patella (knee) for competition-legal depth.
5. **The Ascent:** Drive hips straight up while keeping chest proud and bar centered over midfoot.

### 4. Common Squat Faults
- **Knees Caving In (Valgus Collapse):** Caused by weak glute medius or too wide a stance. Cue "screw feet into the ground".
- **Butt Wink (Pelvic Tilt):** Caused by exceeding anatomical hip socket depth. Limit depth to active mobility threshold.

### 5. Today's Action Task
Refer to your uploaded Squat Program PDF (Powerlifting_Block1_Conv_3xBench.pdf) for Week 1 target working sets and RPE guidelines.`,
            
            duration: '21:30',
            isFreePreview: true,
            summary: 'Determining your ideal stance width based on acetabulum hip socket angle and cueing leg drive.',
            keyTakeaways: [
              'Low bar shelf placement on posterior deltoids.',
              'Spreading the floor and screwing feet into the ground.',
              'Hitting competition legal depth with zero butt wink.'
            ],
            resources: ['Powerlifting_Block1_Conv_3xBench.pdf']
          },
          {
            id: 'les-p1-2',
            title: 'Bench Press: Scapular Retraction & Leg Drive Physics',
            content: `## Bench Press: Scapular Retraction & Leg Drive Physics

### 1. Introduction
The bench press is a full-body movement. Establishing a rock-solid foundation with your upper back and legs is essential for handling maximum loads without shoulder impingement.

### 2. Upper Back & Scapular Setup
- **Retract and Depress:** Pinch your shoulder blades together and pull them down into your back pockets. This creates a stable surface to press from and protects the rotator cuff.
- **Thoracic Arch:** Arch through your mid-to-upper back (thoracic spine), keeping glutes firmly on the bench at all times.

### 3. Bar Path Physics
- The optimal barbell trajectory is not a straight vertical line. It descends toward the lower sternum and follows an angled J-curve back toward the shoulders/eyes on the ascent to minimize moment arms.

### 4. Leg Drive Execution
- Plant feet firmly under or slightly behind knees.
- Cue driving your heels into the floor and pushing your body toward the head of the bench without lifting your glutes off the pad.

### 5. Common Bench Press Mistakes
- Flaring elbows to 90 degrees (keep tuck between 45 and 70 degrees).
- Bouncing the bar off the rib cage.
- Losing upper back tightness at the top of lockout.

### 6. Today's Action Task
Review your uploaded Bench Press Program PDF (Powerlifting_Block1_Conv_4xBench.pdf) and calibrate your grip width and RPE 7-8 working sets.`,
            
            duration: '18:50',
            isFreePreview: false,
            summary: 'Creating a rigid arch, pinching shoulder blades, and transferring force from the floor to the bar.',
            keyTakeaways: [
              'J-curve bar path versus straight vertical line.',
              'Grip width calculation based on forearm verticality.'
            ],
            resources: ['Powerlifting_Block1_Conv_4xBench.pdf']
          },
          {
            id: 'les-p1-3',
            title: 'Deadlift: Conventional vs Sumo Stance Breakdown',
            content: `## Deadlift: Conventional vs Sumo Stance Breakdown

### 1. Introduction
The deadlift tests absolute pulling power from a dead stop. Choosing between Conventional and Sumo stance depends directly on limb proportions and hip architecture.

### 2. Conventional vs. Sumo Stance
- **Conventional:** Feet hip-width apart, arms outside legs. Higher demand on the spinal erectors and hamstrings. Ideal for lifters with long arms and short torsos.
- **Sumo:** Feet wide, toes pointed out 30–45 degrees, arms inside legs. Shorter range of motion and higher demand on adductors, quads, and hips with a more vertical torso angle.

### 3. Pulling The Slack
- Before initiating the pull, wedge your hips into the bar, pull chest up, and pull upward against the barbell until you hear the plates click against the collar.
- This creates total body tension and prevents the hips from shooting up prematurely.

### 4. Step-by-Step Lift Execution
1. Set midfoot directly under barbell (1 inch from shins).
2. Grip the bar without moving it.
3. Bring shins forward to touch the barbell.
4. Squeeze lats back (protect armpits) and take slack out of the steel.
5. Push the floor away through midfoot until bar passes knees, then snap glutes forward to lockout.

### 5. Today's Action Task
Check your uploaded Deadlift Program PDF (Powerlifting_15_Week_Sumo_4xBench.pdf) for volume landmarks and accessory block programming.`,
            
            duration: '24:10',
            isFreePreview: false,
            summary: 'Wedging into the bar, taking the slack out of the steel, and locking out with glutes.',
            keyTakeaways: [
              'How torso and femur length determine your strongest stance.',
              'Engaging lats like you are bending the bar around your shins.'
            ],
            resources: ['Powerlifting_15_Week_Sumo_4xBench.pdf']
          }
        ]
      },
      {
        id: 'mod-p2',
        title: 'Module 2: 1RM Peaking Exam & Certificate',
        duration: '40m',
        lessons: [
          {
            id: 'les-p2-1',
            title: 'Powerlifting Biomechanics Exam',
            content: `## Powerlifting Biomechanics & 1RM Peaking Certification

### 1. Exam Overview
This certification exam evaluates your mastery of the biomechanics, setup protocols, and attempt selection strategies for the Squat, Bench Press, and Deadlift.

### 2. Exam Requirements
- 80% passing score (minimum 4 out of 5 correct).
- Covers bar paths, bracing mechanics, RIR management, and taper periodization.

### 3. Preparation Checklist
- Review Low Bar vs High Bar squat placement and hip socket anatomy.
- Review J-curve bench press bar path and scapular depression.
- Review slack pulling and hip wedging on the deadlift.

### 4. Today's Action Task
Switch to the **Lesson Quiz** tab above to complete your final certification examination.`,
            
            duration: '25:00',
            isFreePreview: false,
            isQuiz: true,
            summary: 'Test your grasp of leverage, bar paths, and fatigue management to earn your strength credentials.',
            quizData: {
              title: 'Elite Strength Biomechanics Exam',
              passingScore: 80,
              questions: [
                {
                  id: 'qp1',
                  question: 'Why is taking the "slack out of the bar" crucial before breaking a heavy deadlift off the floor?',
                  options: [
                    'It makes the bar lighter',
                    'It removes mechanical play, establishes maximum intra-abdominal pressure, and prevents the hips from shooting up early',
                    'It stretches the forearms only',
                    'It is just for show'
                  ],
                  correctAnswer: 1,
                  explanation: 'Pulling the slack pre-tenses the entire posterior chain, anchors the hips, and prevents energy leakage before the plates leave the floor.'
                },
                {
                  id: 'qp2',
                  question: 'What is the optimal bar path for a high-performance bench press?',
                  options: [
                    'A curved J-path that presses back toward the face/shoulders off the chest',
                    'A straight vertical line directly over the sternum',
                    'Pressing away toward the feet',
                    'Zig-zag pattern'
                  ],
                  correctAnswer: 0,
                  explanation: 'A J-curve path aligns the barbell over the glenohumeral joint (center of rotation) at lockout, drastically reducing moment arms.'
                }
              ]
            }
          }
        ]
      }
    ]
  }
];

import React from 'react';
import { TRACKS, COURSES } from '../../data/coursesData';
import { Dumbbell, Flame, Zap, Trophy, Star, Clock, Users, ArrowRight, CheckCircle } from 'lucide-react';

const TRACK_ICONS = { build: Dumbbell, cut: Flame, gain: Zap, powerlifting: Trophy };
const TRACK_COLORS = {
  build:        { accent: 'emerald', border: 'border-emerald-500', ring: 'ring-emerald-500/20', glow: 'shadow-emerald-500/20', btn: 'bg-emerald-500 hover:bg-emerald-400' },
  cut:          { accent: 'cyan',    border: 'border-cyan-500',    ring: 'ring-cyan-500/20',    glow: 'shadow-cyan-500/20',    btn: 'bg-cyan-500 hover:bg-cyan-400' },
  gain:         { accent: 'amber',   border: 'border-amber-500',   ring: 'ring-amber-500/20',   glow: 'shadow-amber-500/20',   btn: 'bg-amber-500 hover:bg-amber-400' },
  powerlifting: { accent: 'purple',  border: 'border-purple-500',  ring: 'ring-purple-500/20',  glow: 'shadow-purple-500/20',  btn: 'bg-purple-500 hover:bg-purple-400' },
};

export const TrackSelector = ({ selectedTrackId, onSelectTrack, onViewCourse, setCurrentView }) => {
  const selectedCourse = COURSES.find(c => c.trackId === selectedTrackId);
  const selectedTrack = TRACKS.find(t => t.id === selectedTrackId);

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-black text-white font-display mb-2">🏋️ Choose Your Training Track</h1>
        <p className="text-slate-400">Select the goal that matches your objective. You can enrol in multiple tracks.</p>
      </div>

      {/* Track Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
        {TRACKS.map(track => {
          const Icon = TRACK_ICONS[track.id];
          const color = TRACK_COLORS[track.id];
          const isSelected = selectedTrackId === track.id;
          return (
            <button
              key={track.id}
              onClick={() => onSelectTrack(track.id)}
             className={`p-4 rounded-xl border-2 transition-all text-left ${
  isSelected
    ? `${color.border} bg-slate-900 shadow-lg ${color.glow} ring-4 ${color.ring}`
    : 'border-slate-800 bg-slate-900/50 hover:border-slate-700'
}`}            >
              <Icon className={`w-6 h-6 mb-2 ${isSelected ? `text-${color.accent}-400` : 'text-slate-500'}`} />
              <div className={`text-xs font-bold uppercase tracking-wider ${isSelected ? `text-${color.accent}-400` : 'text-slate-400'}`}>
                {track.id.toUpperCase()}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{track.tagline}</div>
            </button>
          );
        })}
      </div>

      {/* Full Access Bundle Banner */}
      <div className="mb-10 p-6 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border border-emerald-500/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl shadow-emerald-900/20">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase tracking-wider mb-2">
            <Star className="w-3 h-3" /> Best Value
          </div>
          <h3 className="text-xl font-black text-white font-display mb-1">Kaizen Full Access Pass</h3>
          <p className="text-sm text-slate-400">Unlock all 4 training tracks + PDF library and calculators for one price.</p>
        </div>
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
          <div className="text-center md:text-right">
            <div className="text-2xl font-black text-emerald-400">₹559</div>
            <div className="text-xs text-slate-500 line-through">₹1,496</div>
          </div>
          <button 
            onClick={() => onViewCourse(COURSES.find(c => c.trackId === 'bundle'))}
            className="w-full sm:w-auto px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-sm transition-all border-beam-btn hover:scale-[1.02] active:scale-95"
          >
            Get Full Access
          </button>
        </div>
      </div>

      {/* Selected Track Detail */}
      {selectedCourse && selectedTrack && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Left: Info */}
          <div className="lg:col-span-3 space-y-6">
            <div>
              <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold border mb-3
                ${TRACK_COLORS[selectedTrackId].border} bg-${TRACK_COLORS[selectedTrackId].accent}-500/10 text-${TRACK_COLORS[selectedTrackId].accent}-400`}>
                {React.createElement(TRACK_ICONS[selectedTrackId], { className: 'w-3.5 h-3.5' })}
                {selectedTrack.name}
              </div>
              <h2 className="text-2xl font-black text-white font-display leading-tight mb-2">{selectedCourse.title}</h2>
              <p className="text-slate-300 leading-relaxed">{selectedCourse.overview}</p>
            </div>

            {/* What's included */}
            <div className="p-5 rounded-xl bg-slate-900 border border-slate-800">
              <h3 className="text-sm font-bold text-white mb-3">📦 What's Included in This Track</h3>
              <div className="space-y-2">
                {[
                  '📑 Full 12-Week Workout PDF Blueprint & Progression Rules',
                  '🏋️ Exact weekly exercise splits, sets, reps & coaching notes',
                  '📊 Interactive workout tracker with sets/reps/weight/RIR logging',
                  '🍽️ Nutrition calculator — calories, protein, adjustment rules',
                  '📅 Full 12-week periodized program',
                  '✅ Weekly habit & progress checklist',
                  '📄 High-resolution printable routines & tracking sheets',
                  '🏆 Certificate of completion (after quiz)',
                ].map(f => (
                  <div key={f} className="flex items-start gap-2 text-sm text-slate-300">
                    <CheckCircle className={`w-4 h-4 mt-0.5 flex-shrink-0 text-${TRACK_COLORS[selectedTrackId].accent}-400`} />
                    {f}
                  </div>
                ))}
              </div>
            </div>

            {/* Instructor */}
            <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
              <img src={selectedCourse.instructor.avatar} alt={selectedCourse.instructor.name}
                className="w-14 h-14 rounded-xl object-cover ring-2 ring-slate-700" />
              <div>
                <div className="text-sm font-bold text-white">{selectedCourse.instructor.name}</div>
                <div className="text-xs text-slate-400 mb-1">{selectedCourse.instructor.role}</div>
                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1"><Star className="w-3 h-3 text-amber-400 fill-amber-400" />{selectedCourse.instructor.rating}</span>
                  <span className="flex items-center gap-1"><Users className="w-3 h-3" />{selectedCourse.instructor.students.toLocaleString()} students</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Sticky Card */}
          <div className="lg:col-span-2">
            <div className="sticky top-24 p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <img src={selectedCourse.thumbnail} alt={selectedCourse.title}
                className="w-full h-44 object-cover rounded-xl" />
              <div className="flex items-baseline gap-3">
                <span className="text-3xl font-black text-white">₹{selectedCourse.discountPrice}</span>
                <span className="text-slate-500 line-through">₹{selectedCourse.price}</span>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">50% OFF</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                {[
                  { label: 'Lessons', value: selectedCourse.lessonsCount },
                  { label: 'Hours', value: selectedCourse.durationHours },
                  { label: 'Modules', value: selectedCourse.modulesCount },
                ].map(s => (
                  <div key={s.label} className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                    <div className="font-bold text-white">{s.value}</div>
                    <div className="text-slate-500">{s.label}</div>
                  </div>
                ))}
              </div>
              <button
                onClick={() => onViewCourse(selectedCourse)}
                className={`w-full py-3.5 ${TRACK_COLORS[selectedTrackId].btn} text-slate-950 font-bold rounded-xl text-sm transition-all flex items-center justify-center gap-2 border-beam-btn hover:scale-[1.02] active:scale-95`}
              >
                View Full Course <ArrowRight className="w-4 h-4" />
              </button>
              <div className="text-center text-[11px] text-slate-500">
                🔒 30-day money-back guarantee · Lifetime access
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

const ALL_COURSE_IDS = [
  'course-bundle-all',
  'course-build',
  'course-cut',
  'course-gain',
  'course-powerlifting',
];

const DEFAULT_DEMO_USER = {
  id: 'usr-101',
  name: 'Alex Mercer',
  email: 'alex.mercer@kaizen.fit',
  role: 'student',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  currentStreak: 14,
  enrolledCourseIds: ['course-build'], // Demo user starts with Build track enrolled
  completedLessonIds: ['les-b1-1'],
  quizScores: {},
  joinedDate: 'August 2026'
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('kaizen_auth_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Clear any old hardcoded session where all courses were forcefully enrolled
        if (parsed.email === 'alex.mercer@kaizen.fit' && parsed.enrolledCourseIds?.length > 2) {
          localStorage.removeItem('kaizen_auth_user');
          return null;
        }
        return parsed;
      }
      return null; // Public visitors start as unauthenticated guests!
    } catch (e) {
      return null;
    }
  });

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState('login'); // 'login' or 'signup'
  const [pendingCourseEnroll, setPendingCourseEnroll] = useState(null);

  useEffect(() => {
    if (user) {
      localStorage.setItem('kaizen_auth_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('kaizen_auth_user');
    }
  }, [user]);

  const login = (email, password) => {
    // If demo login requested
    if (email === 'alex.mercer@kaizen.fit') {
      setUser(DEFAULT_DEMO_USER);
      setAuthModalOpen(false);
      return { success: true };
    }
    const loggedUser = {
      id: 'usr-' + Date.now(),
      email: email || 'athlete@kaizen.fit',
      name: email ? email.split('@')[0] : 'Athlete',
      role: 'student',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      currentStreak: 1,
      enrolledCourseIds: [],
      completedLessonIds: [],
      quizScores: {},
      joinedDate: 'November 2026'
    };
    setUser(loggedUser);
    setAuthModalOpen(false);
    return { success: true };
  };

  const signup = (name, email, password) => {
    const newUser = {
      id: 'usr-' + Date.now(),
      name: name || 'New Athlete',
      email: email,
      role: 'student',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
      currentStreak: 1,
      enrolledCourseIds: [],
      completedLessonIds: [],
      quizScores: {},
      joinedDate: 'November 2026'
    };
    setUser(newUser);
    setAuthModalOpen(false);
    return { success: true };
  };

  const logout = () => {
    setUser(null);
  };

  const isEnrolled = (courseId) => {
    if (!user) return false;
    if (user.enrolledCourseIds?.includes('course-bundle-all')) return true;
    return user.enrolledCourseIds?.includes(courseId);
  };

  const enrollInCourse = (courseId) => {
    const toEnroll = courseId === 'course-bundle-all'
      ? ['course-bundle-all', 'course-build', 'course-cut', 'course-gain', 'course-powerlifting']
      : [courseId];

    setUser(prev => {
      if (!prev) {
        return {
          id: 'usr-' + Date.now(),
          name: 'Kaizen Athlete',
          email: 'athlete@kaizen.fit',
          role: 'student',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
          currentStreak: 1,
          enrolledCourseIds: toEnroll,
          completedLessonIds: [],
          quizScores: {},
          joinedDate: 'November 2026'
        };
      }
      return {
        ...prev,
        enrolledCourseIds: Array.from(new Set([...(prev.enrolledCourseIds || []), ...toEnroll]))
      };
    });
    return true;
  };

  const toggleLessonCompletion = (lessonId) => {
    if (!user) return;
    setUser(prev => {
      const alreadyCompleted = prev.completedLessonIds.includes(lessonId);
      const updated = alreadyCompleted
        ? prev.completedLessonIds.filter(id => id !== lessonId)
        : [...prev.completedLessonIds, lessonId];
      return { ...prev, completedLessonIds: updated };
    });
  };

  const isLessonCompleted = (lessonId) => {
    if (!user) return false;
    return user.completedLessonIds?.includes(lessonId);
  };

  const recordQuizResult = (courseId, score, passed) => {
    if (!user) return;
    setUser(prev => ({
      ...prev,
      quizScores: {
        ...prev.quizScores,
        [courseId]: { score, passed, date: new Date().toISOString() }
      }
    }));
  };

  const openAuth = (mode = 'login', pendingCourse = null) => {
    setAuthMode(mode);
    setPendingCourseEnroll(pendingCourse);
    setAuthModalOpen(true);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        logout,
        isEnrolled,
        enrollInCourse,
        toggleLessonCompletion,
        isLessonCompleted,
        recordQuizResult,
        authModalOpen,
        setAuthModalOpen,
        authMode,
        setAuthMode,
        openAuth,
        pendingCourseEnroll,
        setPendingCourseEnroll
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);

import React from 'react';
import {
  CheckCircle,
  AlertTriangle,
  Flame,
  Award,
  BookOpen,
  ArrowRight,
  Sparkles,
  ClipboardCheck,
  Zap,
} from 'lucide-react';

/**
 * Custom Markdown & Structure Renderer for Kaizen Fitness Academy Lessons
 * Converts structured lesson content into an interactive, beautifully styled editorial layout.
 */
export const LessonContentRenderer = ({ content, lesson, color = 'emerald' }) => {
  // If content is missing, dynamically build a comprehensive lesson guide from lesson metadata
  const effectiveContent = content || (lesson ? `## ${lesson.title || 'Lesson Overview'}

### Lesson Overview
${lesson.summary || 'Welcome to this in-depth educational chapter from the Kaizen Fitness Academy curriculum. Follow the structured protocols below to master these training concepts.'}

### Core Principles & Takeaways
${lesson.keyTakeaways?.map(t => `- ${t}`).join('\n') || '- Master exercise biomechanics and control tempo on every repetition.\n- Record all sets, loads, and RIR in the Kaizen Workout Log.\n- Prioritize 7.5 to 9 hours of sleep and adequate protein intake.'}

### Step-by-Step Implementation Protocol
1. **Warm-Up:** Perform 5–10 minutes of general cardiovascular warm-up followed by exercise-specific ramp-up sets.
2. **Execution:** Execute all prescribed working sets with strict technical form, stopping 1–2 reps before muscular failure.
3. **Tracking:** Immediately log your weights, repetitions, and perceived exertion in the Kaizen Workout Tracker.

### Common Mistakes to Avoid
- Sacrificing form for heavier weight on the barbell.
- Neglecting the eccentric (lowering) phase of the lift.
- Inconsistent training frequency or skipping planned recovery days.

### Today's Action Task
Review your blueprint parameters, execute today's target training volume, and complete the knowledge assessment quiz for this lesson.

### Completion Requirement
Read through all educational principles above and achieve at least 80% on the lesson quiz.` : null);

  if (!effectiveContent) {
    return (
      <div className="p-8 text-center text-slate-400">
        <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p>Loading lesson educational guide...</p>
      </div>
    );
  }

  const lines = effectiveContent.split('\n');
  const elements = [];
  let currentTable = null;
  let inCodeBlock = false;
  let codeBuffer = [];

  const flushTable = () => {
    if (currentTable && currentTable.rows.length > 0) {
      elements.push({
        type: 'table',
        headers: currentTable.headers,
        rows: currentTable.rows,
      });
      currentTable = null;
    }
  };

  const flushCode = () => {
    if (codeBuffer.length > 0) {
      elements.push({
        type: 'code',
        code: codeBuffer.join('\n'),
      });
      codeBuffer = [];
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];
    const line = rawLine.trim();

    // Code block fences
    if (line.startsWith('```')) {
      if (inCodeBlock) {
        flushCode();
        inCodeBlock = false;
      } else {
        flushTable();
        inCodeBlock = true;
      }
      continue;
    }

    if (inCodeBlock) {
      codeBuffer.push(rawLine);
      continue;
    }

    // Markdown Table handling
    if (line.startsWith('|') && line.endsWith('|')) {
      const cells = line
        .split('|')
        .slice(1, -1)
        .map((c) => c.trim());

      // Check if it's separator line (e.g. |:---|:---|)
      if (cells.every((c) => /^:?-+:?$/.test(c))) {
        continue;
      }

      if (!currentTable) {
        currentTable = { headers: cells, rows: [] };
      } else {
        currentTable.rows.push(cells);
      }
      continue;
    } else {
      flushTable();
    }

    // Empty lines
    if (!line) {
      continue;
    }

    // Headings
    if (line.startsWith('## ')) {
      elements.push({ type: 'h2', text: line.replace('## ', '') });
    } else if (line.startsWith('### ')) {
      elements.push({ type: 'h3', text: line.replace('### ', '') });
    } else if (line.startsWith('#### ')) {
      elements.push({ type: 'h4', text: line.replace('#### ', '') });
    } else if (/^\d+\.\s/.test(line)) {
      elements.push({
        type: 'ordered-list-item',
        text: line.replace(/^\d+\.\s*/, ''),
      });
    } else if (line.startsWith('- ') || line.startsWith('* ')) {
      elements.push({
        type: 'unordered-list-item',
        text: line.replace(/^[-*]\s*/, ''),
      });
    } else {
      elements.push({ type: 'p', text: line });
    }
  }

  flushTable();
  flushCode();

  // Helper to render bold markdown (**text**)
  const renderInline = (str) => {
    if (!str) return '';
    const parts = [];
    let remaining = str;
    let key = 0;

    // Match **bold**
    while (remaining.length > 0) {
      const boldMatch = remaining.match(/\*\*(.*?)\*\*/);
      if (boldMatch && boldMatch.index !== undefined) {
        const pre = remaining.substring(0, boldMatch.index);
        if (pre) parts.push(<span key={key++}>{pre}</span>);
        parts.push(
          <strong key={key++} className="font-bold text-white">
            {boldMatch[1]}
          </strong>
        );
        remaining = remaining.substring(boldMatch.index + boldMatch[0].length);
      } else {
        parts.push(<span key={key++}>{remaining}</span>);
        break;
      }
    }
    return parts;
  };

  // Color mappings
  const colorStyles = {
    emerald: {
      accentText: 'text-emerald-400',
      accentBg: 'bg-emerald-500/10',
      accentBorder: 'border-emerald-500/30',
      badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
      taskBg: 'bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-950',
    },
    cyan: {
      accentText: 'text-cyan-400',
      accentBg: 'bg-cyan-500/10',
      accentBorder: 'border-cyan-500/30',
      badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
      taskBg: 'bg-gradient-to-r from-cyan-950/40 via-slate-900 to-slate-950',
    },
    amber: {
      accentText: 'text-amber-400',
      accentBg: 'bg-amber-500/10',
      accentBorder: 'border-amber-500/30',
      badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
      taskBg: 'bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950',
    },
    purple: {
      accentText: 'text-purple-400',
      accentBg: 'bg-purple-500/10',
      accentBorder: 'border-purple-500/30',
      badge: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
      taskBg: 'bg-gradient-to-r from-purple-950/40 via-slate-900 to-slate-950',
    },
  }[color] || {
    accentText: 'text-emerald-400',
    accentBg: 'bg-emerald-500/10',
    accentBorder: 'border-emerald-500/30',
    badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    taskBg: 'bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-950',
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 text-slate-300 leading-relaxed font-sans pb-16">
      {elements.map((el, idx) => {
        switch (el.type) {
          case 'h2':
            return (
              <div key={idx} className="pt-2 pb-1 border-b border-slate-800">
                <h2 className="text-2xl sm:text-3xl font-black text-white font-display tracking-tight flex items-center gap-2">
                  <Sparkles className={`w-6 h-6 ${colorStyles.accentText}`} />
                  {renderInline(el.text)}
                </h2>
              </div>
            );

          case 'h3': {
            const headingText = el.text.toLowerCase();
            const isActionTask = headingText.includes("action task");
            const isCommonMistake = headingText.includes("mistake");
            const isObjectives = headingText.includes("objective");
            const isCompletion = headingText.includes("completion");
            const isScience = headingText.includes("scientific");

            return (
              <div
                key={idx}
                className={`pt-6 pb-2 flex items-center gap-2.5 font-bold text-lg text-white font-display ${
                  isActionTask
                    ? 'text-amber-400'
                    : isCommonMistake
                    ? 'text-rose-400'
                    : isScience
                    ? colorStyles.accentText
                    : ''
                }`}
              >
                {isActionTask && <ClipboardCheck className="w-5 h-5 text-amber-400" />}
                {isCommonMistake && <AlertTriangle className="w-5 h-5 text-rose-400" />}
                {isObjectives && <Zap className={`w-5 h-5 ${colorStyles.accentText}`} />}
                {isCompletion && <Award className="w-5 h-5 text-emerald-400" />}
                {isScience && <BookOpen className={`w-5 h-5 ${colorStyles.accentText}`} />}
                <span>{renderInline(el.text)}</span>
              </div>
            );
          }

          case 'h4':
            return (
              <h4 key={idx} className="text-sm font-bold text-slate-200 uppercase tracking-wider pt-2">
                {renderInline(el.text)}
              </h4>
            );

          case 'p':
            return (
              <p key={idx} className="text-sm sm:text-base text-slate-300 leading-relaxed">
                {renderInline(el.text)}
              </p>
            );

          case 'ordered-list-item':
            return (
              <div key={idx} className="flex items-start gap-3 text-sm sm:text-base text-slate-200 pl-2">
                <div className={`w-5 h-5 rounded-full ${colorStyles.accentBg} ${colorStyles.accentText} border ${colorStyles.accentBorder} flex items-center justify-center font-bold text-xs flex-shrink-0 mt-0.5`}>
                  ✓
                </div>
                <div className="flex-1">{renderInline(el.text)}</div>
              </div>
            );

          case 'unordered-list-item':
            return (
              <div key={idx} className="flex items-start gap-3 text-sm sm:text-base text-slate-200 pl-2">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-2.5 flex-shrink-0" />
                <div className="flex-1">{renderInline(el.text)}</div>
              </div>
            );

          case 'code':
            return (
              <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs sm:text-sm text-slate-300 overflow-x-auto shadow-inner">
                <pre className="whitespace-pre">{el.code}</pre>
              </div>
            );

          case 'table':
            return (
              <div key={idx} className="my-4 overflow-x-auto rounded-xl border border-slate-800 shadow-xl">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-slate-900/90 text-white font-bold border-b border-slate-800">
                    <tr>
                      {el.headers.map((h, hIdx) => (
                        <th key={hIdx} className="px-4 py-3 tracking-wider font-display">
                          {renderInline(h)}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 bg-slate-950/60">
                    {el.rows.map((row, rIdx) => (
                      <tr key={rIdx} className={rIdx % 2 === 0 ? 'bg-slate-950/40' : 'bg-slate-900/20'}>
                        {row.map((cell, cIdx) => (
                          <td key={cIdx} className="px-4 py-3 text-slate-300">
                            {renderInline(cell)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );

          default:
            return null;
        }
      })}
    </div>
  );
};

import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  X, 
  CreditCard, 
  CheckCircle, 
  ShieldCheck, 
  Lock, 
  Tag, 
  Sparkles, 
  ArrowRight,
  Clock,
  Award
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PowerliftingProgramSelector, savePurchasedPrograms } from '../course/PowerliftingProgramSelector';
import { PL_ADDON_PRICE } from '../../data/powerliftingPrograms';

export const CheckoutModal = ({ course, isOpen, onClose, onSuccess }) => {
  const { user, enrollInCourse, openAuth } = useAuth();
  
  const [promoCode, setPromoCode] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoError, setPromoError] = useState('');
  
  const [addPersonalTraining, setAddPersonalTraining] = useState(false);
  const PT_PRICE = 159;

  // Powerlifting program selection
  const [plSelectedIds, setPlSelectedIds] = useState([]);
  const isPowerliftingCourse = course?.trackId === 'powerlifting';

  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen || !course) return null;

  // Calculate powerlifting addon cost
  const getPLAddonCost = () => {
    if (!isPowerliftingCourse) return 0;
    const existingOwned = (() => {
      try {
        return JSON.parse(localStorage.getItem('kaizen_pl_programs') || '[]');
      } catch { return []; }
    })();
    const newSelections = plSelectedIds.filter(id => !existingOwned.includes(id));
    const freeSlots = Math.max(0, 1 - existingOwned.length);
    const freeUsed = Math.min(freeSlots, newSelections.length);
    const paidAddons = Math.max(0, newSelections.length - freeUsed);
    return paidAddons * PL_ADDON_PRICE;
  };

  const basePrice = course.discountPrice || course.price;
  const coursePrice = discountPercent > 0 
    ? Math.max(0, Math.round(basePrice * (1 - discountPercent / 100))) 
    : basePrice;
  const plAddonCost = getPLAddonCost();
  const finalPrice = coursePrice + (addPersonalTraining ? PT_PRICE : 0) + plAddonCost;

  const handleApplyPromo = (e) => {
    e.preventDefault();
    setPromoError('');
    const code = promoCode.trim().toUpperCase();

    if (code === 'SHRED20' || code === 'IRON20') {
      setDiscountPercent(20);
      setPromoApplied(true);
    } else if (code === 'VIP50' || code === 'LAUNCH50') {
      setDiscountPercent(50);
      setPromoApplied(true);
    } else {
      setPromoError('Invalid promo code. Try "SHRED20" or "LAUNCH50".');
    }
  };

  const canCheckout = isPowerliftingCourse ? plSelectedIds.length > 0 : true;

  const handleProcessPayment = () => {

    if (!user) {
      onClose();
      openAuth('signup', course.id);
      return;
    }

    if (!canCheckout) return;

    setIsProcessing(true);

    // Redirect to the user's personal Razorpay Payment Page in a new tab with exact amount
    const payUrl = `https://razorpay.me/@rajashokrai?amount=${finalPrice}`;
    window.open(payUrl, '_blank');

    // Since we don't have server-side webhooks yet, we will simulate the success callback 
    // after they click the link so they can access their course in this MVP.
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      enrollInCourse(course.id);

      // Save powerlifting program selections
      if (isPowerliftingCourse && plSelectedIds.length > 0) {
        savePurchasedPrograms(plSelectedIds);
      }

      try {
        confetti({
          particleCount: 150,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#22c55e', '#06b6d4', '#eab308', '#ffffff']
        });
      } catch (e) {}

      setTimeout(() => {
        setIsSuccess(false);
        onClose();
        if (onSuccess) onSuccess(course);
      }, 3000);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        
        {/* Top Gradient */}
        <div className="h-1.5 bg-gradient-to-r from-emerald-500 via-cyan-500 to-amber-500 flex-shrink-0" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess ? (
          <div className="p-10 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 mx-auto flex items-center justify-center animate-bounce">
              <CheckCircle className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-bold text-white font-display">
              Enrollment Confirmed!
            </h3>
            <p className="text-sm text-slate-300 max-w-md mx-auto">
              Welcome to <span className="text-emerald-400 font-semibold">{course.title}</span>. All modules and downloadable PDFs are now permanently unlocked.
            </p>
            {isPowerliftingCourse && plSelectedIds.length > 0 && (
              <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/30 text-xs text-purple-200 max-w-md mx-auto text-left">
                <div className="font-bold text-purple-400 text-sm mb-1">
                  🏋️ {plSelectedIds.length} Program{plSelectedIds.length > 1 ? 's' : ''} Unlocked!
                </div>
                <p className="text-slate-300">
                  Your selected powerlifting PDFs are now available for download in your dashboard.
                </p>
              </div>
            )}
            {addPersonalTraining && (
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200 max-w-md mx-auto text-left space-y-1">
                <div className="font-bold text-amber-400 flex items-center gap-1.5 text-sm">
                  <Sparkles className="w-4 h-4 text-amber-400" /> Personal Training &amp; Diet Activated!
                </div>
                <p className="text-slate-300">
                  Please email your current bodyweight, height, and goal to{' '}
                  <a href="mailto:rajjj3209@gmail.com" className="text-amber-400 font-bold underline">
                    rajjj3209@gmail.com
                  </a>{' '}
                  to receive your customized diet plan &amp; tailored exercise routine!
                </p>
              </div>
            )}
            <p className="text-xs text-slate-500">Redirecting to your classroom...</p>
          </div>
        ) : (
          <div className="p-6 sm:p-8 overflow-y-auto flex-1">
            <div className="flex items-center gap-2 text-xs text-emerald-400 font-semibold tracking-wider uppercase mb-3">
              <Lock className="w-3.5 h-3.5" />
              Secure 256-Bit SSL Checkout
            </div>

            {/* Course Summary Card */}
            <div className="flex flex-col sm:flex-row gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800 mb-6">
              <img
                src={course.thumbnail}
                alt={course.title}
                className="w-full sm:w-28 h-24 sm:h-20 rounded-lg object-cover"
              />
              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase">
                      {course.trackId} Track
                    </span>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {course.durationHours} Hours
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white leading-snug line-clamp-1">
                    {course.title}
                  </h4>
                  <p className="text-xs text-slate-400">By {course.instructor.name}</p>
                </div>

                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-xl font-extrabold text-white font-display">
                    ₹{coursePrice}
                  </span>
                  {course.price > course.discountPrice && (
                    <span className="text-xs text-slate-500 line-through">
                      ₹{course.price}
                    </span>
                  )}
                  {discountPercent > 0 && (
                    <span className="text-xs text-emerald-400 font-bold">
                      ({discountPercent}% OFF applied)
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* ── Powerlifting Program Selection ── */}
            {isPowerliftingCourse && (
              <div className="mb-6">
                <PowerliftingProgramSelector
                  mode="checkout"
                  selectedIds={plSelectedIds}
                  onSelectionChange={setPlSelectedIds}
                />
              </div>
            )}

            {/* Promo Code Box */}
            <form onSubmit={handleApplyPromo} className="mb-4">
              <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Promo Code</span>
                <span className="text-[11px] text-emerald-400/80">Use code: <strong>SHRED20</strong></span>
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    placeholder="Enter coupon (e.g. SHRED20)"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white uppercase placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-all"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold border border-slate-700 transition-colors"
                >
                  Apply
                </button>
              </div>
              {promoError && (
                <p className="text-[11px] text-rose-400 mt-1">{promoError}</p>
              )}
              {promoApplied && (
                <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" /> {discountPercent}% discount activated!
                </p>
              )}
            </form>

            {/* ── Order Bump: 1-on-1 Personal Training by Admin/Coach ── */}
            <div
              onClick={() => setAddPersonalTraining(prev => !prev)}
              className={`mb-5 p-4 rounded-xl border-2 transition-all cursor-pointer select-none ${
                addPersonalTraining
                  ? 'bg-amber-500/10 border-amber-500/70 shadow-lg shadow-amber-500/15'
                  : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={addPersonalTraining}
                  onChange={(e) => setAddPersonalTraining(e.target.checked)}
                  onClick={(e) => e.stopPropagation()}
                  className="mt-1 w-4 h-4 rounded border-slate-700 text-amber-500 focus:ring-amber-500 cursor-pointer accent-amber-500"
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 tracking-wider flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Highly Effective VIP Add-on
                    </span>
                    <span className="text-sm font-black text-amber-400 font-display">
                      +₹{PT_PRICE} <span className="text-[10px] text-slate-400 font-normal">one-time</span>
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white leading-snug">
                    Personal Training &amp; Custom Diet by Head Coach (Admin)
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    Customized daily calorie &amp; macro targets, tailored exercise swaps for your specific equipment or injuries, plus direct 1-on-1 coach review.
                  </p>
                  <div className="mt-2 text-[11px] text-amber-400/90 font-medium flex flex-wrap items-center gap-2">
                    <span>✓ Custom Diet Blueprint</span>
                    <span>·</span>
                    <span>✓ Injury-Safe Exercise Swaps</span>
                    <span>·</span>
                    <span>✓ Direct Coach Guidance</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Payment Method - Razorpay UPI */}
            <div className="space-y-3 mb-6 p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-black text-xs">
                    UPI
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      Instant UPI &amp; Cards Checkout
                      <span className="text-[10px] px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 rounded font-semibold">Razorpay Verified</span>
                    </div>
                    <div className="text-[11px] text-slate-400">Google Pay · PhonePe · Paytm · BHIM · Cred · Cards</div>
                  </div>
                </div>
                <Lock className="w-4 h-4 text-emerald-400" />
              </div>

              <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-1">
                <div className="flex items-center justify-between">
                  <span>Merchant:</span>
                  <span className="text-white font-medium">Kaizen Academy (@rajashokrai)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Instant Delivery:</span>
                  <span className="text-emerald-400 font-medium">Full Course + PDF{isPowerliftingCourse ? ' Programs' : ' Blueprint'} Unlocked</span>
                </div>
              </div>
            </div>

            {/* Total and Checkout CTA */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-4">
              <div>
                <p className="text-xs text-slate-400">Total Billed Today</p>
                <div className="flex flex-col">
                  <span className="text-2xl font-black text-emerald-400 font-display">₹{finalPrice} INR</span>
                  <div className="text-[10px] text-slate-400 space-y-0.5">
                    {isPowerliftingCourse && plAddonCost > 0 && (
                      <div className="text-purple-400 font-medium">
                        Course (₹{coursePrice}) + Programs (₹{plAddonCost})
                        {addPersonalTraining ? ` + PT (₹${PT_PRICE})` : ''}
                      </div>
                    )}
                    {!isPowerliftingCourse && addPersonalTraining && (
                      <div className="text-amber-400 font-medium">
                        Includes Course (₹{coursePrice}) + Personal Training (₹{PT_PRICE})
                      </div>
                    )}
                    {isPowerliftingCourse && plAddonCost === 0 && addPersonalTraining && (
                      <div className="text-amber-400 font-medium">
                        Course (₹{coursePrice}) + Personal Training (₹{PT_PRICE})
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <button
                  type="button"
                  onClick={handleProcessPayment}
                  disabled={isProcessing || !canCheckout}
                  className="flex-1 max-w-xs py-3.5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-extrabold rounded-xl text-sm shadow-lg shadow-emerald-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50 border-beam-btn hover:scale-[1.02] active:scale-95"
                >
                {isProcessing ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    Opening Razorpay...
                  </span>
                ) : (
                  <>
                    <span>Pay ₹{finalPrice} with UPI</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>

            <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-[11px] text-slate-500">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> 30-Day Guarantee
              </span>
              <span className="flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-amber-400" /> Lifetime Access
              </span>
              <span className="text-slate-600">·</span>
              <a href="mailto:rajjj3209@gmail.com" className="text-slate-400 hover:text-emerald-400 transition-colors">
                Need Help? rajjj3209@gmail.com
              </a>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};

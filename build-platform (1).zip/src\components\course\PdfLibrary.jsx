import React, { useState } from 'react';
import { DOWNLOADABLE_PDFS } from '../../data/downloadablePdfs';
import { TRACKS } from '../../data/coursesData';
import { useAuth } from '../../context/AuthContext';
import { FileText, Download, Lock, Dumbbell, Flame, Zap, Trophy, Eye, ExternalLink, X, CheckCircle } from 'lucide-react';
import { getPurchasedPrograms } from './PowerliftingProgramSelector';

const TRACK_ICONS = { build: Dumbbell, cut: Flame, gain: Zap, powerlifting: Trophy, bundle: Trophy };
const TRACK_COLORS = {
  build: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
  cut: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
  gain: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  powerlifting: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
  bundle: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
};

const PL_PDF_MAP = {
  'pdf-pl-squat': 'pl-squat',
  'pdf-pl-bench': 'pl-bench',
  'pdf-pl-deadlift': 'pl-deadlift',
};

export const PdfLibrary = ({ selectedTrackId, onSelectTrack }) => {
  const { user, isEnrolled, openAuth } = useAuth();
  const [filter, setFilter] = useState('all');
  const [downloadedIds, setDownloadedIds] = useState([]);
  const [previewPdf, setPreviewPdf] = useState(null);

  const pdfs = filter === 'all' ? DOWNLOADABLE_PDFS : DOWNLOADABLE_PDFS.filter(p => p.trackId === filter || (filter === 'bundle' && p.trackId === 'bundle'));

  const checkUserAccess = (pdf) => {
    if (!user) return false;
    if (isEnrolled('course-bundle-all')) return true;

    // Check specific Powerlifting program unlock
    if (pdf.trackId === 'powerlifting') {
      const plProgId = PL_PDF_MAP[pdf.id];
      const purchasedPL = getPurchasedPrograms();
      if (plProgId && purchasedPL.includes(plProgId)) return true;
      if (isEnrolled('course-powerlifting') && purchasedPL.length === 0) {
        // If enrolled in course but no specific program stored, allow first
        return true;
      }
      return false;
    }

    if (isEnrolled('course-' + pdf.trackId)) return true;
    return false;
  };

  const handleDownload = (pdf) => {
    if (!user) { openAuth('signup'); return; }
    if (!checkUserAccess(pdf)) {
      alert(`Enroll in the ${pdf.trackId.toUpperCase()} track (or Full Access Pass) to unlock this resource.`);
      return;
    }
    const a = document.createElement('a');
    a.href = pdf.fileUrl;
    a.download = pdf.title.replace(/[^a-zA-Z0-9]/g, '_') + '.pdf';
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setDownloadedIds(prev => [...prev, pdf.id]);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-3">
          📑 Official Kaizen Fitness Academy Blueprints &amp; Workbooks
        </div>
        <h1 className="text-3xl font-black text-white font-display mb-2">PDF Program &amp; Workbook Vault</h1>
        <p className="text-slate-400">Authentic 12-week workout plans, nutrition workbooks, periodized tracking sheets, and powerlifting peaking blueprints. Download or view online.</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-8">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
            filter === 'all' ? 'bg-slate-700 text-white' : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
          }`}
        >
          All Resources ({DOWNLOADABLE_PDFS.length})
        </button>
        {TRACKS.map(t => {
          const Icon = TRACK_ICONS[t.id] || FileText;
          return (
            <button
              key={t.id}
              onClick={() => setFilter(t.id)}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-sm font-medium transition-all border ${
                filter === t.id ? TRACK_COLORS[t.id] : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />{t.id.charAt(0).toUpperCase() + t.id.slice(1)}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {pdfs.map(pdf => {
          const enrolled = checkUserAccess(pdf);
          const downloaded = downloadedIds.includes(pdf.id);
          const Icon = TRACK_ICONS[pdf.trackId] || FileText;
          const colors = TRACK_COLORS[pdf.trackId] || TRACK_COLORS.build;

          return (
            <div key={pdf.id} className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className={`flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${colors}`}>
                    <Icon className="w-3 h-3" />
                    {pdf.category}
                  </span>
                  <span className="text-xs text-slate-500 font-mono">{pdf.pages} Pages · {pdf.fileSize}</span>
                </div>

                <h3 className="text-base font-bold text-white mb-2 leading-snug">{pdf.title}</h3>
                <p className="text-xs text-slate-400 mb-4 leading-relaxed">{pdf.description}</p>

                {/* Content preview tags */}
                <div className="space-y-1.5 mb-5 p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                  {pdf.previewSections?.map((sec, idx) => (
                    <div key={idx} className="text-xs text-slate-300">
                      <span className="text-emerald-400 font-semibold">{sec.title}: </span>
                      <span className="text-slate-400 line-clamp-1">{sec.text}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-slate-800/80">
                <button
                  onClick={() => setPreviewPdf(pdf)}
                  className="flex-1 py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors border border-slate-700"
                >
                  <Eye className="w-3.5 h-3.5" />
                  View Online
                </button>

                <button
                  onClick={() => handleDownload(pdf)}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                    enrolled
                      ? downloaded
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20'
                      : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  }`}
                >
                  {enrolled ? (
                    downloaded ? (
                      <>
                        <CheckCircle className="w-3.5 h-3.5" />
                        Saved
                      </>
                    ) : (
                      <>
                        <Download className="w-3.5 h-3.5" />
                        Download PDF
                      </>
                    )
                  ) : (
                    <>
                      <Lock className="w-3.5 h-3.5" />
                      Enroll to Unlock
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Online PDF Viewer Modal */}
      {previewPdf && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative w-full max-w-4xl h-[85vh] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-950 flex-shrink-0">
              <div className="flex items-center gap-2.5 min-w-0">
                <FileText className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span className="text-sm font-bold text-white truncate">{previewPdf.title}</span>
                <span className="text-xs text-slate-500 hidden sm:inline font-mono">({previewPdf.pages} Pages)</span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={previewPdf.fileUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1 transition-colors"
                >
                  <ExternalLink className="w-3 h-3" />
                  New Tab
                </a>
                <button
                  onClick={() => setPreviewPdf(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Embedded Iframe */}
            <div className="flex-1 bg-slate-950 relative">
              <iframe
                src={`${previewPdf.fileUrl}#view=FitH`}
                title={previewPdf.title}
                className="w-full h-full border-0"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export const WORKOUT_TEMPLATES = {
  build: [
    {
      id: 'w-b1',
      name: 'Day 1: Upper Hypertrophy (Chest & Back Focus)',
      day: 1,
      estimatedTime: '65 mins',
      exercises: [
        {
          id: 'ex-1',
          name: 'Incline Dumbbell Press (30° Angle)',
          targetSets: 4,
          targetReps: '8 - 10',
          targetRpe: '8.5',
          restTime: '120s',
          formTip: 'Keep elbows tucked at 45 degrees, slow 3-second eccentric stretch.',
          defaultWeight: 36
        },
        {
          id: 'ex-2',
          name: 'Chest-Supported T-Bar Row',
          targetSets: 4,
          targetReps: '10 - 12',
          targetRpe: '8.0',
          restTime: '90s',
          formTip: 'Lead with the elbows, squeeze shoulder blades together at top.',
          defaultWeight: 50
        },
        {
          id: 'ex-3',
          name: 'Standing Cable Lateral Raises',
          targetSets: 4,
          targetReps: '12 - 15',
          targetRpe: '9.0',
          restTime: '60s',
          formTip: 'Slight forward lean, raise arms in the scapular plane.',
          defaultWeight: 10
        },
        {
          id: 'ex-4',
          name: 'Incline Dumbbell Bicep Curls',
          targetSets: 3,
          targetReps: '10 - 12',
          targetRpe: '8.5',
          restTime: '60s',
          formTip: 'Keep elbows pinned behind torso for deep bicep stretch.',
          defaultWeight: 14
        },
        {
          id: 'ex-5',
          name: 'Overhead Cable Tricep Extensions',
          targetSets: 3,
          targetReps: '12 - 15',
          targetRpe: '9.0',
          restTime: '60s',
          formTip: 'Flared elbows slightly, fully stretch the tricep long head at bottom.',
          defaultWeight: 22
        }
      ]
    },
    {
      id: 'w-b2',
      name: 'Day 2: Lower Quad & Posterior Chain Focus',
      day: 2,
      estimatedTime: '70 mins',
      exercises: [
        {
          id: 'ex-6',
          name: 'Hack Squat (Heels Elevated)',
          targetSets: 4,
          targetReps: '8 - 10',
          targetRpe: '8.5',
          restTime: '150s',
          formTip: 'Descend to full depth, push through midfoot without locking knees violently.',
          defaultWeight: 120
        },
        {
          id: 'ex-7',
          name: 'Romanian Deadlift (Dumbbell or Barbell)',
          targetSets: 3,
          targetReps: '8 - 10',
          targetRpe: '8.0',
          restTime: '120s',
          formTip: 'Hips push straight back like closing a car door with your glutes.',
          defaultWeight: 90
        },
        {
          id: 'ex-8',
          name: 'Seated Leg Curls',
          targetSets: 3,
          targetReps: '12 - 15',
          targetRpe: '9.0',
          restTime: '60s',
          formTip: 'Lock thigh pad tight against quads to prevent hip movement.',
          defaultWeight: 45
        },
        {
          id: 'ex-9',
          name: 'Standing Single-Leg Calf Raises',
          targetSets: 4,
          targetReps: '15',
          targetRpe: '9.5',
          restTime: '45s',
          formTip: 'Hold 2-second pause at full deep stretch.',
          defaultWeight: 20
        }
      ]
    }
  ],
  cut: [
    {
      id: 'w-c1',
      name: 'Day 1: Upper Body Strength & Density',
      day: 1,
      estimatedTime: '55 mins',
      exercises: [
        {
          id: 'exc-1',
          name: 'Barbell Flat Bench Press',
          targetSets: 3,
          targetReps: '5 - 6',
          targetRpe: '8.0',
          restTime: '150s',
          formTip: 'Heavy load to signal muscle retention during caloric deficit.',
          defaultWeight: 85
        },
        {
          id: 'exc-2',
          name: 'Weighted Neutral-Grip Pull-ups',
          targetSets: 3,
          targetReps: '6 - 8',
          targetRpe: '8.5',
          restTime: '120s',
          formTip: 'Full deadhang at bottom, chest touches bar at top.',
          defaultWeight: 15
        },
        {
          id: 'exc-3',
          name: 'Seated Dumbbell Shoulder Press',
          targetSets: 3,
          targetReps: '8 - 10',
          targetRpe: '8.0',
          restTime: '90s',
          formTip: 'Press slightly angled in front of the head.',
          defaultWeight: 26
        },
        {
          id: 'exc-4',
          name: 'Incline Treadmill Fast Walk (NEAT / Cardio)',
          targetSets: 1,
          targetReps: '20 mins',
          targetRpe: '6.0',
          restTime: '0s',
          formTip: '12% Incline, 3.2 mph speed, zero handrail holding.',
          defaultWeight: 0
        }
      ]
    }
  ],
  gain: [
    {
      id: 'w-g1',
      name: 'Day 1: Full Body Heavy Compound Push',
      day: 1,
      estimatedTime: '60 mins',
      exercises: [
        {
          id: 'exg-1',
          name: 'Barbell Back Squat',
          targetSets: 4,
          targetReps: '6 - 8',
          targetRpe: '8.0',
          restTime: '180s',
          formTip: 'Brace core with diaphragmatic breath, drive knees outward.',
          defaultWeight: 100
        },
        {
          id: 'exg-2',
          name: 'Overhead Barbell Military Press',
          targetSets: 4,
          targetReps: '6 - 8',
          targetRpe: '8.0',
          restTime: '120s',
          formTip: 'Squeeze glutes tight to stabilize spine during vertical press.',
          defaultWeight: 50
        },
        {
          id: 'exg-3',
          name: 'Barbell Bent Over Row (Overhand)',
          targetSets: 4,
          targetReps: '8 - 10',
          targetRpe: '8.5',
          restTime: '120s',
          formTip: 'Torso at 45 degree angle, pull bar into lower sternum.',
          defaultWeight: 70
        }
      ]
    }
  ],
  powerlifting: [
    {
      id: 'w-p1',
      name: 'Day 1: Heavy Squat & Bench Primary Day',
      day: 1,
      estimatedTime: '80 mins',
      exercises: [
        {
          id: 'exp-1',
          name: 'Competition Low Bar Squat',
          targetSets: 4,
          targetReps: '3',
          targetRpe: '8.5',
          restTime: '240s',
          formTip: 'Wedge bar low across rear delts, break hips and knees simultaneously.',
          defaultWeight: 160
        },
        {
          id: 'exp-2',
          name: 'Competition Paused Bench Press',
          targetSets: 4,
          targetReps: '3',
          targetRpe: '8.5',
          restTime: '180s',
          formTip: '1-second motionless pause on chest before pressing in J-curve.',
          defaultWeight: 120
        },
        {
          id: 'exp-3',
          name: 'Close-Grip Bench Press (Tricep Builder)',
          targetSets: 3,
          targetReps: '6',
          targetRpe: '8.0',
          restTime: '120s',
          formTip: 'Hands shoulder-width apart, elbows tracked tight to ribs.',
          defaultWeight: 90
        }
      ]
    }
  ]
};

export const INITIAL_PROGRESS_LOGS = [
  {
    date: '2026-08-10',
    weight: 78.4,
    bodyFat: 14.2,
    track: 'build',
    workoutCompleted: 'Upper Hypertrophy',
    notes: 'Hit 36kg DB Incline for 10 reps on set 1. Energy was top notch.'
  },
  {
    date: '2026-08-12',
    weight: 78.6,
    bodyFat: 14.1,
    track: 'build',
    workoutCompleted: 'Lower Quad Focus',
    notes: 'Hack squat feeling very clean, increased depth.'
  },
  {
    date: '2026-08-15',
    weight: 78.9,
    bodyFat: 13.9,
    track: 'build',
    workoutCompleted: 'Push Volume',
    notes: 'Shoulder pump was insane with cable laterals.'
  }
];

export const DOWNLOADABLE_PDFS = [
  {
    id: 'pdf-wb-build',
    title: 'Kaizen Muscle Gain Mastery Workbook',
    trackId: 'build',
    category: 'Hypertrophy Workbook',
    fileUrl: '/pdfs/Kaizen_Muscle_Gain_Workbook.pdf',
    fileSize: '7 KB',
    pages: 2,
    badge: 'Official Workbook',
    description: 'Evidence-based muscle building companion workbook featuring caloric surplus calculators, progressive overload tables, volume landmark logs, and anthropometric tracking.',
    previewSections: [
      { title: 'Surplus Calculator', text: 'Step-by-step TDEE formula with individual +250-350 kcal surplus targets, 2.0g/kg protein, and 0.8g/kg fat floor.' },
      { title: 'Progression Log', text: '5-week progressive overload tracking table with double progression rules for Upper/Lower movements.' },
      { title: 'Review Matrix', text: 'Bi-weekly waist-to-chest circumference ratios and 7-day rolling average scale trend monitoring.' }
    ]
  },
  {
    id: 'pdf-wb-cut',
    title: 'Kaizen Fat Loss Protocol Workbook',
    trackId: 'cut',
    category: 'Fat Loss Workbook',
    fileUrl: '/pdfs/Kaizen_Fat_Loss_Workbook.pdf',
    fileSize: '7 KB',
    pages: 2,
    badge: 'Official Workbook',
    description: 'Comprehensive sub-10% fat loss workbook featuring deficit calculators, 3-day full body preservation trackers, 21-day plateau flowcharts, and MATADOR diet break scheduling.',
    previewSections: [
      { title: 'Deficit Calculator', text: 'Target deficit determination with 2.2g/kg protein shield and non-negotiable 0.75g/kg hormonal fat floor.' },
      { title: 'Preservation Log', text: 'Full body heavy tension preservation tracking sheet with weekly step targets and Zone 2 cardio logs.' },
      { title: 'Plateau Diagnostics', text: '21-day diagnostic matrix to differentiate cortisol-mediated water retention from true metabolic stalls.' }
    ]
  },
  {
    id: 'pdf-wb-gain',
    title: 'Kaizen Skinny to Built Transformation Workbook',
    trackId: 'gain',
    category: 'Recomposition Workbook',
    fileUrl: '/pdfs/Kaizen_Skinny_To_Built_Workbook.pdf',
    fileSize: '7 KB',
    pages: 2,
    badge: 'Official Workbook',
    description: 'Designed specifically for beginners and hardgainers: body recomposition baseline audits, alternating A/B workout logs, and habit consistency grids.',
    previewSections: [
      { title: 'Recomposition Audit', text: 'Establish baseline stats, hydration needs, and maintenance energy targets to build muscle while losing fat.' },
      { title: 'Alternating A/B Log', text: 'Foundational movement pattern logger (push, pull, squat, hinge) across 12 weeks of training.' },
      { title: 'Habit Mastery Grid', text: 'Monthly recomposition benchmarks tracking stable scale weight with shrinking waist measurements.' }
    ]
  },
  {
    id: 'pdf-kfa-plans',
    title: 'Kaizen 12-Week Master Workout Blueprints',
    trackId: 'bundle',
    category: 'Master Workout Routine',
    fileUrl: '/pdfs/KFA_12_Week_Workout_Plans.pdf',
    fileSize: '40 KB',
    pages: 6,
    badge: 'Master Blueprint',
    description: 'The master printable workout PDF containing Track 1 (4-Day Upper/Lower), Track 2 (3-Day Full Body), Track 3 (Alternating A/B), and official tracking sheets.',
    previewSections: [
      { title: 'Track 1: Muscle Gain', text: '4-day Upper A, Lower A, Upper B, Lower B hypertrophy periodization.' },
      { title: 'Track 2: Fat Loss', text: '3-day Full Body A, B, C metabolic resistance split with low-impact cardio.' },
      { title: 'Track 3: Skinny to Built', text: 'Alternating Workout A & B mass engineering foundation routine.' },
      { title: 'Page 6 Tracking Sheet', text: 'Standardized printable workout log for sets, reps, load, and RIR tracking.' }
    ]
  },
  {
    id: 'pdf-pl-squat',
    title: 'Powerlifting Squat Mastery Blueprint (Block 1 Conventional)',
    trackId: 'powerlifting',
    category: 'Strength Program',
    fileUrl: '/pdfs/Powerlifting_Block1_Conv_3xBench.pdf',
    fileSize: '2.5 MB',
    pages: 12,
    badge: 'Squat Program',
    description: 'Periodized squat programming with percentage-based progression, hip anatomy calibration, and competition legal depth execution standards.',
    previewSections: [
      { title: 'Periodized Wave', text: 'Multi-week wave loading: hypertrophy capacity -> strength conversion -> heavy singles.' },
      { title: 'Depth & Cues', text: 'Spreading the floor, screw feet into ground, eliminate lumbar butt-wink at the hole.' }
    ]
  },
  {
    id: 'pdf-pl-bench',
    title: 'Powerlifting Bench Press Specialization (4x Weekly Frequency)',
    trackId: 'powerlifting',
    category: 'Strength Program',
    fileUrl: '/pdfs/Powerlifting_Block1_Conv_4xBench.pdf',
    fileSize: '2.5 MB',
    pages: 12,
    badge: 'Bench Program',
    description: 'High-frequency bench press program with 4 weekly bench sessions, paused competition variations, close-grip accessories, and J-curve bar paths.',
    previewSections: [
      { title: '4x Frequency', text: 'Primary competition bench, paused Spoto press, close-grip tricep overload, and technique recovery.' },
      { title: 'Bar Path', text: 'J-curve trajectory off the sternum back over the glenohumeral joint.' }
    ]
  },
  {
    id: 'pdf-pl-deadlift',
    title: 'Powerlifting 15-Week Sumo Deadlift Peaking Blueprint',
    trackId: 'powerlifting',
    category: 'Strength Program',
    fileUrl: '/pdfs/Powerlifting_15_Week_Sumo_4xBench.pdf',
    fileSize: '2.8 MB',
    pages: 15,
    badge: 'Deadlift Program',
    description: 'Complete 15-week SBD peaking program featuring sumo deadlift specialisation, attempt selection matrix, and competition taper timeline.',
    previewSections: [
      { title: 'Sumo Mechanics', text: 'Hip wedge, taking slack out of the bar, and locking out with glutes.' },
      { title: 'Attempt Matrix', text: 'Opener at 90-92%, 2nd at 96-98%, 3rd attempt PR selection.' }
    ]
  },
  {
    id: 'pdf-playbook',
    title: 'Mission Kaizen Daily Playbook & Habit System',
    trackId: 'bundle',
    category: 'Mindset & Habits',
    fileUrl: '/pdfs/Mission_Kaizen_Daily_Playbook.pdf',
    fileSize: '24 KB',
    pages: 4,
    badge: 'Daily Tracker',
    description: 'Printable daily performance logbook, workout accountability checklist, nutrition compliance metrics, and morning/evening discipline systems.',
    previewSections: [
      { title: 'Daily Check-in', text: 'Hydration (3L+), Sleep (7.5h+), Protein Target (2g/kg), Step Goal (8k-10k).' },
      { title: 'Workout Logging', text: 'Pre-workout readiness rating (1-10), load progressions, RIR logging, and recovery notes.' }
    ]
  }
];

import React from 'react';
import { Dumbbell, ShieldCheck, Award, Heart, Lock } from 'lucide-react';

export const Footer = ({ onSelectTrack, setCurrentView }) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800/80 text-slate-400 text-sm mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center">
                <Dumbbell className="w-5 h-5 text-emerald-400" />
              </div>
              <span className="font-extrabold text-xl tracking-wider text-white font-display">
                KAIZEN<span className="text-emerald-400"> ACADEMY</span>
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed text-sm max-w-sm">
              The premier digital academy for science-based strength training, hypertrophy engineering, sub-10% fat loss protocols, and powerlifting 1RM mastery.
            </p>
            <div className="flex items-center gap-4 text-xs text-slate-500 pt-2">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> 30-Day Guarantee
              </span>
              <span className="flex items-center gap-1">
                <Award className="w-4 h-4 text-amber-400" /> Verified Credentials
              </span>
              <span className="flex items-center gap-1">
                <Lock className="w-4 h-4 text-cyan-400" /> 256-Bit SSL Checkout
              </span>
            </div>
          </div>

          {/* Training Tracks */}
          <div>
            <h4 className="font-bold text-white uppercase text-xs tracking-wider mb-4">Training Tracks</h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button 
                  onClick={() => { onSelectTrack('build'); setCurrentView('curriculum'); }}
                  className="hover:text-emerald-400 transition-colors"
                >
                  Hypertrophy (Build)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectTrack('cut'); setCurrentView('curriculum'); }}
                  className="hover:text-cyan-400 transition-colors"
                >
                  Fat Loss & Shred (Cut)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectTrack('gain'); setCurrentView('curriculum'); }}
                  className="hover:text-amber-400 transition-colors"
                >
                  Clean Bulking (Gain)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectTrack('powerlifting'); setCurrentView('curriculum'); }}
                  className="hover:text-purple-400 transition-colors"
                >
                  SBD Peaking (Powerlifting)
                </button>
              </li>
            </ul>
          </div>

          {/* Tools & Resources */}
          <div>
            <h4 className="font-bold text-white uppercase text-xs tracking-wider mb-4">Academy Tools</h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button 
                  onClick={() => setCurrentView('tracker')}
                  className="hover:text-white transition-colors"
                >
                  Interactive Workout Logger
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentView('tracker')}
                  className="hover:text-white transition-colors"
                >
                  1RM Calculator (Epley/Brzycki)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentView('tracker')}
                  className="hover:text-white transition-colors"
                >
                  Bodyweight & Body Fat % Tracker
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentView('resources')}
                  className="hover:text-white transition-colors"
                >
                  Downloadable PDFs & Excel Files
                </button>
              </li>
            </ul>
          </div>

          {/* Legal & Trust */}
          <div>
            <h4 className="font-bold text-white uppercase text-xs tracking-wider mb-4">Support & Trust</h4>
            <ul className="space-y-2.5 text-sm">
              <li className="text-xs text-slate-400 font-medium">Customer & Athlete Support:</li>
              <li>
                <a
                  href="mailto:rajjj3209@gmail.com"
                  className="text-emerald-400 hover:text-emerald-300 font-semibold transition-colors flex items-center gap-1.5"
                >
                  rajjj3209@gmail.com
                </a>
              </li>
              <li><span className="text-slate-400 text-xs">Instant UPI & Card Assistance</span></li>
              <li><span className="text-slate-400 text-xs">30-Day 100% Refund Guarantee</span></li>
            </ul>
          </div>

        </div>

        <div className="border-t border-slate-800/80 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2026 Kaizen Academy. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Built for elite natural athletes & serious lifters worldwide.
          </p>
        </div>
      </div>
    </footer>
  );
};
